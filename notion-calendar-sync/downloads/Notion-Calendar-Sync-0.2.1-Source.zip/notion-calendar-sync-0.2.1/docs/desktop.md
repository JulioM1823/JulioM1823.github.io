# Notion Calendar Sync desktop guide

**0.2.1 platform validation:** Native Intel macOS and Windows x64 checks now pass, including packaged UI, secure storage, setup/sync acceptance, installer rollback and Windows crash recovery. See [the platform and live-API report](desktop-platform-validation-20261109.md) for tested operating systems, actual provider checks and limitations.

A free, MIT-licensed desktop application for macOS and Windows. The setup window connects your accounts, selects a Notion data source and Google calendar, maps fields, previews changes and asks before starting the first synchronization. It uses the same SQLite journal, duplicate prevention, two-way deletion, conflict handling and gzip transport as the Pi service. It requires no paid automation or hosting.

## Install and open

**macOS:** The `universal2` disk image includes Apple Silicon and Intel machine code; `arm64` is an Apple Silicon-only alternative. Open the suitable disk image, drag **Notion Calendar Sync.app** into Applications, then open it. The local build is not Developer ID signed or notarized: macOS may require using Finder's Open action or the system's Privacy & Security approval. A paid Apple signing identity was not required or used. Only approve a download whose source and checksum you trust. You do not need to install Python. Including Intel code does not imply that this release was executed on an Intel Mac; check the validation report.

**Windows x64 portable download:** Extract the entire ZIP first, then double-click **Start Notion Calendar Sync.vbs**. It includes a private, hash-verified official Python runtime, Tcl/Tk and timezone data. It does not use or modify an existing Python installation, change your PATH, or require administrator access. **Install.vbs** optionally copies the application into your per-user Programs folder and creates desktop/Start-menu shortcuts. Quit the app before upgrading. **Start Notion Calendar Sync.cmd** is a double-click fallback where Windows Script Host is disabled; no typed terminal commands are needed. The `.cmd` fallback briefly opens a console while launching the GUI.

**Windows native download:** The optional native-build ZIP contains `Notion Calendar Sync.exe`; extract the whole folder and open that executable. Native Windows artifacts are built by the included Windows workflow or on a Windows computer. Artifacts are unsigned; local Windows policy may block untrusted downloads. The portable runtime ZIP and native frozen executable are separate formats, not interchangeable builds.

The Windows bundle targets Windows 10/11 x64. Native ARM Windows is not built here; x64 emulation availability depends on the Windows system. macOS compatibility also depends on the Python/Tk used by the builder; check the artifact's build manifest and validation report. No Windows execution result is implied by assembling a Windows ZIP on a Mac.

## 1. Connect Notion

Create an internal Notion connection in [Notion's connection settings](https://www.notion.so/profile/integrations), select the workspace, and give it **Read, Insert and Update content** capabilities. Copy its internal token into the masked app field. The application stores it in macOS Keychain or Windows Credential Manager, never a plaintext settings file.

In Notion, grant that connection access to the database or parent page you want to synchronize. Notion may require doing this in the website or application; the desktop tool cannot grant itself access. The connection only discovers content that you explicitly share with it. A failed or missing database lookup therefore means an access/setup issue, not deletion.

## 2. Connect Google Calendar

This open-source build uses **your own Google Desktop OAuth client**. It does not ship a developer's reusable client credentials or a paid service. In a Google Cloud project, enable **Google Calendar API**, configure the OAuth consent screen, and create a **Desktop app** OAuth client. Download its client JSON and select it in the app, then choose **Authorize Google**. A browser opens Google's consent screen and returns to the local computer through the official loopback flow with PKCE/state verification. Google refresh tokens and the imported client credential are stored in the operating system credential store.

Google requests `calendar.events` and `calendar.calendarlist.readonly`; the app shows the writable calendars available to that account. A project in External/**Testing** mode can issue Calendar refresh tokens that expire after seven days. For unattended personal operation, finish the applicable consent-screen setup and move the client to **In production**, then authorize again. Public distribution of one shared OAuth client can require Google's verification process; supplying one's own desktop client avoids shipping a credential belonging to the application author, but does not bypass Google's policies. Ordinary grant revocation and account-security changes can still require reconnecting. See [Google desktop OAuth](https://developers.google.com/identity/protocols/oauth2/native-app) and [token-expiration rules](https://developers.google.com/identity/protocols/oauth2#expiration).

The application cannot sign in, accept consent or create an account on your behalf. These are account-owner actions in the provider's browser. An account may be restricted by its organization administrator.

## 3. Choose data and map fields

Search for a shared Notion database/data source by name, or enter its Notion URL/ID. Names are labels: confirm the displayed IDs when names repeat. A database can contain more than one data source; select the specific source whose properties should map to Calendar. Then choose a writable Google calendar. Optional Notion select/category and synchronization-checkbox filters can limit participating entries.

The mapping screen reads the actual schema, proposes compatible properties and lets you change them. Required fields are a title, a Notion date range and a rich-text Google event identity property. You can explicitly approve creation of missing integration properties before they are added. Other compatible fields include plain description/notes, location, Google event URL, IANA timezone, recurrence text and an opt-in checkbox. Unrelated properties and Notion page content are preserved.

A **Notion date range** carries start and end and distinguishes date-only/all-day values from timed values; it does not require separate start, end and all-day columns. All-day Notion end dates are inclusive while Google's are exclusive; the engine handles the conversion. Missing timed ends use the configured duration. Undated or date-cleared entries are paused, never turned into invalid events or automatically deleted. The IANA timezone mapping preserves DST behavior. Description mapping uses literal plain source, so HTML-like text is not repeatedly reformatted.

Recurring events use an optional recurrence text property: one RFC5545 rule per line. A series is represented by a master page plus explicitly supported modified/cancelled exceptions, never an unlimited list of future pages. Attendees, invitations and RSVP synchronization are outside the default mapping. See [complete mapping rules](mapping.md) for recurrence and deletion limits.

## 4. Review the first synchronization

The preview is read-only and lists proposed creates, updates, stable-ID links, conflicts and unsupported/paused items. Read it before approving **Start synchronization**. Changing settings invalidates the previous preview. Existing items are linked only through stable identifiers or explicit reviewed links; identical titles/dates are not proof of identity. If both platforms contain independent copies with no shared identifiers, automatic merging is deliberately unavailable: review/link those identities before authorizing creates.

The desktop has its own local state. Do not point it at the same calendar/data source already being synchronized by the Pi, another desktop, or a third-party tool. Independent workers have independent journals and can create duplicate counterparts. To migrate from the Pi, pause its service and transfer configuration/state using an explicit migration procedure; simply reconnecting accounts does not transfer the Pi's mappings. The existing Pi deployment is not changed by installing this app.

## Dashboard and background use

The dashboard displays connection status, the most recent successful synchronization, pending operations and conflicts. Pause/resume controls preserve the SQLite journal. A paused mapping change requires another preview/approval; changes that could reinterpret existing identities need a separate mapping/state rather than silently reusing old links. Conflict details retain both versions and offer an explicit provider choice. For a deletion concurrent with an edit, the conflict is retained rather than discarding the edit silently.

The host computer must be **awake, connected to the internet and running the application/background worker**. A laptop asleep or powered off cannot synchronize. The optional startup-at-login setting starts it for your user after login; this is not a server running before login. The window’s close control minimizes it, so synchronization continues in the background. Use its explicit Quit action to end background synchronization. After temporary network failures, durable work is retried with bounded backoff and reconciliation. Reconnect an account if its grant is revoked.

Diagnostics export contains counts, health and sanitized error categories, not OAuth credentials, event descriptions or full provider snapshots. Review any diagnostic file before sharing it. Full backups contain private events and must be protected. Credential-store items are outside SQLite; migrating a state backup to another computer requires connecting the accounts there.

## Upgrade and uninstall

Pause synchronization, quit the app and keep a state backup before replacing a bundle. Replace the application in Applications on macOS, or rerun the per-user Windows installer from a fresh extracted ZIP after quitting all running copies. Configuration/state live separately in the user's app-data directory and are preserved. Updates are explicit; the app does not download and execute arbitrary code.

To uninstall, disable startup at login, quit synchronization, and delete the application bundle/installed program folder and its shortcuts. This preserves local SQLite history, provider events and operating-system credentials. Remove those separately only when you intend to disconnect and permanently discard local history. Deleting SQLite history alone and reconnecting to the same providers can defeat duplicate prevention; keep a backup and use stable-ID linking when migrating.

## Build from source

The engine requires Python 3.11+; desktop release builds use Python 3.14 with Tk. The Pi service remains a separate zero-dependency installation. From a clean checkout, install build tools into an isolated environment:

```sh
python3 -m venv .venv-desktop
# macOS: source .venv-desktop/bin/activate
# Windows: .venv-desktop\Scripts\activate
python -m pip install -r packaging/requirements-build.txt
PYTHONPATH=src python -m unittest discover -s tests -v  # PowerShell: set $env:PYTHONPATH='src' first
python scripts/build-desktop.py native
```

`native` must run on the target operating system: macOS builds an `.app`/`.dmg`, and Windows x64 builds the frozen executable folder/ZIP. The default macOS architecture matches the builder. To include both Mac architectures, use `python scripts/build-desktop.py native --mac-arch universal2`; this requires an official universal2 Python and universal binary dependencies, and PyInstaller fails if a binary is missing an architecture. `--mac-arch arm64` and `--mac-arch x86_64` explicitly select one architecture. A universal2 build still needs separate Intel execution testing. PyInstaller is a build dependency with a distribution exception compatible with the MIT app; it is not a paid runtime. Bundles retain Python, Tcl/Tk, tzdata and other runtime notices; see [third-party notices](../THIRD_PARTY_NOTICES.md).

A private-runtime Windows ZIP can also be assembled on macOS/Linux:

```sh
python scripts/build-desktop.py windows-portable
```

The builder downloads only the exact pinned official Windows runtime and tzdata wheel, verifies SHA-256 before extraction, and adds allowlisted source files. `--runtime-zip` and `--tzdata-wheel` can supply previously downloaded, matching files for an offline build. It never scans the whole workspace or packages `secrets/`, credentials, state, logs or private backups. Every output has a `.sha256` and `.manifest.json` sibling. Source has no user account identifiers.

`.github/workflows/desktop-build.yml` defines separate macOS arm64, macOS Intel and Windows x64 jobs, full tests and downloadable build artifacts. It only runs manually or for a `desktop-v*` tag; no external repository was created and no workflow execution is implied by checking in this file. Runners use the [documented native platform labels](https://docs.github.com/en/actions/reference/runners/github-hosted-runners). A public open-source repository can use free standard runner allowances; private-repository billing/allowances are controlled by its owner. Local builds do not need GitHub.

## Validation boundaries

During timed-to-all-day conversion, Google may turn inherited calendar reminders into explicit event alarms. Live checks confirmed that current alarm times are retained, but those explicit alarms may no longer follow future calendar-default changes. This provider normalization is documented rather than represented as identical raw metadata.

The local desktop validation report records the actual tests, build host and artifacts. A packaged Windows runtime can be checked for correct hashes, required Tk libraries, app modules and credential exclusion on a Mac, but that does not prove Windows Credential Manager, window rendering, shortcuts or startup behavior on Windows. Native Windows and Intel Mac execution require their respective build/test hosts. Live account smoke tests must use dedicated calendars/data sources and disposable records; a source test suite cannot prove account grants or provider consent for every user.
