# Desktop distribution notices

The application source is MIT-licensed; see `LICENSE`. The desktop builds do not bundle account credentials, user configuration or synchronization state.

## CPython and its included libraries

The portable Windows bundle includes the unmodified official CPython 3.14.10 Windows x64 runtime, excluding its optional `pip` installation and launcher scripts. Its SHA-256 is pinned in `packaging/windows-runtime.json` against the official [Python Windows runtime index](https://www.python.org/ftp/python/index-windows.json). The complete Python license and incorporated-library notices remain at `runtime/LICENSE.txt`. Python is distributed under the [PSF License Version 2 and historical licenses](https://docs.python.org/3.14/license.html).

CPython includes Tcl/Tk, SQLite, OpenSSL, zlib and other incorporated components under their respective open-source terms. Tcl/Tk uses its permissive license, SQLite is public domain, OpenSSL uses Apache-2.0, and zlib uses its permissive zlib license. Full upstream library notices, including expat, libffi, HACL*, mpdecimal, liblzma/xz, zlib-ng and zstd, are retained in `Licenses`; `SOURCES.json` records their origins. The Python distribution's full license/acknowledgement text is retained; platform bundles preserve included license files. Windows' standard Microsoft C runtime DLLs are also present as redistributed by the official CPython runtime; these platform support components are not relicensed under MIT.

For a frozen native build, the build script copies the active Python interpreter's license text and Tcl/Tk license files, when available, into the distribution's `Licenses` directory. Different build-host Python distributions can include different component versions; builders must retain their corresponding notices.

## IANA time-zone data / tzdata

Desktop distributions include `tzdata` 2026.6 so IANA zones and daylight-saving transitions work on Windows without relying on a system zoneinfo database. The Python package is Apache-2.0 licensed; the upstream IANA database is public domain. Its license files are retained in the wheel's `tzdata-2026.6.dist-info/licenses` directory or native-build `Licenses` directory. Source: [python/tzdata](https://github.com/python/tzdata).

## PyInstaller

Native bundles are assembled using PyInstaller 6.22.3. PyInstaller uses GPL-2.0 with a bootloader exception permitting distribution of the generated application under the application's license; a few files use Apache-2.0. No PyInstaller modifications are distributed. See [the official license explanation](https://pyinstaller.org/en/stable/license.html) and [COPYING.txt](https://github.com/pyinstaller/pyinstaller/blob/develop/COPYING.txt).

PyInstaller's build environment may install its own dependencies. These are build tools, not application runtime dependencies; the application does not import them. Native artifacts carry the application license plus the collected runtime notices.
