# Mapping and synchronization rules

For account creation, installation and a complete example schema, start with the [public setup guide](https://juliom1823.github.io/notion-calendar-sync/). The [downloadable server notes](https://juliom1823.github.io/notion-calendar-sync/downloads/server-setup.md) cover the headless CLI and Raspberry Pi deployment. The desktop walkthrough is also included as `docs/desktop.md` in the source archive.

## Ownership and scope

Each mapping selects exactly one Notion **data source** and one Google calendar. The service validates schema and write access before mutation. Notion view filters are not API scope and are not interpreted. By default active and database-archived membership are fully queried each poll; a linked page omitted from both triggers a direct page read, and only positively confirmed Trash is propagated. `notion_incremental=true` opts into edited-time queries with a 120-second overlap; in that mode a missing/trashed page can wait until full reconciliation (15 minutes by default) or a verified notification. Google remains incremental in either mode. To limit individual pages, configure the optional `sync_enabled` checkbox. A page is eligible when it is in the selected source, has a valid date, and passes that checkbox when configured.

The common fields are `title`, an atomic `time` range, and optional `description`, `location`, and `recurrence`. Unconfigured optional fields are neither imported nor overwritten. Identity and peer links are service-owned metadata, separate from user-editable common values.

| Logical value | Notion | Google |
| --- | --- | --- |
| Title | Mapped title property's text | `summary` |
| Start/end + all-day + zone | Mapped date value | `start`, `end` |
| Description | Mapped rich_text as literal source text | `description` |
| Location | Mapped rich_text text | `location` |
| Recurrence | Optional newline-separated recurrence source | `recurrence` array |
| Google identity | Required rich_text marker | Event `id` |
| Google user-facing link | Optional mapped URL | `htmlLink` |
| Notion peer | Page id/url | Own private `ncs_page`; source link when it does not replace another application's source |

Only the properties/fields needed for a change are patched. Page blocks are never changed. Unrelated Google metadata and private extended properties are preserved. A mapped rich-text field is replaced as a whole when its logical text changes; its internal annotations/mentions are outside this format. Unmapped text formatting is untouched. A mapped title/text property with pagination flags or a full inline mention limit is reported as ineligible instead of silently treating a partial value as complete; paginated mention-rich content is outside this literal-source mapping.

Google can normalize metadata independently of the patch. Live checks found that converting a timed event to all-day can materialize inherited calendar reminders as explicit alarms. Current effective alerts were retained, but later calendar-default changes may no longer apply. This is not byte-for-byte preservation of every provider field. Google also limits source-link visibility to the event creator; an existing source belonging to another application is preserved.

## Description format

The mapping uses **literal description source**, without HTML→Markdown→HTML conversion. Google accepts HTML in `description`; the exact source is stored as plain text in the Notion rich-text property. For example `<b>Review</b><br>notes` remains those literal characters in Notion. Plain text is also accepted. This makes repeated reconciliation stable and prevents repeated escaping/reformatting. It does not render the same rich formatting on both interfaces. Editing Notion page blocks does not edit the event description.

## Dates and time zones

- Date-only values are all-day. A Notion all-day range ending October 31 includes October 31; its Google exclusive end is November 1. A single all-day October 30 is Google `[2026-10-30, 2026-10-31)`.
- All-day records have no per-event Google time zone and use the mapping time zone canonically. Timed values use RFC3339 instants and the configured IANA time zone (`America/Denver` in the examples). An explicit zone in provider data takes precedence where present. Fixed offsets and daylight-saving transitions are normalized through the system time-zone database.
- For exact times in a repeated daylight-saving hour, map the optional `timezone` rich_text property. It stores the IANA zone separately while Date stores both instants in UTC. Live testing found that Notion coerces mixed-offset range endpoints to the start's fixed offset; UTC endpoints prevent a one-hour shift across DST. The Notion Date UI may display UTC; `NCS Time Zone` retains the intended zone. Without the zone property, native named-zone dates are used and ambiguous writes are rejected and reported.
- A mapped zone and explicit offsets do not guarantee that every provider will preserve every valid range. A live Google check of an `America/Denver` fall-back range found a 90-minute interval returned as 30 minutes, including when the request used UTC instants with that named event zone. Choosing an explicit UTC event zone preserved the tested interval. The service compares returned mapped values with the requested values; a mismatch becomes a manual provider-normalization conflict rather than allowing the shorter result to overwrite the original source. Exact named-zone fold round trips are therefore not promised.
- A missing timed end gets `default_duration_minutes` (60 by default); a missing all-day end means one day. Multi-day events remain a single linked item.
- An invalid, negative, mixed date/timestamp, nonexistent local time, or ambiguous offset-free local time is reported and preserved rather than written as an invalid event. Use explicit UTC offsets for repeated hours at the end of daylight saving.
- The start, end, zone, all-day flag, and recurrence form one conflict group; a range is not assembled from incompatible halves. A time-zone change can change the logical time representation even where the UTC instant stays the same.
- **Undated new Notion pages do not create Google events.** Clearing the date or disabling `sync_enabled` on an existing linked page suspends synchronization for that pair. The existing event is retained, and this is reported as ineligible. No query disappearance or date clearing acts as a deletion.
- Moving a page outside the selected source, archiving it from a data-source view (`is_archived`, distinct from Trash), or losing access suspends it. It does not remove the event.

Notion's date/property API and Google Calendar's all-day semantics are documented in [Notion page properties](https://developers.notion.com/reference/page-property-values) and [Google event resources](https://developers.google.com/workspace/calendar/api/v3/reference/events).

## Initial import and explicit links

`dry-run` reads complete provider pages and emits proposed actions without changing providers or persistent synchronization state. Matching uses a persisted pair, an exact configured Google event-id marker, or the service's private Google page-id marker. Existing user-facing URLs and titles are not used to guess a pair.

An unlinked eligible Notion page creates a Google event. An unlinked supported Google event creates a Notion page containing its exact event-id marker. Therefore existing third-party pairs must be linked before an initial apply to avoid importing their two sides independently.

```sh
sudo systemctl stop ncs
sudo ncs-control link --mapping calendar --notion NOTION_PAGE_UUID --google GOOGLE_EVENT_ID
sudo ncs-control link --mapping calendar --notion NOTION_PAGE_UUID --google GOOGLE_EVENT_ID --apply
sudo ncs-control dry-run
```

Linking records both versions as a baseline only after a safe comparison; differing values are exposed for review. Unrelated items are never merged merely because their names or times match.

## Conflicting changes

Each link retains the last successfully synchronized values and provider versions. A field changed on one side propagates. Independent changes on opposite sides merge. Identical edits converge without another write. The default `manual` policy persists competing values rather than discarding either edit.

A conflict contains ids, common baseline, both observed versions, and affected fields. View full details with `conflicts ID`; resolve with `resolve ID --prefer notion` or `--prefer google`. The engine refetches the current records before applying a resolution; it does not blindly replay an old response. The other items in the mapping continue while a conflict waits.

Alternative mapping policies `notion` and `google` select the named side for incompatible changes. These policies explicitly authorize discarding the other conflicting value and are not the default. Independent changes still merge.

A **provider-normalization conflict** means the provider returned mapped values different from the values just requested, or an interrupted write cannot safely establish its intended result. It retains the original source, requested values, returned values and previous common baseline for review. It is held for manual review even when the mapping policy prefers Notion or Google. An explicit resolution is checked again; if the provider changes the requested value again, the conflict remains open. For the tested fall-back interval, a deliberate change to an explicit UTC event zone preserved the 90-minute duration. This is a user choice to review, not an automatic reinterpretation of a named regional time zone. If an item is edited after a conflict was recorded, the first resolution refreshes the conflict snapshots; inspect the refreshed conflict before choosing again.

## Explicit deletions

A positively fetched Notion trashed page (`in_trash`, or the legacy page-level `archived` alias) or a positively fetched Google `status=cancelled` event is deletion evidence. The linked peer is trashed/cancelled, using reversible provider behavior where available, and the mapping remains as a tombstone to prevent accidental recreation. Provider trash retention and restore capabilities still apply; SQLite retains the logical mapping even after provider retention expires.

A deletion concurrent with an edit is a conflict under the default policy. A 401/403/404, failed page request, missing row in a view/query, incomplete pagination, or expired sync token never means deletion. A positive cancellation payload from events.list remains deletion evidence if a subsequent event GET returns 410; a standalone 410 without that payload is not sufficient. Otherwise, if deleted resources are no longer retrievable, the service preserves the peer and reports uncertain access.

Restoring just one provider resource does not implicitly remove the tombstone or resurrect its peer. Restore both resources explicitly in their provider interfaces, then use `link ... --apply` for the same live pair to reactivate it. Do not delete SQLite state to force a new import. A deletion conflict can choose the deleted side to propagate cancellation; choosing the live side requires explicit provider restore before relinking.

The [public platform and live-API validation report](desktop-platform-validation-20261109.md) records the deletion checks actually performed and their scope. Personal production-deployment reports are intentionally omitted from distributable source. The [public guide](https://juliom1823.github.io/notion-calendar-sync/#behavior) explains the supported deletion and restore behavior.

## Recurring events

Notion's public date property is a date range, not a recurrence-rule/exception API. This service represents recurrence explicitly in an optional text property. Google recurrence is kept as its RFC5545 source: one `RRULE:...`, `RDATE:...`, or `EXDATE:...` line per line. `DTSTART`/`DTEND` belong in the mapped Date field and are not accepted in the recurrence text. No occurrence expansion is performed.

| Item/edit | Representation and direction |
| --- | --- |
| Recurring master | One Notion page; Google series title/time/notes/location/rule edits sync both ways. |
| New series from Notion | A dated page with a configured recurrence property creates one Google recurring master. |
| Ordinary generated occurrence | No Notion page is generated. Edit it in Google to make an explicit exception. |
| Modified Google occurrence | Its own Notion page linked to that exact instance id; immutable parent/original-start metadata remains in SQLite. Mapped edits sync only that occurrence. |
| Cancelled linked occurrence | Its own linked Notion page is trashed; trashing an exception page cancels that instance only. |
| Never-imported cancelled occurrence | Retained as a cancellation observation; no unnecessary live Notion row is generated. |
| Notion-created unlinked exception | Unsupported; the service does not infer a parent/occurrence from a title or date. |
| “This and following” edits | Google may split series into distinct masters. Each resulting master is treated as a distinct identity; no heuristic merging. |
| Missing recurrence mapping | Recurring items are skipped/reported and preserved. |

A recurring exception's parent id and original start are immutable identity. The service does not convert an exception row into a series or apply an occurrence edit to its parent. A cancelled master and its explicit cancellation records are handled without treating omitted instances as deletion evidence. Series with unsupported rules or provider special semantics are preserved and reported.

Google explains master/exception identity and list behavior in [recurring events](https://developers.google.com/workspace/calendar/api/guides/recurringevents).

## Attendees and unsupported items

By default any event with attendees is excluded from both writes and deletes, including an already linked event that later gains attendees. Google notes that `sendUpdates=none` is not an absolute no-email guarantee, so the default does not modify meetings. RSVP synchronization, invitation management, and conference creation are outside scope. `allow_attendees=true` is an explicit opt-in to event-field changes using `sendUpdates=none`; it cannot guarantee no provider email. Attendees themselves are never mapped.

Birthday, focus-time, out-of-office, working-location, and other special event types are outside the normal event mapping. Unsupported records and malformed values are visible in diagnostics and remain unmodified.

## Category scope and migration cutoff

Set `notion_select_property="Type"` and `notion_select_value="Research"` to scope one calendar to an existing Notion select option. Queries include that exact filter; directly fetched pages outside the category pause, and newly created Notion pages receive that category. Changing a linked page's category does not silently move or delete its Google event. Multiple mappings can share one data source only when they use distinct values of the same select property and distinct Google calendars.

An optional ISO timestamp with a time zone, `import_since`, prevents automatic creation for pre-existing unlinked items. Such items are reported as requiring explicit linking; verified persisted links continue synchronizing, and new records created after the cutoff synchronize normally. Missing creation timestamps fail closed. This is an opt-in migration boundary, not an event-date filter or the default configuration.

`scripts/migrate_legacy_links.py --config PATH` checks exact legacy page/event/calendar IDs from Notion Automations metadata and verifies the Google event. It never matches title/date and never treats a failed GET as deletion. Add `--apply` to persist local links with a backup; no remote event fields are changed by migration itself. Initial differences remain manual conflicts.


## One-time historical repair

The administrative history tools are separate from normal synchronization. They check the full data source for stable identifiers and unique full-field evidence, retain originals, and apply only an explicit plan. Known unavailable counterparts retain their original IDs as `historical-unavailable` links. They are rechecked during full reconciliation or after a newly observed change; they are never cloned or interpreted as deleted because of access errors. Out-of-scope relationships remain paused. A verified peer returning later is reconciled against the preserved common version (or exposed as a new conflict if its history is unknown). Personal historical-repair reports are not part of the public source package. For a new installation, use the [documented stable-ID linking procedure](https://juliom1823.github.io/notion-calendar-sync/#existing-links) rather than assuming a prior deployment's repair plan applies. This release has no desktop historical-linking or state-migration wizard.

Legacy Google whole-hour zone labels such as `GMT-05:00` are normalized to equivalent IANA fixed-offset zones (`Etc/GMT+5`) without changing the event's instants. These are fixed offsets, not inferred geographic zones, and therefore have no daylight-saving rule. Unrecognized labels/offsets remain paused.
