"""Remote writes may succeed while returning a different mapped value.

The fixture models Google's observed repeated-hour end coercion independently
of the engine: a requested 90-minute Denver range is stored as 30 minutes.
"""
from copy import deepcopy
import json
import unittest
from unittest.mock import patch

from notion_calendar_sync.engine import Engine
from notion_calendar_sync.model import normalize_time
import test_engine as engine_fixtures
from test_engine import FakeProvider, values


REQUESTED = normalize_time('2036-11-02T01:15:00-06:00',
                           '2036-11-02T01:45:00-07:00', 'America/Denver')
ACTUAL = normalize_time('2036-11-02T01:15:00-06:00',
                        '2036-11-02T01:45:00-06:00', 'America/Denver')
UTC_CHOICE = normalize_time('2036-11-02T07:15:00Z',
                            '2036-11-02T08:45:00Z', 'UTC')


class NormalizingProvider(FakeProvider):
    def __init__(self, side):
        super().__init__(side)
        self.crash_after_normalization = False

    def normalized(self, record):
        if record.values.get('time') == REQUESTED:
            self.items[record.id].values['time'] = deepcopy(ACTUAL)
            if self.crash_after_normalization:
                self.crash_after_normalization = False
                raise SystemExit('process stopped after normalized remote commit')
        return self.get(None, record.id)

    def create(self, *args, **kwargs):
        return self.normalized(super().create(*args, **kwargs))

    def update(self, *args, **kwargs):
        return self.normalized(super().update(*args, **kwargs))


class ProviderNormalizationTests(unittest.TestCase):
    setUp = engine_fixtures.EngineTests.setUp
    tearDown = engine_fixtures.EngineTests.tearDown
    sync = engine_fixtures.EngineTests.sync
    pair = engine_fixtures.EngineTests.pair

    def normalize_side(self, side):
        provider = NormalizingProvider(side)
        setattr(self, 'n' if side == 'notion' else 'g', provider)
        self.engine.providers[side] = provider
        return provider

    def open_conflict(self):
        row = self.store.db.execute("SELECT * FROM conflicts WHERE status='open' ORDER BY id DESC LIMIT 1").fetchone()
        self.assertIsNotNone(row)
        self.assertIn('provider_normalization', json.loads(row['fields']))
        self.assertIn('time', json.loads(row['fields']))
        return row

    def new_notion_fold(self):
        self.normalize_side('google')
        self.n.add('n1', values(time=REQUESTED))
        self.sync()
        link = self.store.db.execute('SELECT * FROM links').fetchone()
        return link['notion_id'], link['google_id']

    def test_create_retains_source_intent_actual_result_and_single_identity(self):
        n, g = self.new_notion_fold()
        self.assertEqual(REQUESTED, self.n.items[n].values['time'])
        self.assertEqual(ACTUAL, self.g.items[g].values['time'])
        conflict = self.open_conflict()
        detail = json.loads(conflict['base'])['_provider_normalization']
        self.assertEqual(REQUESTED, detail['requested']['time'])
        self.assertEqual(ACTUAL, detail['actual']['time'])
        self.assertEqual(REQUESTED, detail['source']['values']['time'])
        self.assertEqual('google', detail['side'])
        self.assertEqual('create', detail['action'])
        self.assertEqual(REQUESTED, json.loads(conflict['notion'])['values']['time'])
        self.assertEqual(ACTUAL, json.loads(conflict['google'])['values']['time'])
        self.assertEqual('done', self.store.db.execute('SELECT status FROM operations').fetchone()[0])
        writes = (len(self.n.writes), len(self.g.writes))
        self.engine = Engine(self.config, self.store, self.n, self.g)
        for _ in range(3):
            self.sync(full=True)
        self.assertEqual(writes, (len(self.n.writes), len(self.g.writes)))
        self.assertEqual(1, len(self.g.items))
        self.assertEqual(1, self.store.db.execute('SELECT count(*) FROM links').fetchone()[0])
        self.assertEqual(REQUESTED, self.n.items[n].values['time'])

    def test_create_guard_also_protects_google_to_notion_source(self):
        self.normalize_side('notion')
        self.g.add('g1', values(time=REQUESTED))
        self.sync()
        link = self.store.db.execute('SELECT * FROM links').fetchone()
        self.assertEqual(REQUESTED, self.g.items['g1'].values['time'])
        self.assertEqual(ACTUAL, self.n.items[link['notion_id']].values['time'])
        self.assertEqual('notion', json.loads(self.open_conflict()['base'])['_provider_normalization']['side'])

    def test_normalization_hold_ignores_automatic_policies_and_other_items_continue(self):
        n, g = self.new_notion_fold()
        before = len(self.g.writes)
        for policy in ('notion', 'google', 'manual'):
            self.mapping.conflict_policy = policy
            self.sync(full=True)
            self.assertEqual(REQUESTED, self.n.items[n].values['time'])
            self.assertEqual(before, len(self.g.writes))
            self.open_conflict()
        self.n.add('n2', values(title='Unrelated ordinary item'))
        self.sync()
        self.assertEqual(2, len(self.g.items))
        self.assertEqual(REQUESTED, self.n.items[n].values['time'])
        self.assertEqual(ACTUAL, self.g.items[g].values['time'])

    def test_update_holds_both_versions_without_advancing_successful_base(self):
        self.normalize_side('google')
        n, g = self.pair()
        original = json.loads(self.store.db.execute('SELECT base FROM links').fetchone()[0])
        self.n.edit(n, time=deepcopy(REQUESTED))
        self.sync()
        self.assertEqual(original, json.loads(self.store.db.execute('SELECT base FROM links').fetchone()[0]))
        self.assertEqual(REQUESTED, self.n.items[n].values['time'])
        self.assertEqual(ACTUAL, self.g.items[g].values['time'])
        detail = json.loads(self.open_conflict()['base'])['_provider_normalization']
        self.assertEqual('update', detail['action'])
        writes = (len(self.n.writes), len(self.g.writes))
        self.sync(full=True)
        self.assertEqual(writes, (len(self.n.writes), len(self.g.writes)))

    def test_failed_resolution_reopens_manual_hold_instead_of_discarding_source(self):
        n, g = self.new_notion_fold()
        self.mapping.conflict_policy = 'google'
        report = self.engine.resolve(self.open_conflict()['id'], 'notion')
        self.assertTrue(any(r['action'] == 'provider_normalization' for r in report))
        self.assertEqual(REQUESTED, self.n.items[n].values['time'])
        self.assertEqual(ACTUAL, self.g.items[g].values['time'])
        conflict = self.open_conflict()
        writes = (len(self.n.writes), len(self.g.writes))
        self.sync(full=True)
        self.assertEqual(writes, (len(self.n.writes), len(self.g.writes)))
        self.engine.resolve(conflict['id'], 'google')
        self.assertEqual(ACTUAL, self.n.items[n].values['time'])
        self.assertEqual(ACTUAL, self.g.items[g].values['time'])
        self.assertEqual(0, self.store.db.execute("SELECT count(*) FROM conflicts WHERE status='open'").fetchone()[0])

    def test_explicit_choice_is_honored_even_when_actual_equals_previous_base(self):
        self.normalize_side('google')
        self.n.add('n1', values(time=ACTUAL))
        self.sync()
        self.n.edit('n1', time=REQUESTED)
        self.sync()
        conflict = self.open_conflict()
        self.engine.resolve(conflict['id'], 'google')
        self.assertEqual(ACTUAL, self.n.items['n1'].values['time'])
        self.assertEqual(0, self.store.db.execute("SELECT count(*) FROM conflicts WHERE status='open'").fetchone()[0])

    def test_reviewed_utc_choice_resolves_without_losing_original_duration(self):
        n, g = self.new_notion_fold()
        conflict = self.open_conflict()
        self.n.edit(n, time=UTC_CHOICE)
        with self.assertRaisesRegex(ValueError, 'Item changed after conflict'):
            self.engine.resolve(conflict['id'], 'notion')
        fresh = self.open_conflict()
        self.engine.resolve(fresh['id'], 'notion')
        self.assertEqual(UTC_CHOICE, self.n.items[n].values['time'])
        self.assertEqual(UTC_CHOICE, self.g.items[g].values['time'])
        self.assertEqual(0, self.store.db.execute("SELECT count(*) FROM conflicts WHERE status='open'").fetchone()[0])
        self.assertEqual(1, len(self.g.items))

    def test_lost_create_response_recovers_one_id_and_keeps_normalization_hold(self):
        self.normalize_side('google').crash_after_normalization = True
        self.n.add('n1', values(time=REQUESTED))
        with self.assertRaises(SystemExit):
            self.sync()
        self.assertEqual(1, len(self.g.items))
        self.engine = Engine(self.config, self.store, self.n, self.g)
        self.sync(full=True)
        self.open_conflict()
        self.assertEqual(REQUESTED, self.n.items['n1'].values['time'])
        self.assertEqual(1, len(self.g.items))
        self.assertEqual(1, len([r for r in self.g.writes if r[0] == 'create']))

    def test_identity_completion_and_hold_are_atomic_on_local_process_death(self):
        self.normalize_side('google')
        self.n.add('n1', values(time=REQUESTED))
        with patch.object(self.engine, '_conflict', side_effect=SystemExit('stopped before conflict commit')):
            with self.assertRaises(SystemExit):
                self.sync()
        link = self.store.db.execute('SELECT * FROM links').fetchone()
        self.assertIsNone(link['google_id'])
        self.assertEqual('inflight', self.store.db.execute('SELECT status FROM operations').fetchone()[0])
        self.engine = Engine(self.config, self.store, self.n, self.g)
        self.sync(full=True)
        self.assertIsNotNone(self.store.db.execute('SELECT google_id FROM links').fetchone()[0])
        self.open_conflict()
        self.assertEqual(REQUESTED, self.n.items['n1'].values['time'])
        self.assertEqual(1, len(self.g.items))

    def test_lost_update_response_holds_unexpected_remote_value_under_auto_policy(self):
        self.normalize_side('google')
        n, g = self.pair()
        self.mapping.conflict_policy = 'google'
        self.n.edit(n, time=REQUESTED)
        self.g.crash_after_normalization = True
        with self.assertRaises(SystemExit):
            self.sync()
        self.assertEqual(ACTUAL, self.g.items[g].values['time'])
        self.engine = Engine(self.config, self.store, self.n, self.g)
        self.sync(full=True)
        self.open_conflict()
        self.assertEqual(REQUESTED, self.n.items[n].values['time'])
        self.assertEqual(1, len(self.g.items))
        self.assertEqual(0, self.store.db.execute("SELECT count(*) FROM operations WHERE status NOT IN ('done','cancelled')").fetchone()[0])


if __name__ == '__main__':
    unittest.main()
