Option Explicit
Dim fso, shell, source, target, programs, stage, backup, testRoot, testing, response
Dim shortcut, failure, name, oldMoved, promoted, arg
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
source = fso.GetParentFolderName(WScript.ScriptFullName)
testRoot = ""
For arg = 0 To WScript.Arguments.Count - 1
    If WScript.Arguments(arg) = "--test-root" And arg + 1 < WScript.Arguments.Count Then
        testRoot = WScript.Arguments(arg + 1)
    End If
Next
testing = (testRoot <> "")
If testing Then
    programs = fso.GetAbsolutePathName(testRoot)
    If Not fso.FolderExists(programs) Then WScript.Quit 2
Else
    programs = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs"
    response = MsgBox("Install Notion Calendar Sync for your Windows account?" & vbCrLf & vbCrLf & _
        "No administrator access or separate Python installation is needed." & vbCrLf & vbCrLf & _
        "Quit any existing copy before upgrading. Your saved settings and sync history are kept separately and will be preserved.", 33, "Install Notion Calendar Sync")
    If response <> 1 Then WScript.Quit 0
End If
target = programs & "\Notion Calendar Sync"
On Error Resume Next
Err.Clear
If Not fso.FolderExists(programs) Then fso.CreateFolder programs
If Err.Number <> 0 Then
    FailureMessage "The application folder could not be created. Check your account's folder access and try again."
    WScript.Quit 1
End If
stage = target & ".staging-" & fso.GetTempName
backup = target & ".previous-" & fso.GetTempName
Err.Clear
fso.CreateFolder stage
If Err.Number = 0 Then fso.CopyFolder source & "\runtime", stage & "\runtime", True
failure = Err.Number
For Each name In Array("Start Notion Calendar Sync.vbs", "Start Notion Calendar Sync.cmd", "LICENSE", "THIRD_PARTY_NOTICES.md", "USER_GUIDE.md")
    Err.Clear
    fso.CopyFile source & "\" & name, stage & "\" & name, True
    If Err.Number <> 0 Then failure = Err.Number
Next
Err.Clear
fso.CopyFolder source & "\Licenses", stage & "\Licenses", True
If Err.Number <> 0 Then failure = Err.Number
If failure <> 0 Then
    RemoveStage
    FailureMessage "The application could not be copied completely. Extract the entire ZIP, then try again. Your existing installation and saved sync data were preserved."
    WScript.Quit 1
End If
oldMoved = False
If fso.FolderExists(target) Then
    Err.Clear
    fso.MoveFolder target, backup
    If Err.Number <> 0 Then
        RemoveStage
        FailureMessage "The existing application is in use. Quit all copies, then try again. Your installation and saved sync data were preserved."
        WScript.Quit 1
    End If
    oldMoved = True
End If
Err.Clear
If testing And HasArgument("--simulate-promotion-failure") Then
    failure = 1
Else
    fso.MoveFolder stage, target
    failure = Err.Number
End If
If failure <> 0 Then
    If oldMoved Then
        Err.Clear
        fso.MoveFolder backup, target
        If Err.Number <> 0 Then
            FailureMessage "Installation could not finish. Your previous application is preserved in " & backup & ". Your saved sync data was not removed."
            WScript.Quit 1
        End If
    End If
    RemoveStage
    FailureMessage "Installation could not finish. Your previous application and saved sync data were preserved."
    WScript.Quit 1
End If
On Error GoTo 0
' Keep the previous program folder as a recovery copy; user data lives elsewhere.
If testing Then
    WScript.Echo "installed"
    WScript.Quit 0
End If
On Error Resume Next
Err.Clear
Set shortcut = shell.CreateShortcut(shell.SpecialFolders("Programs") & "\Notion Calendar Sync.lnk")
shortcut.TargetPath = target & "\runtime\pythonw.exe"
shortcut.Arguments = "-I -m notion_calendar_sync.desktop"
shortcut.WorkingDirectory = target
shortcut.Description = "Two-way Notion and Google Calendar synchronization"
shortcut.Save
Set shortcut = shell.CreateShortcut(shell.SpecialFolders("Desktop") & "\Notion Calendar Sync.lnk")
shortcut.TargetPath = target & "\runtime\pythonw.exe"
shortcut.Arguments = "-I -m notion_calendar_sync.desktop"
shortcut.WorkingDirectory = target
shortcut.Save
If Err.Number <> 0 Then
    MsgBox "The application was installed, but shortcuts could not be created. Open Start Notion Calendar Sync.vbs in " & target & ".", 48, "Notion Calendar Sync"
    WScript.Quit 0
End If
On Error GoTo 0
MsgBox "Installation complete. Use the Notion Calendar Sync shortcut to connect your accounts and review your first sync.", 64, "Notion Calendar Sync"
shell.Run Chr(34) & target & "\runtime\pythonw.exe" & Chr(34) & " -I -m notion_calendar_sync.desktop", 0, False

Function HasArgument(value)
    Dim i
    HasArgument = False
    For i = 0 To WScript.Arguments.Count - 1
        If WScript.Arguments(i) = value Then HasArgument = True
    Next
End Function

Sub RemoveStage()
    On Error Resume Next
    If fso.FolderExists(stage) Then fso.DeleteFolder stage, True
    On Error GoTo 0
End Sub

Sub FailureMessage(message)
    If testing Then
        WScript.Echo message
    Else
        MsgBox message, 16, "Notion Calendar Sync"
    End If
End Sub
