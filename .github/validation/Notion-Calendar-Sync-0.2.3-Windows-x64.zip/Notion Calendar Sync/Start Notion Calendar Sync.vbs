Option Explicit
Dim fso, shell, root, executable
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
root = fso.GetParentFolderName(WScript.ScriptFullName)
executable = fso.BuildPath(root, "runtime\pythonw.exe")
If Not fso.FileExists(executable) Then
    MsgBox "The application runtime is missing. Extract the entire download before opening the application.", 16, "Notion Calendar Sync"
    WScript.Quit 1
End If
shell.CurrentDirectory = root
shell.Run Chr(34) & executable & Chr(34) & " -I -m notion_calendar_sync.desktop", 0, False
