@echo off
if not exist "%~dp0runtime\pythonw.exe" (
  echo Extract the entire download before starting Notion Calendar Sync.
  pause
  exit /b 1
)
start "" "%~dp0runtime\pythonw.exe" -I -m notion_calendar_sync.desktop
