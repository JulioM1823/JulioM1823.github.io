"""SQLite state, durable observations, write journal, and notification inbox."""
from pathlib import Path
from contextlib import closing
import json
import os
import sqlite3
import time
import uuid

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS links(id INTEGER PRIMARY KEY,mapping TEXT NOT NULL,notion_id TEXT,google_id TEXT,
 base TEXT NOT NULL DEFAULT '{}',notion_version TEXT,google_version TEXT,status TEXT DEFAULT 'active',
 kind TEXT DEFAULT 'single',UNIQUE(mapping,notion_id),UNIQUE(mapping,google_id));
CREATE TABLE IF NOT EXISTS observations(mapping TEXT,side TEXT,item_id TEXT,record TEXT,
 PRIMARY KEY(mapping,side,item_id));
CREATE TABLE IF NOT EXISTS operations(id TEXT PRIMARY KEY,mapping TEXT,link_id INTEGER,side TEXT,action TEXT,
 payload TEXT,status TEXT DEFAULT 'pending',attempts INTEGER DEFAULT 0,next_attempt REAL DEFAULT 0,error TEXT,created REAL);
CREATE INDEX IF NOT EXISTS operations_status ON operations(status,next_attempt);
CREATE TABLE IF NOT EXISTS conflicts(id INTEGER PRIMARY KEY,mapping TEXT,link_id INTEGER,fields TEXT,base TEXT,
 notion TEXT,google TEXT,status TEXT DEFAULT 'open',created REAL);
CREATE INDEX IF NOT EXISTS conflicts_link ON conflicts(link_id,status);
CREATE TABLE IF NOT EXISTS signals(id TEXT PRIMARY KEY,provider TEXT,mapping TEXT,entity TEXT,received REAL);
CREATE TABLE IF NOT EXISTS channels(id TEXT PRIMARY KEY,mapping TEXT,resource_id TEXT,token TEXT,expiration REAL,status TEXT);
"""


class Store:
    def __init__(self, path):
        self.path = Path(path)
        existed = self.path.parent.exists()
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if not existed:
            os.chmod(self.path.parent, 0o700)
        # Sidecars inherit a restrictive creation mask too.
        old = os.umask(0o077)
        try:
            self.db = sqlite3.connect(str(self.path), timeout=30)
            self.db.row_factory = sqlite3.Row
            self.db.execute("PRAGMA journal_mode=WAL")
            self.db.execute("PRAGMA busy_timeout=30000")
            self.db.execute("PRAGMA synchronous=FULL")
            self.db.executescript(SCHEMA)
            os.chmod(self.path, 0o600)
        finally:
            os.umask(old)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        self.db.close()

    def get_meta(self, key, default=None):
        row = self.db.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def set_meta(self, key, value):
        self.db.execute("INSERT INTO meta VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                        (key, json.dumps(value, sort_keys=True)))

    def put_record(self, mapping, side, record):
        self.db.execute("INSERT INTO observations VALUES(?,?,?,?) ON CONFLICT(mapping,side,item_id) "
                        "DO UPDATE SET record=excluded.record", (mapping, side, record.id, record.to_json()))

    def signal(self, provider, mapping="", entity="", signal_id=None):
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO signals VALUES(?,?,?,?,?)",
                            (signal_id or str(uuid.uuid4()), provider, mapping, entity, time.time()))

    def backup(self, path):
        path = Path(path)
        if path.resolve() == self.path.resolve():
            raise ValueError("Backup destination must differ from live database")
        old = os.umask(0o077)
        try:
            with closing(sqlite3.connect(str(path))) as dest:
                self.db.backup(dest)
            os.chmod(path, 0o600)
        finally:
            os.umask(old)
