"""Google desktop OAuth with PKCE, loopback callback, and atomic token files."""
from __future__ import annotations

import base64
import hashlib
import http.server
import json
import os
from pathlib import Path
import secrets
import tempfile
import time
import urllib.parse
import webbrowser

from .http import ProviderError, ReauthRequired, Transport

SCOPES = ('https://www.googleapis.com/auth/calendar.events',
          'https://www.googleapis.com/auth/calendar.calendarlist.readonly')
AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth'
TOKEN_URL = 'https://oauth2.googleapis.com/token'


def secure_write(path: Path, data: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor, temporary = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    try:
        if hasattr(os, 'fchmod'):
            os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, 'w') as output:
            json.dump(data, output)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
        if os.name != 'nt':
            directory = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def load_client(path: Path) -> dict:
    try:
        data = json.loads(Path(path).read_text())['installed']
        if not data.get('client_id'):
            raise KeyError('client_id')
        return data
    except (OSError, ValueError, KeyError, TypeError):
        raise ReauthRequired('Download a Google OAuth Desktop app client JSON into configured client path') from None


def authorize(client_path: Path, token_path: Path, *, open_browser: bool = True,
              port: int = 0, timeout: int = 300, transport: Transport | None = None,
              client_loader=None, token_saver=None, url_callback=None, cancel=None) -> dict:
    client = client_loader() if client_loader else load_client(client_path)
    transport = transport or Transport()
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode()
    state = secrets.token_urlsafe(32)
    result: dict = {}

    class Callback(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urllib.parse.urlsplit(self.path)
            query = urllib.parse.parse_qs(parsed.query)
            if parsed.path != '/oauth/callback' or not secrets.compare_digest(query.get('state', [''])[0], state):
                self.send_error(400, 'Invalid authorization callback')
                return
            if query.get('error'):
                result['error'] = True
            elif query.get('code'):
                result['code'] = query['code'][0]
            else:
                self.send_error(400, 'Missing authorization code')
                return
            body = b'Authorization received. Return to Notion Calendar Sync.'
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *_):
            pass

    with http.server.HTTPServer(('127.0.0.1', port), Callback) as server:
        server.timeout = 1
        redirect = f'http://127.0.0.1:{server.server_port}/oauth/callback'
        query = {'client_id': client['client_id'], 'redirect_uri': redirect, 'response_type': 'code',
                 'scope': ' '.join(SCOPES), 'state': state, 'code_challenge': challenge,
                 'code_challenge_method': 'S256', 'access_type': 'offline', 'prompt': 'consent'}
        url = AUTH_URL + '?' + urllib.parse.urlencode(query)
        # Authorization URL contains no token; must be presented to the interactive operator.
        if url_callback:
            url_callback(url)
        else:
            print('Open this URL in a browser on the computer running authorization:\n' + url, flush=True)
        if open_browser:
            webbrowser.open(url)
        deadline = time.monotonic() + timeout
        while not result and time.monotonic() < deadline:
            if cancel is not None and cancel.is_set():
                raise ReauthRequired('Authorization cancelled')
            server.handle_request()
        if not result.get('code'):
            raise ReauthRequired('Authorization cancelled or timed out; run authorize again')
    token = transport.request('POST', TOKEN_URL, form={'client_id': client['client_id'],
                              'client_secret': client.get('client_secret', ''), 'code': result['code'],
                              'code_verifier': verifier, 'redirect_uri': redirect,
                              'grant_type': 'authorization_code'}, safe=False)
    if not token.get('refresh_token'):
        raise ReauthRequired('Google did not return offline access; revoke this app grant and authorize again')
    token['expires_at'] = time.time() + float(token.get('expires_in', 3600))
    token.pop('id_token', None)
    if token_saver:
        token_saver(token)
    else:
        secure_write(token_path, token)
    return {'authorized': True, 'scopes': token.get('scope', ' '.join(SCOPES))}


class TokenManager:
    def __init__(self, client_path: Path, token_path: Path, transport: Transport | None = None,
                 *, client_loader=None, token_loader=None, token_saver=None):
        self.client_path, self.token_path = Path(client_path), Path(token_path)
        self.transport = transport or Transport()
        self.client_loader, self.token_loader, self.token_saver = client_loader, token_loader, token_saver

    def access_token(self, force: bool = False) -> str:
        try:
            token = self.token_loader() if self.token_loader else json.loads(self.token_path.read_text())
        except (OSError, ValueError):
            raise ReauthRequired('Google token unavailable; run ncs authorize') from None
        if not force and token.get('access_token') and token.get('expires_at', 0) > time.time() + 60:
            return token['access_token']
        if not token.get('refresh_token'):
            raise ReauthRequired('Offline token missing; run ncs authorize')
        client = self.client_loader() if self.client_loader else load_client(self.client_path)
        try:
            refreshed = self.transport.request('POST', TOKEN_URL, form={
                'client_id': client['client_id'], 'client_secret': client.get('client_secret', ''),
                'refresh_token': token['refresh_token'], 'grant_type': 'refresh_token'}, safe=True)
        except ProviderError as exc:
            if exc.status in (400, 401) or exc.code in ('invalid_grant', 'invalid_client'):
                raise ReauthRequired('Google refresh grant expired/revoked; run ncs authorize') from None
            raise
        if not refreshed.get('access_token'):
            raise ReauthRequired('Google refresh response omitted access token; reauthorize')
        token.update(refreshed)
        token['expires_at'] = time.time() + float(refreshed.get('expires_in', 3600))
        if self.token_saver:
            self.token_saver(token)
        else:
            secure_write(self.token_path, token)
        return token['access_token']
