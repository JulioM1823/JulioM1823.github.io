"""Native desktop secrets and per-user paths; no plaintext credential fallback.

macOS uses the login Keychain and Windows uses Generic Credentials for the
current user. These APIs can prompt the OS to unlock/allow access. A locked or
unavailable credential store is an actionable failure, never an instruction to
write a token to the filesystem.
"""
from __future__ import annotations

import base64
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import platform as _platform
import plistlib
import subprocess
import sys
import threading
import uuid

SERVICE_NAME = 'org.notioncalendarsync.desktop'
APP_NAME = 'Notion Calendar Sync'


class SecretStoreError(RuntimeError):
    """Credential access failed; messages never include secret values."""


def _signature(function, argtypes, restype):
    function.argtypes = argtypes
    function.restype = restype
    return function


class _MacKeychain:
    NOT_FOUND = -25300
    DUPLICATE = -25299

    def __init__(self, service, library=None, foundation=None):
        self.service = service.encode('utf-8')
        self.api = library or ctypes.CDLL('/System/Library/Frameworks/Security.framework/Security')
        self.cf = foundation or ctypes.CDLL('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')
        pointer = ctypes.c_void_p
        uint = ctypes.c_uint32
        self.find = _signature(self.api.SecKeychainFindGenericPassword,
            [pointer, uint, ctypes.c_char_p, uint, ctypes.c_char_p,
             ctypes.POINTER(uint), ctypes.POINTER(pointer), ctypes.POINTER(pointer)], ctypes.c_int32)
        self.add = _signature(self.api.SecKeychainAddGenericPassword,
            [pointer, uint, ctypes.c_char_p, uint, ctypes.c_char_p, uint, pointer,
             ctypes.POINTER(pointer)], ctypes.c_int32)
        self.modify = _signature(self.api.SecKeychainItemModifyAttributesAndData,
            [pointer, pointer, uint, pointer], ctypes.c_int32)
        self.remove = _signature(self.api.SecKeychainItemDelete, [pointer], ctypes.c_int32)
        self.free = _signature(self.api.SecKeychainItemFreeContent, [pointer, pointer], ctypes.c_int32)
        self.release = _signature(self.cf.CFRelease, [pointer], None)

    @staticmethod
    def _check(status):
        if status:
            raise SecretStoreError('macOS Keychain access failed (OS status '+str(status)+'). '
                                   'Unlock your login Keychain and allow this application access, then reconnect.')

    def _item(self, key, *, content=False):
        account = key.encode('utf-8')
        length, data, item = ctypes.c_uint32(), ctypes.c_void_p(), ctypes.c_void_p()
        status = self.find(None, len(self.service), self.service, len(account), account,
                           ctypes.byref(length) if content else None,
                           ctypes.byref(data) if content else None, ctypes.byref(item))
        return status, length, data, item

    def get(self, key):
        status, length, data, item = self._item(key, content=True)
        if status == self.NOT_FOUND:
            return None
        self._check(status)
        try:
            try:
                return ctypes.string_at(data, length.value).decode('utf-8')
            except UnicodeError:
                raise SecretStoreError('The Keychain credential is invalid. Reconnect this account.') from None
        finally:
            self.free(None, data)
            if item:
                self.release(item)

    def set(self, key, value):
        status, _, _, item = self._item(key)
        blob = value.encode('utf-8')
        buffer = ctypes.create_string_buffer(blob)
        if status == self.NOT_FOUND:
            account = key.encode('utf-8')
            status = self.add(None, len(self.service), self.service, len(account), account,
                              len(blob), ctypes.cast(buffer, ctypes.c_void_p), ctypes.byref(item))
            if status == self.DUPLICATE:
                # Another callback/process may have inserted it since our read.
                status, _, _, item = self._item(key)
                self._check(status)
                try:
                    self._check(self.modify(item, None, len(blob), ctypes.cast(buffer, ctypes.c_void_p)))
                finally:
                    if item:
                        self.release(item)
                return
        else:
            self._check(status)
            status = self.modify(item, None, len(blob), ctypes.cast(buffer, ctypes.c_void_p))
        try:
            self._check(status)
        finally:
            if item:
                self.release(item)

    def delete(self, key):
        status, _, _, item = self._item(key)
        if status == self.NOT_FOUND:
            return
        self._check(status)
        try:
            self._check(self.remove(item))
        finally:
            if item:
                self.release(item)


class _Credential(ctypes.Structure):
    _fields_ = [('Flags', wintypes.DWORD), ('Type', wintypes.DWORD),
                ('TargetName', wintypes.LPWSTR), ('Comment', wintypes.LPWSTR),
                ('LastWritten', wintypes.FILETIME), ('CredentialBlobSize', wintypes.DWORD),
                ('CredentialBlob', ctypes.POINTER(ctypes.c_ubyte)),
                ('Persist', wintypes.DWORD), ('AttributeCount', wintypes.DWORD),
                ('Attributes', ctypes.c_void_p), ('TargetAlias', wintypes.LPWSTR),
                ('UserName', wintypes.LPWSTR)]


class _WindowsCredentials:
    NOT_FOUND = 1168
    PREFIX = 'ncs-vault-v1:'
    CHUNK_BYTES = 2048
    MAX_SECRET_BYTES = 1024 * 1024

    def __init__(self, service, library=None, last_error=None):
        self.service = service
        self.api = library or ctypes.WinDLL('Advapi32.dll', use_last_error=True)
        self.last_error = last_error or ctypes.get_last_error
        self.read = _signature(self.api.CredReadW,
            [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
             ctypes.POINTER(ctypes.POINTER(_Credential))], wintypes.BOOL)
        self.write = _signature(self.api.CredWriteW,
            [ctypes.POINTER(_Credential), wintypes.DWORD], wintypes.BOOL)
        self.remove = _signature(self.api.CredDeleteW,
            [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD], wintypes.BOOL)
        self.free = _signature(self.api.CredFree, [ctypes.c_void_p], None)

    def _error(self):
        return SecretStoreError('Windows Credential Manager access failed (OS error '+str(self.last_error())+'). '
                                'Sign in to your Windows profile and reconnect this account.')

    def _target(self, key):
        return self.service + ':' + key

    def _read_raw(self, key):
        credential = ctypes.POINTER(_Credential)()
        if not self.read(self._target(key), 1, 0, ctypes.byref(credential)):
            if self.last_error() == self.NOT_FOUND:
                return None
            raise self._error()
        try:
            try:
                return ctypes.string_at(credential.contents.CredentialBlob,
                                        credential.contents.CredentialBlobSize).decode('utf-8')
            except UnicodeError:
                raise SecretStoreError('The saved Windows credential is invalid. Reconnect this account.') from None
        finally:
            self.free(credential)

    def _write_raw(self, key, value):
        blob = value.encode('utf-8')
        # Conservative documented generic-credential limit, also compatible
        # with older Windows installations. Never truncate a refresh token.
        if len(blob) > 2560:
            raise SecretStoreError('Internal credential record exceeds the Windows credential limit.')
        buffer = (ctypes.c_ubyte * len(blob)).from_buffer_copy(blob)
        credential = _Credential(Type=1, TargetName=self._target(key),
                                 CredentialBlobSize=len(blob), CredentialBlob=buffer,
                                 Persist=2, UserName=APP_NAME)
        if not self.write(ctypes.byref(credential), 0):
            raise self._error()

    def _delete_raw(self, key):
        if not self.remove(self._target(key), 1, 0) and self.last_error() != self.NOT_FOUND:
            raise self._error()


    @classmethod
    def _manifest(cls, raw):
        if raw is None or not raw.startswith(cls.PREFIX):
            return None
        try:
            item = json.loads(raw[len(cls.PREFIX):])
            if (not isinstance(item, dict) or set(item) != {'generation', 'count', 'sha256'} or
                not isinstance(item['generation'], str) or len(item['generation']) != 32 or
                any(c not in '0123456789abcdef' for c in item['generation']) or
                type(item['count']) is not int or not 1 <= item['count'] <= 1024 or
                not isinstance(item['sha256'], str) or len(item['sha256']) != 64 or
                any(c not in '0123456789abcdef' for c in item['sha256'])):
                raise ValueError()
            return item
        except (ValueError, KeyError, TypeError):
            raise SecretStoreError('Saved credential manifest is invalid. Reconnect this account.') from None

    @staticmethod
    def _chunk_key(key, manifest, index):
        return key + ':chunk:' + manifest['generation'] + ':' + str(index)

    def _cleanup(self, key, manifest):
        if manifest:
            for index in range(manifest['count']):
                self._delete_raw(self._chunk_key(key, manifest, index))

    def get(self, key):
        # Each credential write is atomic. A reader racing a committed manifest
        # and removal of its old chunks retries the current manifest instead of
        # returning a partial/mixed grant. No token is ever truncated.
        for attempt in range(3):
            raw = self._read_raw(key)
            manifest = self._manifest(raw)
            if manifest is None:
                return raw
            chunks = [self._read_raw(self._chunk_key(key, manifest, i))
                      for i in range(manifest['count'])]
            try:
                if any(chunk is None for chunk in chunks):
                    raise ValueError()
                encoded = ''.join(chunks)
                if len(encoded) > (self.MAX_SECRET_BYTES * 4 // 3 + 4):
                    raise ValueError()
                data = base64.b64decode(encoded, validate=True)
                if (len(data) > self.MAX_SECRET_BYTES or
                    hashlib.sha256(data).hexdigest() != manifest['sha256']):
                    raise ValueError()
                return data.decode('utf-8')
            except (ValueError, UnicodeError):
                if self._read_raw(key) == raw:
                    raise SecretStoreError('Saved credential chunks are incomplete or invalid. Reconnect this account.') from None
        raise SecretStoreError('Credentials changed repeatedly while being read. Retry the connection.')

    def set(self, key, value):
        data = value.encode('utf-8')
        if len(data) > self.MAX_SECRET_BYTES:
            raise SecretStoreError('Credential exceeds the supported 1 MiB vault limit.')
        previous_raw = self._read_raw(key)
        try:
            previous = self._manifest(previous_raw)
        except SecretStoreError:
            # Explicit reconnect can replace a corrupt manifest; do not follow
            # its untrusted chunk references while cleaning up.
            previous = None
        if len(data) <= 2560 and not value.startswith(self.PREFIX):
            self._write_raw(key, value)
            self._cleanup(key, previous)
            return
        encoded = base64.b64encode(data).decode('ascii')
        chunks = [encoded[i:i+self.CHUNK_BYTES] for i in range(0, len(encoded), self.CHUNK_BYTES)]
        manifest = {'generation': uuid.uuid4().hex, 'count': len(chunks),
                    'sha256': hashlib.sha256(data).hexdigest()}
        written = []
        try:
            for index, chunk in enumerate(chunks):
                chunk_key = self._chunk_key(key, manifest, index)
                self._write_raw(chunk_key, chunk)
                written.append(chunk_key)
            # Commit only after every new native credential is complete. On a
            # failed/interrupted pre-commit save the former grant remains usable.
            self._write_raw(key, self.PREFIX + json.dumps(manifest, separators=(',', ':')))
        except Exception:
            for chunk_key in written:
                try:
                    self._delete_raw(chunk_key)
                except SecretStoreError:
                    pass
            raise
        self._cleanup(key, previous)

    def delete(self, key):
        raw = self._read_raw(key)
        try:
            manifest = self._manifest(raw)
        except SecretStoreError:
            manifest = None
        self._delete_raw(key)
        self._cleanup(key, manifest)


class SecretStore:
    """One application namespace in the signed-in OS user's credential store."""
    def __init__(self, service=SERVICE_NAME, *, platform=None, backend=None):
        self._lock = threading.RLock()
        name = platform or _platform.system()
        if backend is not None:
            self._backend = backend
        elif name == 'Darwin':
            self._backend = _MacKeychain(service)
        elif name == 'Windows':
            self._backend = _WindowsCredentials(service)
        else:
            raise SecretStoreError('Desktop credential storage requires macOS or Windows. '
                                   'Use the existing CLI configuration on Linux.')

    @staticmethod
    def _key(key):
        if not isinstance(key, str) or not key or '\x00' in key or len(key.encode('utf-8')) > 256:
            raise ValueError('Credential key must be a nonempty string of at most 256 UTF-8 bytes')

    def get(self, key):
        self._key(key)
        with self._lock:
            return self._backend.get(key)

    def set(self, key, value):
        self._key(key)
        if not isinstance(value, str):
            raise TypeError('Credential value must be a string')
        with self._lock:
            self._backend.set(key, value)

    def delete(self, key):
        self._key(key)
        with self._lock:
            self._backend.delete(key)


class SecretJSONStore:
    """JSON persistence hook for OAuth; the complete grant stays in the OS vault."""
    def __init__(self, secrets, key='google-token'):
        self.secrets, self.key = secrets, key

    def load(self):
        raw = self.secrets.get(self.key)
        if raw is None:
            raise SecretStoreError('Account credentials are unavailable. Connect the account to continue.')
        try:
            data = json.loads(raw)
            if not isinstance(data, dict):
                raise ValueError()
            return data
        except (ValueError, TypeError):
            raise SecretStoreError('Saved account credentials are invalid. Reconnect the account.') from None

    def save(self, data):
        if not isinstance(data, dict):
            raise TypeError('OAuth credential data must be an object')
        self.secrets.set(self.key, json.dumps(data, ensure_ascii=False, separators=(',', ':')))

    def delete(self):
        self.secrets.delete(self.key)


def app_data_dir(*, platform=None, home=None, create=True):
    name = platform or _platform.system()
    base = Path(home) if home is not None else Path.home()
    if name == 'Darwin':
        path = base / 'Library' / 'Application Support' / APP_NAME
    elif name == 'Windows':
        local = Path(os.environ['LOCALAPPDATA']) if home is None and os.environ.get('LOCALAPPDATA') else base/'AppData'/'Local'
        path = local / APP_NAME
    else:
        raise RuntimeError('The desktop application supports macOS and Windows')
    if create:
        path.mkdir(parents=True, exist_ok=True, mode=0o700)
    return path


def startup_command():
    if getattr(sys, 'frozen', False):
        return [sys.executable, '--background']
    isolated = ['-I'] if sys.flags.isolated else []
    return [sys.executable, *isolated, '-m', 'notion_calendar_sync.desktop', '--background']


def _startup_path(home=None):
    return (Path(home) if home is not None else Path.home()) / 'Library' / 'LaunchAgents' / (SERVICE_NAME+'.plist')


def startup_enabled(*, platform=None, home=None):
    name = platform or _platform.system()
    if name == 'Darwin':
        return _startup_path(home).is_file()
    if name == 'Windows':
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Software\Microsoft\Windows\CurrentVersion\Run') as key:
                return bool(winreg.QueryValueEx(key, APP_NAME)[0])
        except FileNotFoundError:
            return False
    raise RuntimeError('Startup at login requires macOS or Windows')


def set_startup(enabled, command=None, *, platform=None, home=None):
    """Change only this user's next-login startup preference; never start a duplicate.

    No credentials are placed in launch arguments, registry values or plist files.
    An already running app keeps running; enabling startup takes effect next login.
    """
    if not isinstance(enabled, bool):
        raise TypeError('Startup preference must be boolean')
    name = platform or _platform.system()
    command = list(command or startup_command())
    if not command or any(not isinstance(part, str) or '\x00' in part for part in command):
        raise ValueError('Invalid application startup command')
    if name == 'Darwin':
        path = _startup_path(home)
        if enabled:
            path.parent.mkdir(parents=True, exist_ok=True)
            contents = {'Label': SERVICE_NAME, 'ProgramArguments': command,
                        'RunAtLoad': True, 'KeepAlive': {'SuccessfulExit': False},
                        'ThrottleInterval': 15, 'ProcessType': 'Background'}
            temporary = path.with_suffix('.tmp')
            try:
                with temporary.open('wb') as f:
                    plistlib.dump(contents, f)
                    f.flush()
                    os.fsync(f.fileno())
                temporary.chmod(0o600)
                temporary.replace(path)
            finally:
                temporary.unlink(missing_ok=True)
        else:
            path.unlink(missing_ok=True)
        return
    if name == 'Windows':
        import winreg
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r'Software\Microsoft\Windows\CurrentVersion\Run') as key:
            if enabled:
                winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, subprocess.list2cmdline(command))
            else:
                try:
                    winreg.DeleteValue(key, APP_NAME)
                except FileNotFoundError:
                    pass
        return
    raise RuntimeError('Startup at login requires macOS or Windows')
