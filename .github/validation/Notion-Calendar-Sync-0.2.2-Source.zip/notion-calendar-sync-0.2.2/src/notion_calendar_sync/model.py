"""Canonical mapped fields. Time range and recurrence form one conflict unit."""
from dataclasses import dataclass, field, asdict
from datetime import date, datetime, timedelta, timezone as dt_timezone
from zoneinfo import ZoneInfo
import json


@dataclass
class Record:
    id: str
    values: dict
    version: str = ""
    deleted: bool = False
    eligible: bool = True
    reason: str = ""
    url: str = ""
    raw: dict = field(default_factory=dict)

    def to_json(self):
        return json.dumps(asdict(self), sort_keys=True, separators=(",", ":"))

    @classmethod
    def from_json(cls, value):
        return cls(**json.loads(value))


def _datetime(value, zone):
    value = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if value.tzinfo is None:
        a = value.replace(tzinfo=zone, fold=0)
        b = value.replace(tzinfo=zone, fold=1)
        if a.astimezone(dt_timezone.utc).astimezone(zone).replace(tzinfo=None) != value:
            raise ValueError("Nonexistent local time during daylight-saving transition")
        if a.utcoffset() != b.utcoffset():
            raise ValueError("Ambiguous local time requires an explicit UTC offset")
        value = a
    return value.astimezone(zone)


def normalize_time(start, end=None, timezone="UTC", default_minutes=60):
    """Normalize to local RFC3339 offsets; date-only end is EXCLUSIVE."""
    zone = ZoneInfo(timezone or "UTC")
    timezone = str(zone)
    if not start:
        raise ValueError("An event requires a start date")
    if len(start) == 10:
        start_date = date.fromisoformat(start)
        end_date = date.fromisoformat(end) if end else start_date + timedelta(days=1)
        if end_date <= start_date:
            raise ValueError("All-day end must be after start")
        return {"start": start_date.isoformat(), "end": end_date.isoformat(),
                "timezone": timezone, "all_day": True}
    if end and len(end) == 10:
        raise ValueError("Mixed timed/date-only range")
    a = _datetime(start, zone)
    b = _datetime(end, zone) if end else (
        a.astimezone(dt_timezone.utc) + timedelta(minutes=default_minutes)).astimezone(zone)
    if b.astimezone(dt_timezone.utc) <= a.astimezone(dt_timezone.utc):
        raise ValueError("Event end must be after start")
    return {"start": a.isoformat(timespec="seconds"), "end": b.isoformat(timespec="seconds"),
            "timezone": timezone, "all_day": False}


def merge_fields(base, notion, google, fields, prefer=None):
    """Three-way merge. Return merged values and conflicting field names.

    A schedule change on either side claims both time and recurrence. Missing
    optional fields are ignored by callers by selecting only mapped fields.
    """
    result, conflicts = {}, []
    groups = [[k] for k in fields if k not in ("time", "recurrence")]
    schedule = [k for k in ("time", "recurrence") if k in fields]
    if schedule:
        groups.append(schedule)
    for group in groups:
        old = {k: base.get(k) for k in group}
        n = {k: notion.get(k) for k in group}
        g = {k: google.get(k) for k in group}
        if n == g:
            chosen = n
        elif n == old:
            chosen = g
        elif g == old:
            chosen = n
        elif prefer:
            chosen = n if prefer == "notion" else g
            conflicts.extend(group)
        else:
            conflicts.extend(group)
            continue
        result.update(chosen)
    return result, conflicts
