"""Journaled, idempotent two-way synchronization without absence-based deletes."""
from __future__ import annotations

import json
import logging
import random
import tempfile
import time
import uuid
from datetime import datetime

from .config import ConfigError
from .http import AccessError, AmbiguousWrite, PreconditionFailed, ProviderError, RetryableError
from .model import Record, merge_fields
from .store import Store

LOG = logging.getLogger(__name__)


def dumps(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _values(record, fields):
    return {k: record.values.get(k) for k in fields}


def _peer(record, side, mapping):
    if side == 'google':
        # Exceptions can inherit a master's metadata. Never link one to its master page.
        if record.raw.get('recurringEventId'):
            return ''
        if record.raw.get('ncs_mapping') != mapping.name:
            return ''
    return record.raw.get('ncs_peer_id', '')


class Engine:
    def __init__(self, config, store, notion, google):
        self.config, self.store = config, store
        self.providers = {'notion': notion, 'google': google}
        self.report = []
        self._dry_run = False

    def _emit(self, action, mapping, **details):
        item = dict(action=action, mapping=mapping.name, **details)
        self.report.append(item)
        return item

    def _mapping(self, name):
        return next(m for m in self.config.mappings if m.name == name)

    def sync(self, dry_run=False, full=False, mapping_names=None):
        """Consume complete scans, journal writes, continue unrelated items on failure.

        Dry run uses an isolated SQLite copy and never executes remote writes.
        No write, cursor, inbox, or conflict change escapes the copy.
        """
        if dry_run:
            with tempfile.TemporaryDirectory(prefix='ncs-dry-run-') as directory:
                with Store(directory + '/dry.sqlite3') as scratch:
                    self.store.db.backup(scratch.db)
                    engine = Engine(self.config, scratch, self.providers['notion'], self.providers['google'])
                    engine._dry_run = True
                    return engine._sync(full, mapping_names)
        return self._sync(full, mapping_names)

    def _sync(self, full=False, mapping_names=None):
        self.report = []
        for mapping in self.config.mappings:
            if mapping_names is not None and mapping.name not in mapping_names:
                continue
            started = time.monotonic()
            try:
                self._guard_identity(mapping)
                for provider in self.providers.values():
                    provider.validate(mapping)
                scans = {}
                for side, provider in self.providers.items():
                    cursor = self.store.get_meta(f'cursor:{mapping.name}:{side}')
                    scan = provider.scan(mapping, cursor, full=full)
                    if not scan.complete:
                        raise ProviderError('Incomplete provider scan; no changes applied')
                    scans[side] = scan
                touched = set()
                with self.store.db:
                    for side, scan in scans.items():
                        for record in scan.records:
                            old = self.store.db.execute('SELECT record FROM observations WHERE mapping=? AND side=? AND item_id=?',
                                                        (mapping.name, side, record.id)).fetchone()
                            changed = not old or self._changed(Record.from_json(old[0]), record)
                            if changed or full:
                                touched.add((side, record.id))
                            if changed:
                                # Checkpoint dirty work atomically with the cursor. A
                                # process death after this commit must not hide a change.
                                self.store.db.execute(
                                    f"UPDATE links SET status='dirty' WHERE mapping=? AND {side}_id=? AND status='active'",
                                    (mapping.name, record.id))
                                self.store.set_meta(f'dirty:{mapping.name}:{side}:{record.id}', True)
                            self.store.put_record(mapping.name, side, record)
                        self.store.set_meta(f'cursor:{mapping.name}:{side}', scan.cursor)
                for side, scan in scans.items():
                    if getattr(scan, 'full_membership', full):
                        seen_ids = {r.id for r in scan.records}
                        for row in self.store.db.execute(f"SELECT {side}_id,status FROM links WHERE mapping=? AND status!='deleted' AND {side}_id IS NOT NULL", (mapping.name,)):
                            if row[0] not in seen_ids:
                                if side == 'notion' and row['status'] == 'paused':
                                    previous = self.store.db.execute('SELECT record FROM observations WHERE mapping=? AND side=? AND item_id=?', (mapping.name, side, row[0])).fetchone()
                                    if previous and Record.from_json(previous[0]).raw.get('ncs_out_of_scope'):
                                        # The filtered query will positively show
                                        # it if it returns to scope. Absence is
                                        # expected and never deletion evidence.
                                        continue
                                touched.add((side, row[0]))
                # Signed Notion notifications identify the page and bypass query indexing lag.
                for signal in self.store.db.execute("SELECT entity FROM signals WHERE provider='notion' AND (mapping='' OR mapping=?)", (mapping.name,)):
                    if signal[0]:
                        try:
                            current = self.providers['notion'].get(mapping, signal[0])
                            # Integration may receive notifications about other shared databases.
                            parent = current.raw.get('parent', {})
                            source = parent.get('data_source_id')
                            if source and source.replace('-', '') != mapping.notion_data_source.replace('-', ''):
                                continue
                            with self.store.db:
                                self.store.put_record(mapping.name, 'notion', current)
                            touched.add(('notion', current.id))
                        except ProviderError:
                            # Keep diagnostic; reconciliation will retry access without deleting.
                            self._emit('unavailable', mapping, side='notion', item_id=signal[0])
                if not self._dry_run:
                    for op in list(self.store.db.execute("SELECT * FROM operations WHERE mapping=? AND status IN ('pending','inflight','retry','ambiguous') AND next_attempt<=? ORDER BY created", (mapping.name, time.time()))):
                        self._execute(mapping, op)
                # Adopt only explicit stable IDs, before creating any new records.
                self._adopt(mapping)
                links = list(self.store.db.execute('SELECT * FROM links WHERE mapping=? ORDER BY id', (mapping.name,)))
                for link in links:
                    if link['status'] == 'deleted':
                        continue
                    # Ineligible linked records stay paused until a scan observes
                    # a change or a full reconciliation checks them again. Missing
                    # membership is already in touched, so access/trash is checked.
                    if (not full and link['status'] in ('paused', 'historical-unavailable') and
                        ('notion', link['notion_id']) not in touched and
                        ('google', link['google_id']) not in touched and
                        not self.store.db.execute("SELECT 1 FROM operations WHERE link_id=? AND status IN ('pending','inflight','retry','ambiguous')", (link['id'],)).fetchone()):
                        continue
                    # Stable manual conflicts need no per-item reads on every
                    # poll. Changed observations and full reconciliation revisit
                    # them; explicit CLI resolution always fetches both peers.
                    if (not full and ('notion', link['notion_id']) not in touched and
                        ('google', link['google_id']) not in touched and
                        self.store.db.execute("SELECT 1 FROM conflicts WHERE link_id=? AND status='open'", (link['id'],)).fetchone() and
                        not self.store.db.execute("SELECT 1 FROM operations WHERE link_id=? AND status IN ('pending','inflight','retry','ambiguous')", (link['id'],)).fetchone()):
                        continue
                    if full and self._unchanged_full(mapping, link, scans):
                        continue
                    if (full or link['status'] != 'active' or not json.loads(link['base']) or
                        ('notion', link['notion_id']) in touched or ('google', link['google_id']) in touched or
                        self._observed_values_differ(mapping, link) or
                        self.store.db.execute("SELECT 1 FROM operations WHERE link_id=? AND status!='done' AND status!='cancelled'", (link['id'],)).fetchone()):
                        self._process_safe(mapping, link['id'])
                # Remaining unmatched records were positively returned at least once.
                # Fetch each source again before creating to reject stale cached observations.
                for side in ('notion', 'google'):
                    column = side + '_id'
                    records = list(self.store.db.execute(f'SELECT o.record FROM observations o LEFT JOIN links l ON l.mapping=o.mapping AND l.{column}=o.item_id WHERE o.mapping=? AND o.side=? AND l.id IS NULL', (mapping.name, side)))
                    for row in records:
                        observed = Record.from_json(row[0])
                        dirty_key = f'dirty:{mapping.name}:{side}:{observed.id}'
                        if observed.deleted or (not full and not observed.eligible and (side, observed.id) not in touched and not self.store.get_meta(dirty_key)):
                            continue
                        # Creation timestamps are immutable. Old unlinked records
                        # cannot become automatic imports, so avoid an API GET on
                        # every poll; fresh scans still discover explicit markers.
                        if not _peer(observed, side, mapping) and not self._allow_initial_import(mapping, observed, side):
                            self._emit('link_required', mapping, side=side, item_id=observed.id,
                                       reason='Pre-existing item has no verified stable link; automatic import disabled by import_since')
                            continue
                        try:
                            current = self.providers[side].get(mapping, observed.id)
                            with self.store.db:
                                self.store.db.execute('DELETE FROM meta WHERE key=?', (dirty_key,))
                            if current.deleted:
                                continue
                            if not current.eligible:
                                self._emit('paused', mapping, side=side, item_id=current.id, reason=current.reason)
                                continue
                            if side == 'google' and current.raw.get('ncs_mapping') not in (None, '', mapping.name):
                                self._emit('unsupported', mapping, side=side, item_id=current.id, reason='Owned by another mapping')
                                continue
                            if _peer(current, side, mapping):
                                # A stable identity exists but couldn't be safely adopted. Do not clone it.
                                self._emit('link_required', mapping, side=side, item_id=current.id)
                                continue
                            if not self._allow_initial_import(mapping, current, side):
                                self._emit('link_required', mapping, side=side, item_id=current.id, reason='Pre-existing item has no verified stable link; automatic import disabled by import_since')
                                continue
                            if self._dry_run:
                                self._emit('create', mapping, side='google' if side == 'notion' else 'notion', source_id=current.id)
                                continue
                            with self.store.db:
                                cur = self.store.db.execute(f'INSERT INTO links(mapping,{column},status,kind) VALUES(?,?,?,?)',
                                                            (mapping.name, current.id, 'linking', self._kind(current)))
                                self.store.put_record(mapping.name, side, current)
                            self._process_safe(mapping, cur.lastrowid)
                        except (ProviderError, ValueError) as exc:
                            with self.store.db:
                                self.store.set_meta(dirty_key, True)
                            self._emit('error', mapping, side=side, item_id=observed.id, error=type(exc).__name__, reason=str(exc))
                if not self._dry_run:
                    with self.store.db:
                        self.store.set_meta(f'last_success:{mapping.name}', time.time())
                        self.store.set_meta(f'last_error:{mapping.name}', None)
            except (ProviderError, ValueError, ConfigError) as exc:
                self._emit('error', mapping, error=type(exc).__name__, reason=str(exc))
                if not self._dry_run:
                    with self.store.db:
                        self.store.set_meta(f'last_error:{mapping.name}', {'type': type(exc).__name__, 'message': str(exc), 'at': time.time()})
            if not self._dry_run:
                with self.store.db:
                    self.store.set_meta(f'last_processing_seconds:{mapping.name}', time.monotonic() - started)
        return self.report

    @staticmethod
    def _allow_initial_import(mapping, record, side):
        cutoff = getattr(mapping, 'import_since', '')
        if not cutoff:
            return True
        created = record.raw.get('created_time' if side == 'notion' else 'created')
        try:
            return bool(created) and datetime.fromisoformat(created.replace('Z', '+00:00')) >= datetime.fromisoformat(cutoff.replace('Z', '+00:00'))
        except (ValueError, TypeError):
            return False

    def _observed_values_differ(self, mapping, link):
        base = json.loads(link['base'])
        for side in ('notion', 'google'):
            row = self.store.db.execute('SELECT record FROM observations WHERE mapping=? AND side=? AND item_id=?',
                                        (mapping.name, side, link[side + '_id'])).fetchone()
            if row and _values(Record.from_json(row[0]), mapping.mapped_fields) != {k: base.get(k) for k in mapping.mapped_fields}:
                return True
        return False

    def _unchanged_full(self, mapping, link, scans):
        conflict = self.store.db.execute("SELECT * FROM conflicts WHERE link_id=? AND status='open' ORDER BY id DESC LIMIT 1", (link['id'],)).fetchone()
        if conflict:
            if (link['status'] not in ('active', 'dirty') or
                self.store.db.execute("SELECT 1 FROM operations WHERE link_id=? AND status IN ('pending','inflight','retry','ambiguous')", (link['id'],)).fetchone()):
                return False
            # A complete full listing already fetched both provider values.
            # Preserve an unchanged conflict without duplicating both GETs.
            # An omitted/changed peer always falls through to direct checks.
            for side in ('notion', 'google'):
                record = next((r for r in scans[side].records if r.id == link[side + '_id']), None)
                if record is None or self._changed(Record.from_json(conflict[side]), record):
                    return False
            return True
        if link['status'] != 'active':
            return False
        base = json.loads(link['base'])
        if not base:
            return False
        for side, other in (('notion', 'google'), ('google', 'notion')):
            record = next((r for r in scans[side].records if r.id == link[side + '_id']), None)
            if not record or record.deleted or not record.eligible or _values(record, mapping.mapped_fields) != base:
                return False
            peer = next((r for r in scans[other].records if r.id == link[other + '_id']), None)
            if not self._metadata_complete(mapping, side, record, link[other + '_id'], peer.url if peer else ''):
                return False
        return True

    @staticmethod
    def _changed(a, b):
        return (a.values, a.deleted, a.eligible, a.raw.get('ncs_peer_id'), a.raw.get('ncs_mapping')) != (
            b.values, b.deleted, b.eligible, b.raw.get('ncs_peer_id'), b.raw.get('ncs_mapping'))

    @staticmethod
    def _kind(record):
        if record.raw.get('recurringEventId'):
            return 'exception'
        return 'series' if record.values.get('recurrence') else 'single'

    def _guard_identity(self, mapping):
        key = f'identity:{mapping.name}'
        identity = [mapping.notion_data_source.replace('-', ''), mapping.google_calendar]
        old = self.store.get_meta(key)
        if old is not None and old != identity:
            raise ConfigError('Mapping endpoints changed under an existing name; use a new mapping name/state after reviewing old links')
        with self.store.db:
            self.store.set_meta(key, identity)

    def _adopt(self, mapping):
        for side, other in (('notion', 'google'), ('google', 'notion')):
            for row in list(self.store.db.execute('SELECT record FROM observations WHERE mapping=? AND side=?', (mapping.name, side))):
                record = Record.from_json(row[0])
                peer_id = _peer(record, side, mapping)
                if not peer_id or record.deleted:
                    continue
                linked = self.store.db.execute(f'SELECT * FROM links WHERE mapping=? AND {side}_id=?', (mapping.name, record.id)).fetchone()
                if linked:
                    continue
                try:
                    record = self.providers[side].get(mapping, record.id)
                    if _peer(record, side, mapping) != peer_id:
                        continue
                    peer = self.providers[other].get(mapping, peer_id)
                    if other == 'google' and peer.raw.get('ncs_mapping') not in (None, '', mapping.name):
                        raise ProviderError('Stable link points to event owned by another mapping')
                    # Google IDs are case-sensitive; Notion UUID spellings differ only by dashes.
                    reciprocal = _peer(peer, other, mapping)
                    if reciprocal and reciprocal.replace('-', '') != record.id.replace('-', ''):
                        self._emit('identity_conflict', mapping, side=side, item_id=record.id)
                        continue
                    if other == 'notion':
                        parent = peer.raw.get('parent', {}).get('data_source_id')
                        if parent and parent.replace('-', '') != mapping.notion_data_source.replace('-', ''):
                            raise ProviderError('Stable link points outside configured data source')
                    occupied = self.store.db.execute(f'SELECT id FROM links WHERE mapping=? AND {other}_id=?', (mapping.name, peer.id)).fetchone()
                    if occupied:
                        self._emit('identity_conflict', mapping, side=side, item_id=record.id)
                        continue
                    n, g = (record, peer) if side == 'notion' else (peer, record)
                    with self.store.db:
                        self.store.db.execute('INSERT INTO links(mapping,notion_id,google_id,kind) VALUES(?,?,?,?)',
                                              (mapping.name, n.id, g.id, self._kind(g)))
                        self.store.put_record(mapping.name, other, peer)
                    self._emit('link', mapping, notion_id=n.id, google_id=g.id)
                except ProviderError as exc:
                    self._emit('link_required', mapping, side=side, item_id=record.id, error=type(exc).__name__)

    def _process_safe(self, mapping, link_id):
        try:
            self._process(mapping, link_id)
            # A write response can include a concurrent user edit. Reconcile
            # once more when observed values differ from the common base.
            # A bounded pass handles creation/linking races without a busy loop;
            # the same persisted comparison recovers after a crash here.
            fresh = self.store.db.execute('SELECT * FROM links WHERE id=?', (link_id,)).fetchone()
            if (not self._dry_run and fresh['status'] == 'active' and
                self._observed_values_differ(mapping, fresh) and
                not self.store.db.execute("SELECT 1 FROM conflicts WHERE link_id=? AND status='open'", (link_id,)).fetchone() and
                not self.store.db.execute("SELECT 1 FROM operations WHERE link_id=? AND status IN ('pending','inflight','retry','ambiguous')", (link_id,)).fetchone()):
                self._process(mapping, link_id)
        except (ProviderError, ValueError) as exc:
            row = self.store.db.execute('SELECT status FROM links WHERE id=?', (link_id,)).fetchone()
            if isinstance(exc, AccessError) and row and row['status'] == 'historical-unavailable':
                # A reviewed legacy identity can be retained even while its
                # peer is inaccessible. Do not manufacture a tombstone, create
                # a replacement, or turn a permanent hold into a hot retry loop.
                self._emit('historical_unavailable', mapping, link_id=link_id, http_status=exc.status)
                return
            if not self._dry_run:
                with self.store.db:
                    self.store.db.execute("UPDATE links SET status='retry' WHERE id=? AND status!='deleted'", (link_id,))
            self._emit('error', mapping, link_id=link_id, error=type(exc).__name__, reason=str(exc))

    def _process(self, mapping, link_id, prefer=None):
        link = self.store.db.execute('SELECT * FROM links WHERE id=?', (link_id,)).fetchone()
        if self.store.db.execute("SELECT 1 FROM operations WHERE link_id=? AND status IN ('pending','inflight','retry','ambiguous')", (link_id,)).fetchone():
            self._emit('pending', mapping, link_id=link_id)
            return
        current = {}
        order = ('google', 'notion') if link['status'] == 'historical-unavailable' else ('notion', 'google')
        for side in order:
            if link[side + '_id']:
                try:
                    current[side] = self.providers[side].get(mapping, link[side + '_id'])
                except AccessError as exc:
                    observed = self.store.db.execute('SELECT record FROM observations WHERE mapping=? AND side=? AND item_id=?',
                                                     (mapping.name, side, link[side + '_id'])).fetchone()
                    tombstone = Record.from_json(observed[0]) if observed else None
                    # A specific event GET can be 410 after events.list positively
                    # returned status=cancelled. The explicit payload is evidence;
                    # the 410 alone remains insufficient. A 403/404 never qualifies.
                    if side != 'google' or exc.status != 410 or not tombstone or not tombstone.deleted:
                        raise
                    current[side] = tombstone
                with self.store.db:
                    self.store.put_record(mapping.name, side, current[side])
        if len(current) == 1:
            side, source = next(iter(current.items()))
            if source.deleted or not source.eligible:
                self._pause(mapping, link_id, 'Creation source is deleted or ineligible')
                return
            target = 'google' if side == 'notion' else 'notion'
            self._emit('create', mapping, link_id=link_id, side=target, source_id=source.id)
            if self._dry_run:
                return
            op = self._enqueue(mapping, link_id, target, 'create',
                               {'values': _values(source, mapping.mapped_fields), 'source_side': side,
                                'source_id': source.id, 'source_expected': _values(source, mapping.mapped_fields)})
            if self._execute(mapping, op):
                self._process(mapping, link_id, prefer=prefer)
            return
        if len(current) != 2:
            raise ProviderError('Incomplete persistent link')
        n, g = current['notion'], current['google']
        if any(r.raw.get('ncs_out_of_scope') for r in current.values()):
            self._pause(mapping, link_id, 'Linked item moved outside configured scope')
            return
        self._check_identity(mapping, link, current)
        base = json.loads(link['base'])
        policy = prefer or (mapping.conflict_policy if mapping.conflict_policy != 'manual' else None)
        # Deletion-vs-edit is always a visible conflict; no automatic restoration.
        if n.deleted or g.deleted:
            if n.deleted and g.deleted:
                self._tombstone(link_id, mapping)
                return
            deleted_side, live_side = ('notion', 'google') if n.deleted else ('google', 'notion')
            live = current[live_side]
            if not live.eligible:
                self._pause(mapping, link_id, live.reason)
                return
            changed = _values(live, mapping.mapped_fields) != {k: base.get(k) for k in mapping.mapped_fields}
            if changed:
                self._conflict(mapping, link, ['deletion'], n, g, base)
                return
            self._emit('archive', mapping, side=live_side, link_id=link_id)
            if self._dry_run:
                return
            op = self._enqueue(mapping, link_id, live_side, 'archive',
                               {'source_side': deleted_side, 'source_id': current[deleted_side].id,
                                'expected': _values(live, mapping.mapped_fields)})
            if self._execute(mapping, op):
                self._tombstone(link_id, mapping)
            return
        # Clearing a date, moving a page, disabling opt-in, or unsupported event type pauses BOTH directions.
        if not n.eligible or not g.eligible:
            self._pause(mapping, link_id, n.reason if not n.eligible else g.reason)
            return
        merged, conflicts = merge_fields(base, n.values, g.values, mapping.mapped_fields, prefer=policy)
        if conflicts:
            self._conflict(mapping, link, conflicts, n, g, base, status='resolved-auto' if policy else 'open')
            if not policy:
                return
        if self.store.db.execute("SELECT 1 FROM conflicts WHERE link_id=? AND status='open'", (link_id,)).fetchone() and not policy:
            # An unchanged conflict remains paused; other records keep syncing.
            self._emit('conflict_pending', mapping, link_id=link_id)
            return
        for side, other in (('notion', 'google'), ('google', 'notion')):
            patch = {k: v for k, v in merged.items() if current[side].values.get(k) != v}
            if not patch:
                continue
            self._emit('update', mapping, side=side, link_id=link_id, fields=list(patch))
            if self._dry_run:
                continue
            op = self._enqueue(mapping, link_id, side, 'update',
                               {'patch': patch, 'expected': _values(current[side], patch),
                                'source_side': other, 'source_id': current[other].id,
                                'source_expected': {k: v for k, v in patch.items()}})
            if not self._execute(mapping, op):
                return
        if not self._dry_run:
            # Both planned values are now durable remotely. New later edits differ from this base.
            with self.store.db:
                self.store.db.execute("UPDATE links SET base=?,notion_version=?,google_version=?,status='active',kind=? WHERE id=?",
                                      (dumps(merged), n.version, g.version, self._kind(g), link_id))
            self._links_metadata(mapping, link_id)

    def _pause(self, mapping, link_id, reason):
        if not self._dry_run:
            with self.store.db:
                self.store.db.execute("UPDATE links SET status='paused' WHERE id=? AND status!='deleted'", (link_id,))
        self._emit('paused', mapping, link_id=link_id, reason=reason)

    def _check_identity(self, mapping, link, records):
        n, g = records.get('notion'), records.get('google')
        if n and n.raw.get('ncs_out_of_scope'):
            raise PreconditionFailed('Notion page is outside the configured source/category scope')
        if n and n.raw.get('ncs_peer_id') not in (None, '', link['google_id']):
            raise PreconditionFailed('Notion stable identity changed; explicit link review required')
        if g:
            if g.raw.get('ncs_mapping') not in (None, '', mapping.name):
                raise PreconditionFailed('Google event is owned by another mapping')
            peer = g.raw.get('ncs_peer_id')
            expected = link['notion_id'] or ''
            if peer and peer.replace('-', '') != expected.replace('-', ''):
                inherited = False
                if g.raw.get('recurringEventId'):
                    master = self.providers['google'].get(mapping, g.raw['recurringEventId'])
                    inherited = (master.raw.get('ncs_mapping') == mapping.name and
                                 master.raw.get('ncs_peer_id') == peer)
                if not inherited:
                    raise PreconditionFailed('Google stable identity changed; explicit link review required')

    def _links_metadata(self, mapping, link_id):
        link = self.store.db.execute('SELECT * FROM links WHERE id=?', (link_id,)).fetchone()
        for side, other in (('notion', 'google'), ('google', 'notion')):
            row = self.store.db.execute('SELECT record FROM observations WHERE mapping=? AND side=? AND item_id=?',
                                        (mapping.name, side, link[side + '_id'])).fetchone()
            peer = self.store.db.execute('SELECT record FROM observations WHERE mapping=? AND side=? AND item_id=?',
                                         (mapping.name, other, link[other + '_id'])).fetchone()
            record = Record.from_json(row[0]) if row else None
            peer_url = Record.from_json(peer[0]).url if peer else ''
            if record and self._metadata_complete(mapping, side, record, link[other + '_id'], peer_url):
                continue
            op = self._enqueue(mapping, link_id, side, 'links', {'peer_id': link[other + '_id'], 'peer_url': peer_url})
            if not self._execute(mapping, op):
                return

    @staticmethod
    def _metadata_complete(mapping, side, record, peer_id, peer_url):
        if record.raw.get('ncs_peer_id') != peer_id:
            return False
        if side == 'notion':
            name = mapping.properties.get('google_url')
            if name and peer_url:
                props = record.raw.get('properties', {})
                prop = props.get(name) or next((p for p in props.values() if p.get('id') == name), {})
                return prop.get('url') == peer_url
        else:
            if record.raw.get('ncs_mapping') != mapping.name:
                return False
            source = record.raw.get('source', {})
            if peer_url and (not source or source.get('title') == 'Notion (NCS)'):
                return source == {'url': peer_url, 'title': 'Notion (NCS)'}
        return True

    def _tombstone(self, link_id, mapping):
        if not self._dry_run:
            with self.store.db:
                self.store.db.execute("UPDATE links SET status='deleted' WHERE id=?", (link_id,))
                self.store.db.execute("UPDATE conflicts SET status='resolved-deleted' WHERE link_id=? AND status='open'", (link_id,))
        self._emit('deleted', mapping, link_id=link_id)

    def _conflict(self, mapping, link, fields, n, g, base, status='open'):
        old = self.store.db.execute("SELECT * FROM conflicts WHERE link_id=? AND status='open' ORDER BY id DESC LIMIT 1", (link['id'],)).fetchone()
        snapshots = (dumps(fields), dumps(base), n.to_json(), g.to_json())
        if old and (old['fields'], old['base'], old['notion'], old['google']) == snapshots:
            conflict_id = old['id']
        else:
            with self.store.db:
                if old:
                    self.store.db.execute("UPDATE conflicts SET status='superseded' WHERE id=?", (old['id'],))
                conflict_id = self.store.db.execute('INSERT INTO conflicts(mapping,link_id,fields,base,notion,google,status,created) VALUES(?,?,?,?,?,?,?,?)',
                                                       (mapping.name, link['id'], *snapshots, status, time.time())).lastrowid
        self._emit('conflict', mapping, link_id=link['id'], conflict_id=conflict_id, fields=fields, policy=status)

    def _enqueue(self, mapping, link_id, side, action, payload):
        op_id = uuid.uuid4().hex
        with self.store.db:
            self.store.db.execute('INSERT INTO operations(id,mapping,link_id,side,action,payload,created) VALUES(?,?,?,?,?,?,?)',
                                  (op_id, mapping.name, link_id, side, action, dumps(payload), time.time()))
        return self.store.db.execute('SELECT * FROM operations WHERE id=?', (op_id,)).fetchone()

    def _execute(self, mapping, op):
        payload = json.loads(op['payload'])
        side, action = op['side'], op['action']
        provider = self.providers[side]
        link = self.store.db.execute('SELECT * FROM links WHERE id=?', (op['link_id'],)).fetchone()
        retried = op['status'] in ('inflight', 'retry', 'ambiguous')
        if action == 'create' and (op['status'] in ('inflight', 'ambiguous') or
                                   (side == 'google' and op['attempts'] > 0)):
            payload['recovery_only'] = True
            with self.store.db:
                self.store.db.execute('UPDATE operations SET payload=? WHERE id=?', (dumps(payload), op['id']))
        recovery_only = bool(payload.get('recovery_only'))
        # Persist inflight BEFORE every remote write. A crash cannot turn a possibly
        # completed Notion POST into a fresh POST on the next run.
        try:
            source = None
            if payload.get('source_side'):
                try:
                    source = self.providers[payload['source_side']].get(mapping, payload['source_id'])
                except AccessError as exc:
                    observed = self.store.db.execute('SELECT record FROM observations WHERE mapping=? AND side=? AND item_id=?',
                                                     (mapping.name, payload['source_side'], payload['source_id'])).fetchone()
                    known = Record.from_json(observed[0]) if observed else None
                    if action != 'archive' or payload['source_side'] != 'google' or exc.status != 410 or not known or not known.deleted:
                        raise
                    source = known
            if action == 'create':
                if not recovery_only:
                    self._check_identity(mapping, link, {payload['source_side']: source})
                if not recovery_only and (source.deleted or not source.eligible or _values(source, payload['source_expected']) != payload['source_expected']):
                    return self._cancel(op)
                with self.store.db:
                    self.store.db.execute("UPDATE operations SET status='inflight',attempts=attempts+1 WHERE id=?", (op['id'],))
                result = provider.create(mapping, payload['values'], op['id'], payload['source_id'], recovery_only=recovery_only)
                # Recovered archived creation is a positive tombstone; never untrash it.
                with self.store.db:
                    self.store.db.execute(f'UPDATE links SET {side}_id=?,base=?,status=? WHERE id=?',
                                          (result.id, dumps(payload['values']), 'active', op['link_id']))
                    self.store.put_record(mapping.name, side, result)
                    self.store.db.execute("UPDATE operations SET status='done',error=NULL WHERE id=?", (op['id'],))
                return True
            try:
                target = provider.get(mapping, link[side + '_id'])
            except AccessError as exc:
                if not (action == 'archive' and retried and exc.status == 410 and source and source.deleted):
                    raise
                target = None
            records = {side: target} if target else {}
            if source:
                records[payload['source_side']] = source
            self._check_identity(mapping, link, records)
            if action == 'update':
                if target.deleted or not target.eligible:
                    return self._cancel(op)
                if _values(target, payload['patch']) == payload['patch']:
                    result = target
                else:
                    if (_values(target, payload['expected']) != payload['expected'] or source.deleted or not source.eligible or
                        _values(source, payload['source_expected']) != payload['source_expected']):
                        return self._cancel(op)
                    with self.store.db:
                        self.store.db.execute("UPDATE operations SET status='inflight',attempts=attempts+1 WHERE id=?", (op['id'],))
                    result = provider.update(mapping, target.id, payload['patch'], target.version)
                    if _values(result, payload['patch']) != payload['patch']:
                        raise PreconditionFailed('Provider did not retain the requested mapped values')
            elif action == 'archive':
                if not source.deleted:
                    return self._cancel(op)
                if target and target.deleted:
                    result = target
                else:
                    if target and (not target.eligible or _values(target, payload['expected']) != payload['expected']):
                        return self._cancel(op)
                    with self.store.db:
                        self.store.db.execute("UPDATE operations SET status='inflight',attempts=attempts+1 WHERE id=?", (op['id'],))
                    result = provider.archive(mapping, link[side + '_id'], target.version if target else '')
            elif action == 'links':
                if target.deleted or not target.eligible:
                    return self._cancel(op)
                with self.store.db:
                    self.store.db.execute("UPDATE operations SET status='inflight',attempts=attempts+1 WHERE id=?", (op['id'],))
                result = provider.set_links(mapping, target.id, payload['peer_id'], payload.get('peer_url', ''))
            else:
                raise ProviderError('Unknown journal operation')
            with self.store.db:
                self.store.put_record(mapping.name, side, result)
                self.store.db.execute("UPDATE operations SET status='done',error=NULL WHERE id=?", (op['id'],))
                if action == 'archive':
                    self.store.db.execute("UPDATE links SET status='deleted' WHERE id=?", (op['link_id'],))
            return True
        except PreconditionFailed:
            self._cancel(op)
            self._emit('replan', mapping, link_id=op['link_id'])
            return False
        except ProviderError as exc:
            state = 'ambiguous' if isinstance(exc, AmbiguousWrite) or recovery_only else 'retry'
            delay = min(300, 2 ** min(op['attempts'] + 1, 8)) + random.uniform(0, 1)
            with self.store.db:
                self.store.db.execute('UPDATE operations SET status=?,error=?,next_attempt=? WHERE id=?',
                                      (state, type(exc).__name__, time.time() + delay, op['id']))
            self._emit(state, mapping, operation_id=op['id'], link_id=op['link_id'], error=type(exc).__name__, reason=str(exc))
            return False

    def _cancel(self, op):
        with self.store.db:
            self.store.db.execute("UPDATE operations SET status='cancelled' WHERE id=?", (op['id'],))
            self.store.db.execute("UPDATE links SET status='retry' WHERE id=? AND status!='deleted'", (op['link_id'],))
        return False

    def resolve(self, conflict_id, choice):
        self.report = []
        if choice not in ('notion', 'google'):
            raise ValueError('Resolution must prefer notion or google')
        conflict = self.store.db.execute("SELECT * FROM conflicts WHERE id=? AND status='open'", (conflict_id,)).fetchone()
        if not conflict:
            raise ValueError('Open conflict not found')
        mapping = self._mapping(conflict['mapping'])
        for provider in self.providers.values():
            provider.validate(mapping)
        link = self.store.db.execute('SELECT * FROM links WHERE id=?', (conflict['link_id'],)).fetchone()
        n = self.providers['notion'].get(mapping, link['notion_id'])
        g = self.providers['google'].get(mapping, link['google_id'])
        old_n, old_g = Record.from_json(conflict['notion']), Record.from_json(conflict['google'])
        if (n.values, n.deleted, g.values, g.deleted) != (old_n.values, old_n.deleted, old_g.values, old_g.deleted):
            self._conflict(mapping, link, json.loads(conflict['fields']), n, g, json.loads(conflict['base']))
            raise ValueError('Item changed after conflict was recorded; inspect the new conflict before resolving')
        if n.deleted or g.deleted:
            chosen = n if choice == 'notion' else g
            if not chosen.deleted:
                raise ValueError('Resolution would restore a deleted item; restore it explicitly in its provider, then explicitly link the restored pair')
            live_side = 'google' if n.deleted else 'notion'
            live, deleted = (g, n) if n.deleted else (n, g)
            op = self._enqueue(mapping, link['id'], live_side, 'archive',
                               {'source_side': choice, 'source_id': deleted.id, 'expected': _values(live, mapping.mapped_fields)})
            if not self._execute(mapping, op):
                return self.report
            self._tombstone(link['id'], mapping)
        else:
            # Mark current conflict resolved only after a successful checked merge.
            self._process(mapping, link['id'], prefer=choice)
            if any(x['action'] in ('retry', 'ambiguous', 'pending', 'replan') for x in self.report):
                return self.report
        with self.store.db:
            self.store.db.execute("UPDATE conflicts SET status=? WHERE id=?", ('resolved-' + choice, conflict_id))
        return self.report

    def link(self, mapping_name, notion_id, google_id, dry_run=True):
        mapping = self._mapping(mapping_name)
        for provider in self.providers.values():
            provider.validate(mapping)
        n = self.providers['notion'].get(mapping, notion_id)
        g = self.providers['google'].get(mapping, google_id)
        if n.deleted or g.deleted or not n.eligible or not g.eligible:
            raise ValueError('Explicit link requires two live eligible records')
        occupied = list(self.store.db.execute('SELECT * FROM links WHERE mapping=? AND (notion_id=? OR google_id=?)', (mapping_name, n.id, g.id)))
        if occupied and not (len(occupied) == 1 and occupied[0]['notion_id'] == n.id and occupied[0]['google_id'] == g.id):
            raise ValueError('One of the items already belongs to a different link')
        self.report = []
        _, conflicts = merge_fields({}, n.values, g.values, mapping.mapped_fields)
        self._emit('link', mapping, notion_id=n.id, google_id=g.id, conflict_fields=conflicts, dry_run=dry_run)
        if dry_run:
            return self.report
        with self.store.db:
            if occupied:
                link_id = occupied[0]['id']
                self.store.db.execute("UPDATE links SET status='active',base='{}' WHERE id=?", (link_id,))
                self.store.db.execute("UPDATE conflicts SET status='superseded' WHERE link_id=? AND status='open'", (link_id,))
            else:
                link_id = self.store.db.execute('INSERT INTO links(mapping,notion_id,google_id,kind) VALUES(?,?,?,?)',
                                                (mapping_name, n.id, g.id, self._kind(g))).lastrowid
            self.store.put_record(mapping_name, 'notion', n)
            self.store.put_record(mapping_name, 'google', g)
        self._process(mapping, link_id)
        return self.report
