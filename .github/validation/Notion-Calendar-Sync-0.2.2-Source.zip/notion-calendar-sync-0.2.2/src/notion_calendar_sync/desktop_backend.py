"""Desktop orchestration: native secrets, immutable previews and one engine writer.

No production credentials/configuration are discovered or imported implicitly.
All desktop state lives in its own per-user directory, separate from the Pi.
"""
from __future__ import annotations

from collections import Counter
from contextlib import closing
from dataclasses import asdict
import hashlib
import json
import math
import os
from pathlib import Path
import re
import secrets
import sqlite3
import threading
import time
from urllib.parse import quote, urlsplit
import uuid

from .config import Config, Mapping, ConfigError
from .engine import Engine
from .http import ProviderError, ReauthRequired
from .oauth import TokenManager, authorize, secure_write
from .providers import NotionProvider, GoogleProvider
from .service import StateLock, SyncService, report_has_errors
from .store import Store


TYPES = {'title': 'title', 'date': 'date', 'description': 'rich_text', 'location': 'rich_text',
         'timezone': 'rich_text', 'recurrence': 'rich_text', 'google_url': 'url',
         'google_event_id': 'rich_text', 'sync_enabled': 'checkbox'}
INTEGRATION_PROPERTIES = {'NCS Event ID': 'rich_text', 'NCS Time Zone': 'rich_text',
                          'Recurrence': 'rich_text', 'Calendar Link': 'url'}


def notion_id(value):
    value = str(value).strip()
    if '://' in value:
        value = urlsplit(value).path
    found = re.findall(r'(?<![a-fA-F0-9])([a-fA-F0-9]{32}|[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12})(?![a-fA-F0-9])', value)
    if len(found) != 1:
        raise ValueError('Enter a Notion database/data-source ID or its page URL, or use database search.')
    return str(uuid.UUID(found[0]))


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def suggest_mapping(schema):
    props = schema.get('properties', {})
    names = {'title': ['task', 'name', 'title', 'event'], 'date': ['date', 'when', 'schedule'],
             'description': ['note', 'notes', 'description'], 'location': ['location', 'place'],
             'timezone': ['ncs time zone', 'time zone', 'timezone'], 'recurrence': ['recurrence'],
             'google_url': ['gcal link', 'google calendar', 'calendar link'],
             'google_event_id': ['ncs event id'], 'sync_enabled': ['sync enabled']}
    result, used = {}, set()
    for field, kind in TYPES.items():
        candidates = [n for n, p in props.items() if p.get('type') == kind and n not in used]
        selected = next((n for preferred in names[field] for n in candidates if n.casefold() == preferred), '')
        if not selected and field in ('title', 'date') and len(candidates) == 1:
            selected = candidates[0]
        result[field] = selected
        if selected:
            used.add(selected)
    return result


class PreviewProvider:
    """Cache read results and prohibit every mutating adapter method in preview."""
    def __init__(self, provider):
        self.provider, self.records = provider, {}

    def validate(self, *a, **kw):
        return self.provider.validate(*a, **kw)

    def scan(self, *a, **kw):
        scan = self.provider.scan(*a, **kw)
        self.records.update({r.id: r for r in scan.records})
        return scan

    def get(self, *a, **kw):
        record = self.provider.get(*a, **kw)
        self.records[record.id] = record
        return record

    def _blocked(self, *a, **kw):
        raise RuntimeError('A preview attempted a remote write; synchronization was blocked.')

    create = update = archive = set_links = _blocked


def _snapshot(providers):
    return {side: {id: {'values': r.values, 'deleted': r.deleted, 'eligible': r.eligible,
                        'peer': r.raw.get('ncs_peer_id'), 'mapping': r.raw.get('ncs_mapping'),
                        'out_of_scope': r.raw.get('ncs_out_of_scope')}
                   for id, r in p.records.items()} for side, p in providers.items()}


def _local_signature(store):
    return _digest({table: [dict(r) for r in store.db.execute('SELECT * FROM '+table+' ORDER BY 1')]
                    for table in ('links', 'operations', 'conflicts')})


class DesktopController:
    def __init__(self, directory=None, secret_store=None, *, provider_factory=None, autorun=True):
        from .desktop_platform import SecretStore, app_data_dir
        self.directory = Path(directory) if directory is not None else app_data_dir()
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.secrets = secret_store if secret_store is not None else SecretStore()
        self.provider_factory = provider_factory
        self._operation = threading.RLock()
        self._state_lock = threading.Lock()
        self._stop = threading.Event()
        self._auth_cancel = threading.Event()
        self._thread = None
        self._preview = None
        self._error = ''
        self._closed = False
        self._logs = []
        self._settings_path = self.directory/'desktop-settings.json'
        self._saved = {}
        if self._settings_path.exists():
            try:
                self._saved = json.loads(self._settings_path.read_text())
                if self._saved.get('settings'):
                    self._config(self._saved['settings'])
            except (ValueError, TypeError, KeyError):
                self._error = 'Saved setup is invalid. Review your mapping and generate a new preview.'
                self._saved = {}
        if autorun and self._saved.get('approved') and not self._saved.get('paused', True):
            self.resume()

    def _note(self, text):
        with self._state_lock:
            self._logs = (self._logs+[text])[-50:]

    def _secret_json(self, key):
        value = self.secrets.get(key)
        if not value:
            raise ReauthRequired('Connect '+('Google' if key.startswith('google') else 'Notion')+' in Account setup.')
        return json.loads(value)

    def _providers(self, config):
        if self.provider_factory:
            return self.provider_factory(config)
        tokens = TokenManager(config.google_client_path, config.google_token_path,
                              client_loader=lambda: self._secret_json('google_client')['installed'],
                              token_loader=lambda: self._secret_json('google_token'),
                              token_saver=lambda t: self.secrets.set('google_token', json.dumps(t)))
        return (NotionProvider(config, token_loader=lambda: self.secrets.get('notion_token')),
                GoogleProvider(config, tokens=tokens))

    def _config(self, settings):
        allowed = {'notion_data_source', 'google_calendar', 'timezone', 'properties', 'default_duration_minutes',
                   'notion_select_property', 'notion_select_value', 'poll_seconds', 'reconcile_seconds'}
        if set(settings) - allowed:
            raise ConfigError('Unsupported desktop mapping option.')
        source = notion_id(settings.get('notion_data_source', ''))
        calendar = str(settings.get('google_calendar', '')).strip()
        if not calendar or calendar == 'primary':
            raise ConfigError('Select a specific writable Google calendar from the list.')
        props = {k: v for k, v in settings.get('properties', {}).items() if v}
        if set(props) - set(TYPES) or any(not isinstance(v, str) for v in props.values()):
            raise ConfigError('Select compatible Notion properties for the fields.')
        if not all(props.get(k) for k in ('title', 'date', 'google_event_id')):
            raise ConfigError('Title, Date range and Google event identity are required.')
        if len(set(props.values())) != len(props):
            raise ConfigError('Each field needs a different Notion property.')
        from zoneinfo import ZoneInfo
        zone = settings.get('timezone', 'America/Denver')
        try:
            ZoneInfo(zone)
        except (ValueError, KeyError):
            raise ConfigError('Choose an IANA time zone, for example America/Denver.') from None
        poll, reconcile = float(settings.get('poll_seconds', 45)), float(settings.get('reconcile_seconds', 900))
        duration = int(settings.get('default_duration_minutes', 60))
        if not math.isfinite(poll) or not math.isfinite(reconcile) or poll < 5 or reconcile < poll or not 1 <= duration <= 10080:
            raise ConfigError('Invalid polling interval or default event duration.')
        category, value = settings.get('notion_select_property', ''), settings.get('notion_select_value', '')
        if bool(category) != bool(value):
            raise ConfigError('Select both a category property and its value, or neither.')
        key = _digest([source, calendar])[:24]
        mapping = Mapping('desktop', source, calendar, timezone=zone, properties=props,
                          default_duration_minutes=duration, poll_seconds=poll, reconcile_seconds=reconcile,
                          notion_select_property=category, notion_select_value=value)
        return Config(state_path=self.directory/('sync-'+key+'.sqlite3'), mappings=[mapping])

    def _discovery(self):
        return self._providers(Config())

    def connect_notion(self, token):
        with self._operation:
            self.pause()
            if not isinstance(token, str) or not token.strip():
                raise ValueError('Paste the internal Notion integration token.')
            # Validate through its own provider, without exposing it in an env var.
            provider = NotionProvider(Config(), token_loader=lambda: token.strip())
            provider._request('GET', '/users/me')
            self.secrets.set('notion_token', token.strip())
            self._preview = None
            self._note('Notion connection validated.')
            return {'connected': True}

    def connect_google(self, client_json_text):
        with self._operation:
            self.pause()
            try:
                data = json.loads(client_json_text)
                if not isinstance(data.get('installed'), dict) or not data['installed'].get('client_id'):
                    raise ValueError()
            except (ValueError, TypeError):
                raise ValueError('Choose the JSON downloaded for a Google Desktop app OAuth client.') from None
            old = self.secrets.get('google_client')
            self.secrets.set('google_client', json.dumps(data))
            if old != json.dumps(data):
                self.secrets.delete('google_token')
            self._preview = None
            return {'client_ready': True}

    def authorize_google(self):
        with self._operation:
            self.pause()
            self._auth_cancel.clear()
            result = authorize(None, None, client_loader=lambda: self._secret_json('google_client')['installed'],
                               token_saver=lambda t: self.secrets.set('google_token', json.dumps(t)),
                               url_callback=lambda _: self._note('Finish Google authorization in your browser.'),
                               cancel=self._auth_cancel)
            self._preview = None
            self._note('Google authorization completed.')
            return result

    def databases(self, query=''):
        provider, _ = self._discovery()
        rows, cursor, seen = [], None, set()
        while True:
            body = {'page_size': 100, 'filter': {'property': 'object', 'value': 'data_source'}}
            if query:
                body['query'] = query
            if cursor:
                body['start_cursor'] = cursor
            result = provider._request('POST', '/search', body=body, safe=True)
            if not isinstance(result.get('results'), list) or not isinstance(result.get('has_more'), bool):
                raise ProviderError('Notion returned an incomplete search result.')
            for row in result['results']:
                title = ''.join(p.get('plain_text', p.get('text', {}).get('content', '')) for p in row.get('title', []))
                rows.append({'id': row['id'], 'name': title or 'Untitled data source', 'kind': 'data_source',
                             'database_id': row.get('parent', {}).get('database_id', '')})
            if not result.get('has_more'):
                return rows
            cursor = result.get('next_cursor')
            if not cursor or cursor in seen:
                raise ProviderError('Notion search pagination was incomplete. Please retry.')
            seen.add(cursor)

    def data_sources(self, identifier):
        id = notion_id(identifier)
        provider, _ = self._discovery()
        from .http import AccessError
        try:
            data = provider._request('GET', '/databases/'+quote(id, safe=''))
        except AccessError:
            data = provider._request('GET', '/data_sources/'+quote(id, safe=''))
        if data.get('object') == 'data_source':
            title = ''.join(p.get('plain_text', p.get('text', {}).get('content', '')) for p in data.get('title', []))
            return [{'id': data['id'], 'name': title or 'Untitled data source'}]
        sources = data.get('data_sources')
        if not isinstance(sources, list) or not sources:
            raise ProviderError('No data sources found. Grant the Notion connection access to this database.')
        return [{'id': s['id'], 'name': s.get('name') or 'Untitled data source'} for s in sources]

    def calendars(self):
        _, provider = self._discovery()
        rows, cursor, seen = [], None, set()
        while True:
            path = '/users/me/calendarList?maxResults=250&minAccessRole=writer'
            if cursor:
                path += '&pageToken='+quote(cursor, safe='')
            result = provider._request('GET', path)
            if not isinstance(result.get('items'), list):
                raise ProviderError('Google returned an incomplete calendar list. Please retry.')
            for row in result['items']:
                if row.get('accessRole') in ('owner', 'writer'):
                    rows.append({'id': row['id'], 'name': row.get('summaryOverride') or row.get('summary') or row['id']})
            cursor = result.get('nextPageToken')
            if not cursor:
                return rows
            if cursor in seen:
                raise ProviderError('Google calendar pagination was incomplete. Please retry.')
            seen.add(cursor)

    def schema(self, source_id):
        n, _ = self._discovery()
        return n._request('GET', '/data_sources/'+quote(notion_id(source_id), safe=''))

    suggest_mapping = staticmethod(suggest_mapping)

    def create_properties(self, source_id, confirmed=False):
        if not confirmed:
            raise ValueError('Confirm creating the integration properties first.')
        with self._operation:
            self.pause()
            schema = self.schema(source_id)
            properties = schema.get('properties', {})
            for name, kind in INTEGRATION_PROPERTIES.items():
                if name in properties and properties[name].get('type') != kind:
                    raise ValueError('An existing integration property has an incompatible type: '+name)
            additions = {name: {kind: {}} for name, kind in INTEGRATION_PROPERTIES.items() if name not in properties}
            if additions:
                n, _ = self._discovery()
                n._request('PATCH', '/data_sources/'+quote(notion_id(source_id), safe=''), body={'properties': additions}, safe=False)
            self._preview = None
            return self.schema(source_id)

    def _collect_preview(self, settings):
        config = self._config(settings)
        n, g = self._providers(config)
        providers = {'notion': PreviewProvider(n), 'google': PreviewProvider(g)}
        with StateLock(config.state_path), Store(config.state_path) as store:
            local = _local_signature(store)
            report = Engine(config, store, providers['notion'], providers['google']).sync(dry_run=True, full=True)
            for row in report:
                id = row.get('source_id') or row.get('item_id')
                record = next((p.records[id] for p in providers.values() if id in p.records), None)
                if record:
                    row['title'] = record.values.get('title', '')
            signature = _digest({'settings': settings, 'records': _snapshot(providers), 'local': local})
        return {'report': report, 'summary': dict(Counter(r['action'] for r in report)), 'signature': signature, 'local_signature': local,
                'blocked': report_has_errors(report), 'config': config}

    def preview(self, settings):
        with self._operation:
            self.pause()
            # Normalize via JSON to avoid mutable references from the UI.
            settings = json.loads(json.dumps(settings))
            result = self._collect_preview(settings)
            self._preview = dict(result, preview_id=secrets.token_urlsafe(24), settings=settings, created=time.monotonic())
            return {k: v for k, v in self._preview.items() if k not in ('signature', 'config', 'local_signature')}

    def approve(self, preview_id):
        with self._operation:
            if self._closed:
                raise RuntimeError('The application is closing.')
            preview = self._preview
            if not preview or not secrets.compare_digest(str(preview_id), preview['preview_id']):
                raise ValueError('Generate a new preview before starting synchronization.')
            if preview['blocked'] or time.monotonic()-preview['created'] > 600:
                raise ValueError('This preview expired or has errors. Generate a fresh preview.')
            fresh = self._collect_preview(preview['settings'])
            if self._closed:
                raise RuntimeError('The application is closing.')
            if fresh['blocked'] or fresh['signature'] != preview['signature']:
                self._preview = None
                raise ValueError('An item changed since the preview. Review a fresh preview before continuing.')
            config = fresh['config']
            with StateLock(config.state_path), Store(config.state_path) as store:
                if _local_signature(store) != fresh['local_signature']:
                    self._preview = None
                    raise ValueError('Local sync state changed. Generate a fresh preview.')
                store.backup(self.directory/('before-first-sync-'+str(time.time_ns())+'.sqlite3'))
            if self._settings_path.exists():
                secure_write(self.directory/('settings-backup-'+str(time.time_ns())+'.json'), self._saved)
            self._saved = {'settings': preview['settings'], 'approved': True, 'paused': False}
            secure_write(self._settings_path, self._saved)
            self._preview = None
            self._launch()
            return {'approved': True, 'running': True}

    def _launch(self):
        if self._closed:
            raise RuntimeError('The application is closing.')
        if self._thread and self._thread.is_alive():
            return
        config = self._config(self._saved['settings'])
        self._stop = threading.Event()
        self._error = ''
        def run():
            while not self._stop.is_set():
                try:
                    n, g = self._providers(config)
                    with StateLock(config.state_path), Store(config.state_path) as store:
                        self._error = ''
                        SyncService(config, store, Engine(config, store, n, g), g, stop=self._stop).run()
                except Exception as exc:
                    self._error = 'Synchronization stopped ('+type(exc).__name__+'). Retrying; reconnect accounts if access was revoked.'
                    self._note(self._error)
                if not self._stop.is_set():
                    self._stop.wait(5)
        self._thread = threading.Thread(target=run, name='ncs-desktop-worker', daemon=True)
        self._thread.start()

    def pause(self):
        with self._operation:
            self._stop.set()
            if self._thread and self._thread.is_alive():
                self._thread.join(120)
                if self._thread.is_alive():
                    raise RuntimeError('A provider request is still finishing. Retry pause in a moment.')
            if self._saved.get('approved'):
                self._saved['paused'] = True
                secure_write(self._settings_path, self._saved)
            return {'running': False}

    def resume(self):
        with self._operation:
            if not self._saved.get('approved'):
                raise ValueError('Complete setup and approve a preview before starting synchronization.')
            self._saved['paused'] = False
            secure_write(self._settings_path, self._saved)
            self._launch()
            return {'running': True}

    def conflicts(self):
        if not self._saved.get('settings'):
            return []
        config = self._config(self._saved['settings'])
        if not config.state_path.exists():
            return []
        with closing(sqlite3.connect('file:'+str(config.state_path)+'?mode=ro', uri=True)) as db:
            db.row_factory = sqlite3.Row
            rows = [dict(r) for r in db.execute("SELECT * FROM conflicts WHERE status='open' ORDER BY id")]
        for row in rows:
            for k in ('base', 'notion', 'google', 'fields'):
                row[k] = json.loads(row[k])
        return rows

    def resolve(self, id, side):
        with self._operation:
            if side not in ('notion', 'google'):
                raise ValueError('Choose Notion or Google.')
            self.pause()
            config = self._config(self._saved['settings'])
            n, g = self._providers(config)
            with StateLock(config.state_path), Store(config.state_path) as store:
                store.backup(self.directory/('before-conflict-resolution-'+str(time.time_ns())+'.sqlite3'))
                report = Engine(config, store, n, g).resolve(int(id), side)
                row = store.db.execute('SELECT status FROM conflicts WHERE id=?', (int(id),)).fetchone()
                resolved = bool(row and row['status'] != 'open')
            return {'resolved': resolved, 'running': False,
                    'pending': not resolved, 'report': report}

    def state(self):
        with self._state_lock:
            data = {'configured': bool(self._saved.get('settings')), 'approved': bool(self._saved.get('approved')),
                    'running': bool(self._thread and self._thread.is_alive()), 'error': self._error,
                    'settings': self._saved.get('settings', {}), 'logs': list(self._logs), 'status': {}}
        for kind, key in [('notion', 'notion_token'), ('google', 'google_token')]:
            try:
                data['connected_'+kind] = bool(self.secrets.get(key))
            except Exception:
                data['connected_'+kind] = False
                data['error'] = 'Unlock your operating-system credential store and reconnect accounts.'
        try:
            from .desktop_platform import startup_enabled
            data['autostart'] = startup_enabled()
        except (OSError, RuntimeError):
            data['autostart'] = False
        if data['configured']:
            config = self._config(data['settings'])
            if config.state_path.exists():
                try:
                    from .cli import status
                    with closing(sqlite3.connect('file:'+str(config.state_path)+'?mode=ro', uri=True)) as db:
                        db.row_factory = sqlite3.Row
                        class ReadOnly:
                            pass
                        store = ReadOnly()
                        store.db = db
                        data['status'] = status(store)
                except sqlite3.Error:
                    data['error'] = 'Sync state is busy; status will refresh shortly.'
        return data

    def diagnostics(self, destination):
        state = self.state()
        # Allowlist only aggregate numbers and error types: never export database
        # IDs, event values, raw logs, exceptions, credential values or cursors.
        status = state.get('status', {})
        safe = {'version': __import__('notion_calendar_sync').__version__,
                'configured': state['configured'], 'running': state['running'],
                'connected_notion': state['connected_notion'], 'connected_google': state['connected_google'],
                'counts': {k: status.get(k, []) for k in ('links', 'operations', 'conflicts')},
                'database_bytes': status.get('database_bytes', 0)}
        secure_write(Path(destination), safe)
        return {'exported': True}

    def set_autostart(self, enabled):
        from .desktop_platform import set_startup
        set_startup(bool(enabled))
        return {'enabled': bool(enabled)}

    def close(self):
        self._closed = True
        self._auth_cancel.set()
        # Closing the process must preserve the user's pause/resume preference.
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(120)
