"""Small HTTPS JSON transport with conservative write/retry semantics."""
from __future__ import annotations

import email.utils
import json
import random
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib
from typing import Any, Callable


class ProviderError(RuntimeError):
    def __init__(self, message: str, status: int = 0, code: str = ''):
        super().__init__(message)
        self.status, self.code = status, code


class AccessError(ProviderError):
    """Access denied or record not visible; never proof of deletion."""


class RetryableError(ProviderError):
    pass


class PreconditionFailed(ProviderError):
    pass


class AmbiguousWrite(ProviderError):
    """A request may have committed remotely; do not blindly replay it."""


class ReauthRequired(ProviderError):
    pass


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # API endpoints should not redirect. Never forward bearer credentials.
        raise ProviderError('Unexpected API redirect', code)


class Transport:
    def __init__(self, *, timeout: float = 15, retries: int = 3,
                 min_interval: float = 0, opener=None, sleep=time.sleep,
                 monotonic=time.monotonic, random_uniform=random.uniform):
        self.timeout, self.retries, self.min_interval = timeout, retries, min_interval
        self.opener = opener or urllib.request.build_opener(_NoRedirect())
        self.sleep, self.monotonic, self.random_uniform = sleep, monotonic, random_uniform
        self._next = 0.0

    @staticmethod
    def _read_json(response, limit=8 * 1024 * 1024):
        """Bound both wire and expanded sizes; never accept partial gzip/JSON.

        urllib does not decompress responses. Negotiate gzip explicitly while
        retaining the identical full provider document and its safety limit.
        """
        raw = response.read(limit + 1)
        if len(raw) > limit:
            raise ValueError('API response exceeds safety size limit')
        encoding = (getattr(response, 'headers', {}).get('Content-Encoding', '') or '').strip().lower()
        if encoding == 'gzip':
            try:
                decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
                raw = decoder.decompress(raw, limit + 1)
                if len(raw) > limit or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
                    raise ValueError('Invalid or oversized compressed API response')
            except zlib.error:
                raise ValueError('Invalid compressed API response') from None
        elif encoding not in ('', 'identity'):
            raise ValueError('Unsupported API response encoding')
        return json.loads(raw) if raw else {}

    def request(self, method: str, url: str, *, headers: dict | None = None,
                body: dict | None = None, form: dict | None = None,
                safe: bool | None = None, retry_auth: Callable | None = None) -> dict:
        if urllib.parse.urlsplit(url).scheme != 'https':
            raise ProviderError('API transport requires HTTPS')
        method = method.upper()
        if safe is None:
            safe = method in {'GET', 'DELETE'}
        payload = None
        # Google requires gzip in both Accept-Encoding and User-Agent.
        outgoing = {'Accept': 'application/json', 'Accept-Encoding': 'gzip',
                    'User-Agent': 'notion-calendar-sync/1.0 (gzip)'}
        outgoing.update(headers or {})
        if body is not None:
            payload = json.dumps(body, ensure_ascii=False).encode()
            outgoing['Content-Type'] = 'application/json'
        if form is not None:
            payload = urllib.parse.urlencode(form).encode()
            outgoing['Content-Type'] = 'application/x-www-form-urlencoded'
        for attempt in range(self.retries + 1):
            delay = self._next - self.monotonic()
            if delay > 0:
                self.sleep(delay)
            self._next = self.monotonic() + self.min_interval
            try:
                request = urllib.request.Request(url, data=payload, headers=outgoing, method=method)
                with self.opener.open(request, timeout=self.timeout) as response:
                    return self._read_json(response)
            except urllib.error.HTTPError as exc:
                status = exc.code
                try:
                    data = self._read_json(exc, 65536)
                except (ValueError, OSError):
                    data = {}
                finally:
                    exc.close()
                code = data.get('code', '')
                err = data.get('error', {})
                if isinstance(err, str):
                    code = err
                elif isinstance(err, dict):
                    code = (err.get('errors') or [{}])[0].get('reason', code)
                if status == 401:
                    raise ReauthRequired('Authentication rejected; reauthorize account', status, code) from None
                if status == 412:
                    raise PreconditionFailed('Remote item changed during write', status, code) from None
                if status in (403, 404):
                    if status != 403 or code not in {'rateLimitExceeded', 'userRateLimitExceeded', 'quotaExceeded'}:
                        raise AccessError('Remote item unavailable or access denied', status, code) from None
                retryable = status in (429, 500, 502, 503, 504, 529) or (status == 403 and code in {'rateLimitExceeded', 'userRateLimitExceeded', 'quotaExceeded'})
                if code == 'public_api_request_blocked':
                    raise AccessError('API access is restricted by provider', status, code) from None
                if retryable:
                    # A rate-limit rejection is definitive; a server error on a create is ambiguous.
                    if not safe and status not in (429, 529, 403):
                        raise AmbiguousWrite('Remote write outcome unknown; recover by stable identifier', status, code) from None
                    wait = self._retry_after(exc.headers.get('Retry-After'), data)
                    self._next = max(self._next, self.monotonic() + wait)
                    if attempt < self.retries:
                        delay = max(wait, min(30, 0.5 * 2 ** attempt) + self.random_uniform(0, 0.5))
                        self.sleep(delay)
                        continue
                    raise RetryableError('Provider temporarily unavailable or rate limited', status, code) from None
                raise ProviderError(f'API request rejected (HTTP {status})', status, code) from None
            except (urllib.error.URLError, TimeoutError, socket.timeout, ConnectionError, OSError) as exc:
                if not safe:
                    raise AmbiguousWrite('Connection interrupted during write; outcome unknown') from None
                if attempt < self.retries:
                    self.sleep(min(30, 0.5 * 2 ** attempt) + self.random_uniform(0, 0.5))
                    continue
                raise RetryableError('Provider connection failed after bounded retries') from None
            except (ValueError, UnicodeError):
                if not safe:
                    raise AmbiguousWrite('Invalid response after write; outcome unknown') from None
                raise RetryableError('Provider returned an invalid JSON response') from None
        raise RetryableError('Retry limit exceeded')

    @staticmethod
    def _retry_after(value: str | None, data: dict) -> float:
        if value:
            try:
                return max(0, float(value))
            except ValueError:
                try:
                    return max(0, email.utils.parsedate_to_datetime(value).timestamp() - time.time())
                except (ValueError, TypeError, OverflowError):
                    pass
        try:
            return max(0, float(data.get('additional_data', {}).get('retry_after', 0)))
        except (ValueError, TypeError):
            return 0
