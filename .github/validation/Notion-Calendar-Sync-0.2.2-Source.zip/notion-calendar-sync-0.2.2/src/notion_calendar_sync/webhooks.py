"""Small, authenticated signal-only webhook receiver.

HTTP must be terminated by a trusted HTTPS reverse proxy. Payloads never directly
change an event; the worker retrieves the official provider's current state.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import logging
import os
from pathlib import Path
import sqlite3
import threading
import time

MAX_BODY = 256 * 1024
MAX_EVENT_AGE = 7 * 24 * 3600
LOG = logging.getLogger(__name__)


class WebhookReceiver:
    def __init__(self, config, *, bootstrap_output: Path | None = None, now=time.time):
        self.config = config
        self.now = now
        self.bootstrap_output = Path(bootstrap_output) if bootstrap_output else None
        self.verified = threading.Event()
        self._bootstrap_lock = threading.Lock()

    def _connection(self):
        from .store import Store
        store = Store(self.config.state_path)
        store.db.execute("CREATE TABLE IF NOT EXISTS webhook_receipts (id TEXT PRIMARY KEY, received REAL NOT NULL)")
        store.db.execute("CREATE INDEX IF NOT EXISTS webhook_receipts_received ON webhook_receipts(received)")
        store.db.commit()
        return store

    def _enqueue(self, provider, identifier, mapping="", entity=""):
        """Receipt and signal are committed atomically before acknowledging delivery."""
        with self._connection() as store:
            now = self.now()
            with store.db:
                store.db.execute("DELETE FROM webhook_receipts WHERE received < ?", (now - MAX_EVENT_AGE - 3600,))
                cursor = store.db.execute("INSERT OR IGNORE INTO webhook_receipts(id,received) VALUES (?,?)", (identifier, now))
                if cursor.rowcount:
                    store.db.execute("INSERT OR IGNORE INTO signals(id,provider,mapping,entity,received) VALUES (?,?,?,?,?)", (identifier, provider, mapping, entity, now))
        return 204

    def accept(self, path: str, headers, raw: bytes):
        if len(raw) > MAX_BODY:
            return 413
        # Query strings and extra paths deliberately fail closed.
        if path == "/webhooks/notion":
            return self._notion(headers, raw)
        if path == "/webhooks/google":
            return self._google(headers, raw)
        return 404

    def _notion(self, headers, raw):
        try:
            payload = json.loads(raw)
        except (ValueError, UnicodeError):
            return 400
        if not isinstance(payload, dict):
            return 400
        if "verification_token" in payload:
            # This first packet cannot be authenticated. A candidate file is
            # captured only during an explicit CLI bootstrap, never trusted here.
            if self.bootstrap_output is None:
                return 403
            token = payload["verification_token"]
            if not isinstance(token, str) or not token or len(token) > 2048 or "\n" in token or "\r" in token:
                return 400
            with self._bootstrap_lock:
                try:
                    fd = os.open(self.bootstrap_output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                except FileExistsError:
                    return 409
                with os.fdopen(fd, "w") as handle:
                    handle.write(token + "\n")
                    handle.flush()
                    os.fsync(handle.fileno())
                self.verified.set()
            return 204
        secret = os.environ.get(self.config.notion_webhook_secret_env, "")
        if not secret:
            return 503
        signature = headers.get("X-Notion-Signature", "")
        expected = "sha256=" + hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected):
            return 403
        subscription = getattr(self.config, "notion_webhook_subscription", "")
        workspace = getattr(self.config, "notion_webhook_workspace", "")
        if subscription and payload.get("subscription_id") != subscription:
            return 403
        if workspace and payload.get("workspace_id") != workspace:
            return 403
        identifier = payload.get("id")
        timestamp = payload.get("timestamp")
        if not isinstance(identifier, str) or not identifier or len(identifier) > 256 or not isinstance(timestamp, str):
            return 400
        try:
            event_time = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
            if event_time.tzinfo is None:
                return 400
            age = self.now() - event_time.timestamp()
        except (ValueError, OverflowError):
            return 400
        # Multi-hour provider retries remain acceptable. Dedupe prevents replay
        # inside this window; older delivery is covered by reconciliation.
        if age < -300 or age > MAX_EVENT_AGE:
            return 400
        entity = payload.get("entity", {})
        if not isinstance(entity, dict) or not isinstance(entity.get("id", ""), str):
            return 400
        return self._enqueue("notion", "notion:" + identifier, entity=entity.get("id", ""))

    def _google(self, headers, raw):
        if raw:
            return 400
        identifier = headers.get("X-Goog-Channel-Id", "")
        token = headers.get("X-Goog-Channel-Token", "")
        resource = headers.get("X-Goog-Resource-Id", "")
        state = headers.get("X-Goog-Resource-State", "")
        message = headers.get("X-Goog-Message-Number", "")
        if state not in {"sync", "exists", "not_exists"} or not message.isdigit() or len(message) > 30:
            return 400
        if not identifier or len(identifier) > 64 or not resource or len(resource) > 512 or not token:
            return 403
        with self._connection() as store:
            row = store.db.execute("SELECT * FROM channels WHERE id=?", (identifier,)).fetchone()
            if row is None:
                return 403
            # sqlite Row is the Store contract; support tuple with explicit columns
            # only via our own SELECT to make the receiver independently testable.
            if not isinstance(row, sqlite3.Row):
                raise RuntimeError("Store must use sqlite3.Row")
            if not hmac.compare_digest(str(row["token"]), token):
                return 403
            if row["status"] == "pending" and not row["resource_id"]:
                # Initial sync can arrive before watch returns. Do not learn/trust
                # a resource id from a webhook, even one with the channel token.
                return 204 if state == "sync" else 503
            if row["status"] != "active" or row["expiration"] <= self.now():
                return 403
            if not hmac.compare_digest(str(row["resource_id"]), resource):
                return 403
            mapping = row["mapping"]
        return self._enqueue("google", f"google:{identifier}:{message}", mapping=mapping)


class WebhookHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 32

    def process_request(self, request, client_address):
        if not self._slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()

    def __init__(self, address, receiver):
        self.receiver = receiver
        self._slots = threading.BoundedSemaphore(16)
        super().__init__(address, WebhookHandler)


class WebhookHandler(BaseHTTPRequestHandler):
    server_version = "ncs"
    sys_version = ""

    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def do_POST(self):
        if self.headers.get("Transfer-Encoding"):
            self._reply(400)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self._reply(400)
            return
        if length < 0 or length > MAX_BODY:
            self._reply(413)
            return
        try:
            raw = self.rfile.read(length)
            if len(raw) != length:
                self._reply(400)
                return
            status = self.server.receiver.accept(self.path, self.headers, raw)
        except (TimeoutError, ConnectionError):
            return
        except Exception as error:
            # Never log request headers, bodies, signatures, candidate tokens,
            # or provider object content.
            LOG.error("Webhook persistence failed (%s)", type(error).__name__)
            status = 503
        self._reply(status)

    def do_GET(self):
        self._reply(404)

    def _reply(self, status):
        self.send_response(status)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, format, *args):
        # The base logger includes an attacker-controlled URL.
        return


def start_server(config, *, bootstrap_output=None):
    receiver = WebhookReceiver(config, bootstrap_output=bootstrap_output)
    server = WebhookHTTPServer((config.webhook_host, config.webhook_port), receiver)
    thread = threading.Thread(target=server.serve_forever, name="ncs-webhooks", daemon=True)
    thread.start()
    return server, receiver
