"""Strict, secret-free TOML configuration."""
from dataclasses import dataclass, field, fields
from pathlib import Path
from datetime import datetime
import tomllib
from urllib.parse import urlparse
from zoneinfo import ZoneInfo


class ConfigError(ValueError):
    pass


@dataclass
class Mapping:
    name: str
    notion_data_source: str
    google_calendar: str
    timezone: str = "America/Denver"
    properties: dict = field(default_factory=lambda: {
        "title": "Name", "date": "Date", "google_event_id": "NCS Event ID"})
    default_duration_minutes: int = 60
    conflict_policy: str = "manual"
    poll_seconds: float = 45
    reconcile_seconds: float = 900
    allow_attendees: bool = False
    notion_incremental: bool = False
    notion_select_property: str = ""
    notion_select_value: str = ""
    import_since: str = ""

    @property
    def mapped_fields(self):
        return ["title", "time"] + [k for k in ("description", "location", "recurrence")
                                      if self.properties.get(k)]


@dataclass
class Config:
    state_path: Path = Path("state/sync.sqlite3")
    google_token_path: Path = Path("secrets/google-token.json")
    google_client_path: Path = Path("secrets/google-client.json")
    notion_token_env: str = "NOTION_TOKEN"
    mappings: list[Mapping] = field(default_factory=list)
    webhook_host: str = "127.0.0.1"
    webhook_port: int = 8765
    public_url: str = ""
    notion_webhook_secret_env: str = "NOTION_WEBHOOK_SECRET"
    notion_webhook_subscription: str = ""
    notion_webhook_workspace: str = ""
    log_level: str = "INFO"


def load_config(path):
    path = Path(path).expanduser().resolve()
    with path.open("rb") as f:
        raw = tomllib.load(f)
    if set(raw) - {"service", "mappings"}:
        raise ConfigError("Unknown top-level configuration section")
    service = raw.get("service", {})
    allowed = {f.name for f in fields(Config)} - {"mappings"}
    if set(service) - allowed:
        raise ConfigError("Unknown service option: " + ", ".join(sorted(set(service) - allowed)))
    conf = Config(**service)
    for key in ("state_path", "google_token_path", "google_client_path"):
        value = Path(getattr(conf, key)).expanduser()
        setattr(conf, key, value if value.is_absolute() else path.parent / value)
    for entry in raw.get("mappings", []):
        try:
            mapping = Mapping(**entry)
        except TypeError as e:
            raise ConfigError("Invalid mapping options") from e
        if not all(isinstance(x, str) and x.strip() for x in
                   (mapping.name, mapping.notion_data_source, mapping.google_calendar)):
            raise ConfigError("Each mapping requires name, notion_data_source and google_calendar")
        if mapping.notion_data_source.startswith("collection://"):
            mapping.notion_data_source = mapping.notion_data_source.removeprefix("collection://")
        if mapping.google_calendar == "primary":
            # Official alias supported; use only one such mapping.
            pass
        try:
            ZoneInfo(mapping.timezone)
        except (ValueError, KeyError) as e:
            raise ConfigError("Unknown mapping timezone") from e
        if mapping.conflict_policy not in ("manual", "notion", "google"):
            raise ConfigError("conflict_policy must be manual, notion or google")
        if not isinstance(mapping.notion_incremental, bool):
            raise ConfigError("notion_incremental must be boolean")
        if not isinstance(mapping.allow_attendees, bool):
            raise ConfigError("allow_attendees must be boolean")
        if mapping.default_duration_minutes <= 0 or mapping.default_duration_minutes > 10080:
            raise ConfigError("default_duration_minutes must be 1..10080")
        if mapping.poll_seconds < 5 or mapping.reconcile_seconds < mapping.poll_seconds:
            raise ConfigError("poll_seconds must be >=5; reconcile_seconds must be >=poll_seconds")
        if bool(mapping.notion_select_property) != bool(mapping.notion_select_value):
            raise ConfigError("Both notion_select_property and notion_select_value are required for category scope")
        if mapping.import_since:
            try:
                stamp = datetime.fromisoformat(mapping.import_since.replace("Z", "+00:00"))
                if stamp.tzinfo is None:
                    raise ValueError("timezone required")
            except (ValueError, AttributeError) as e:
                raise ConfigError("import_since must be an ISO timestamp with a timezone") from e
        props = mapping.properties
        known = {"title", "date", "description", "location", "google_url", "google_event_id",
                 "recurrence", "sync_enabled", "timezone"}
        if set(props) - known or any(not isinstance(v, str) for v in props.values()):
            raise ConfigError("Unknown mapping property key or non-string property name")
        if any(not props.get(k) for k in ("title", "date", "google_event_id")):
            raise ConfigError("Explicit title, date and google_event_id properties are required")
        names = [x for x in props.values() if x]
        if len(names) != len(set(names)):
            raise ConfigError("Each mapped field needs a distinct Notion property")
        conf.mappings.append(mapping)
    if not conf.mappings:
        raise ConfigError("At least one mapping is required")
    for key in ("name", "google_calendar"):
        vals = [getattr(m, key) for m in conf.mappings]
        if len(vals) != len(set(vals)):
            raise ConfigError(f"Mappings must have distinct {key} values to avoid overlapping ownership")
    for source in {m.notion_data_source for m in conf.mappings}:
        group = [m for m in conf.mappings if m.notion_data_source == source]
        if len(group) > 1:
            if not all(m.notion_select_property for m in group) or len({m.notion_select_property for m in group}) != 1 or len({m.notion_select_value for m in group}) != len(group):
                raise ConfigError("Mappings sharing a data source require disjoint values of the same select property")
    if not isinstance(conf.webhook_port, int) or not 1 <= conf.webhook_port <= 65535:
        raise ConfigError("Invalid webhook_port")
    if conf.public_url:
        url = urlparse(conf.public_url)
        if url.scheme != "https" or not url.hostname or url.username or url.password or url.query or url.fragment:
            raise ConfigError("public_url must be an HTTPS base URL without credentials/query/fragment")
        conf.public_url = conf.public_url.rstrip("/")
    if conf.log_level not in {"DEBUG", "INFO", "WARNING", "ERROR"}:
        raise ConfigError("Invalid log_level")
    return conf
