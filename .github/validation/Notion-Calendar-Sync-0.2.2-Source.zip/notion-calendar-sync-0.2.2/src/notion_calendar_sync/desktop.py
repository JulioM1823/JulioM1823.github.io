"""Desktop entry point and a tiny crash supervisor (no credentials in IPC)."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys
import time


def child_command(arguments):
    if getattr(sys, 'frozen', False):
        return [sys.executable, '--child', *arguments]
    isolated = ['-I'] if sys.flags.isolated else []
    return [sys.executable, *isolated, '-m', 'notion_calendar_sync.desktop', '--child', *arguments]


def supervise(arguments, *, run=subprocess.run, sleep=time.sleep):
    # A deliberate Quit returns 0. Crashes restart the same durable app with
    # bounded backoff. A per-user instance lock rejects duplicate windows/writers.
    delay = 2
    while True:
        started = time.monotonic()
        result = run(child_command(arguments))
        if result.returncode == 0:
            return 0
        sleep(delay)
        delay = 2 if time.monotonic()-started > 300 else min(60, delay*2)


def main(argv=None):
    parser = argparse.ArgumentParser(description='Notion Calendar Sync desktop')
    parser.add_argument('--background', action='store_true')
    parser.add_argument('--child', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--smoke-test', action='store_true', help='Open an isolated offline window briefly; no account access')
    args = parser.parse_args(argv)
    if args.smoke_test:
        from .desktop_ui import DesktopWindow
        class Offline:
            def state(self):
                return {'configured': False, 'approved': False, 'running': False, 'settings': {},
                        'connected_notion': False, 'connected_google': False, 'status': {}, 'logs': [], 'error': ''}
            def close(self):
                pass
        window = DesktopWindow(Offline())
        window.root.after(1000, window._destroy)
        window.root.mainloop()
        return 0
    if not args.child:
        return supervise(['--background'] if args.background else [])
    from .desktop_platform import app_data_dir
    from .desktop_backend import DesktopController
    from .desktop_ui import DesktopWindow
    from .service import StateLock
    directory = app_data_dir()
    lock = StateLock(directory/'desktop-instance')
    try:
        lock.__enter__()
    except RuntimeError:
        # A second double-click is a successful no-op rather than a crash loop.
        return 0
    controller = None
    try:
        controller = DesktopController(directory)
        window = DesktopWindow(controller)
        if args.background:
            window.root.iconify()
        window.root.mainloop()
        return 0
    finally:
        if controller:
            controller.close()
        lock.__exit__(None, None, None)


if __name__ == '__main__':
    raise SystemExit(main())
