"""Single-writer daemon, durable notification queue and channel lifecycle."""
from __future__ import annotations

from contextlib import AbstractContextManager
import os
if os.name == 'nt':
    import msvcrt
else:
    import fcntl
import json
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import secrets
import threading
import time
import uuid

LOG = logging.getLogger(__name__)


class StateLock(AbstractContextManager):
    def __init__(self, state_path):
        self.path = Path(str(state_path) + ".lock")
        self.handle = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd = os.open(self.path, os.O_RDWR | os.O_CREAT, 0o600)
        if hasattr(os, 'fchmod'):
            os.fchmod(fd, 0o600)
        self.handle = os.fdopen(fd, "a+")
        try:
            if os.name == 'nt':
                self.handle.seek(0)
                if not self.handle.read(1):
                    self.handle.write('0')
                    self.handle.flush()
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                fcntl.flock(self.handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.handle.close()
            self.handle = None
            raise RuntimeError("Another ncs writer is running; stop the service before running this command") from None
        return self

    def __exit__(self, *args):
        if self.handle is not None:
            try:
                if os.name == 'nt':
                    self.handle.seek(0)
                    msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(self.handle, fcntl.LOCK_UN)
            finally:
                self.handle.close()
                self.handle = None


class PrivateRotatingFileHandler(RotatingFileHandler):
    def _open(self):
        fd = os.open(self.baseFilename, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        if hasattr(os, 'fchmod'):
            os.fchmod(fd, 0o600)
        return os.fdopen(fd, "a", encoding="utf-8", errors="backslashreplace")


def configure_logging(config):
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, config.log_level.upper(), logging.INFO))
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    logger.addHandler(stream)
    config.state_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    log_path = config.state_path.parent / "ncs.log"
    fd = os.open(log_path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    if hasattr(os, 'fchmod'):
        os.fchmod(fd, 0o600)
    os.close(fd)
    # Four files, at most about 8 MiB total. State remains separate from logs.
    handler = PrivateRotatingFileHandler(log_path, maxBytes=2 * 1024 * 1024, backupCount=3, encoding="utf-8")
    handler.setFormatter(formatter)
    logger.addHandler(handler)


def report_has_errors(report):
    if isinstance(report, dict):
        return bool(report.get("error")) or report.get("action") in {"error", "failed"} or report.get("status") in {"error", "failed"}
    if isinstance(report, list):
        return any(report_has_errors(item) for item in report)
    return False


class SyncService:
    def __init__(self, config, store, engine, google, *, stop=None, now=time.time, monotonic=time.monotonic):
        self.config = config
        self.store = store
        self.engine = engine
        self.google = google
        self.stop = stop or threading.Event()
        self.now = now
        self.monotonic = monotonic
        self.next_poll = {mapping.name: 0.0 for mapping in config.mappings}
        self.next_reconcile = {mapping.name: 0.0 for mapping in config.mappings}
        self.next_channels = 0.0
        self.signal_retry_after = 0.0
        self.server = None

    def _meta(self, key, value):
        self.store.db.execute("INSERT INTO meta(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, json.dumps(value, separators=(",", ":"))))
        self.store.db.commit()

    def _signals(self):
        return self.store.db.execute("SELECT id,mapping,received FROM signals ORDER BY received LIMIT 1000").fetchall()

    def _sync(self, names, *, full=False, signals=()):
        started = self.monotonic()
        oldest = min((row["received"] for row in signals), default=self.now())
        self._meta("last_sync_started", self.now())
        try:
            report = self.engine.sync(full=full, mapping_names=list(names))
            success = not report_has_errors(report)
        except Exception as error:
            LOG.error("Synchronization batch failed (%s)", type(error).__name__)
            self._meta("last_service_error", {"time": self.now(), "type": type(error).__name__})
            success = False
        elapsed = self.monotonic() - started
        metrics = {
            "time": self.now(), "duration_seconds": round(elapsed, 6),
            "signal_wait_seconds": round(max(0.0, self.now() - oldest - elapsed), 6) if signals else None,
            "notification_to_batch_completion_seconds": round(max(0.0, self.now() - oldest), 6) if signals else None,
            "notification_count": len(signals), "mapping_count": len(names),
            "full_reconciliation": full, "success": success,
        }
        self._meta("last_service_metrics", metrics)
        LOG.info("Sync batch completed mappings=%d full=%s notifications=%d processing_seconds=%.3f success=%s", len(names), full, len(signals), elapsed, success)
        return success

    def renew_channels(self):
        if not self.config.public_url:
            return
        for mapping in self.config.mappings:
            try:
                self._renew_mapping(mapping)
            except Exception as error:
                LOG.warning("Channel renewal failed mapping=%s (%s); polling remains enabled", mapping.name, type(error).__name__)
                self._meta("channel_error:" + mapping.name, {"time": self.now(), "type": type(error).__name__})

    def _renew_mapping(self, mapping):
        now = self.now()
        active = self.store.db.execute("SELECT * FROM channels WHERE mapping=? AND status='active' ORDER BY expiration DESC", (mapping.name,)).fetchall()
        # A previously failed watch may have created an unknown remote channel.
        # Its random id/token never become trusted; it naturally expires.
        with self.store.db:
            self.store.db.execute("UPDATE channels SET status='expired' WHERE expiration <= ? AND status IN ('active','pending')", (now,))
        healthy = [row for row in active if row["expiration"] > now + 3600]
        if not healthy:
            channel_id = str(uuid.uuid4())
            token = secrets.token_urlsafe(32)
            with self.store.db:
                self.store.db.execute("INSERT INTO channels(id,mapping,resource_id,token,expiration,status) VALUES (?,?,?,?,?,'pending')", (channel_id, mapping.name, "", token, now + 120))
            try:
                result = self.google.watch(mapping, channel_id, token, self.config.public_url.rstrip("/") + "/webhooks/google")
                resource = result.get("resourceId", "")
                expiration = float(result.get("expiration", 0)) / 1000
                if result.get("id") != channel_id or not resource or expiration <= now:
                    raise ValueError("Google returned an invalid notification channel")
                with self.store.db:
                    self.store.db.execute("UPDATE channels SET resource_id=?,expiration=?,status='active' WHERE id=?", (resource, expiration, channel_id))
                self._meta("channel_error:" + mapping.name, None)
                LOG.info("Notification channel registered mapping=%s", mapping.name)
            except Exception:
                with self.store.db:
                    self.store.db.execute("UPDATE channels SET status='failed' WHERE id=?", (channel_id,))
                raise
            newest_id = channel_id
        else:
            newest_id = healthy[0]["id"]
        # Stop replaced channels only after the replacement is safely durable.
        for row in active:
            if row["id"] == newest_id:
                continue
            try:
                self.google.stop_channel(row["id"], row["resource_id"])
                with self.store.db:
                    self.store.db.execute("UPDATE channels SET status='stopped' WHERE id=?", (row["id"],))
            except Exception as error:
                LOG.warning("Old channel cleanup deferred (%s)", type(error).__name__)
        # Old channel tokens are no longer needed after their remote expiration.
        with self.store.db:
            self.store.db.execute("DELETE FROM channels WHERE expiration < ? AND status IN ('stopped','expired','failed')", (now - 86400,))

    def tick(self):
        clock = self.monotonic()
        if clock >= self.next_channels:
            self.renew_channels()
            self.next_channels = clock + 60
        signals = self._signals() if clock >= self.signal_retry_after else []
        all_names = {mapping.name for mapping in self.config.mappings}
        signalled = set()
        for row in signals:
            if row["mapping"]:
                if row["mapping"] in all_names:
                    signalled.add(row["mapping"])
            else:
                signalled.update(all_names)
        full_names = {name for name, deadline in self.next_reconcile.items() if clock >= deadline}
        due_names = {name for name, deadline in self.next_poll.items() if clock >= deadline}
        successful_names = set()
        failed = False
        # Full reconciliation needs its own batch so unrelated mappings retain
        # efficient incremental scans.
        if full_names:
            relevant = [row for row in signals if not row["mapping"] or row["mapping"] in full_names]
            success = self._sync(full_names, full=True, signals=relevant)
            if success:
                successful_names.update(full_names)
            else:
                failed = True
            for mapping in self.config.mappings:
                if mapping.name in full_names:
                    self.next_reconcile[mapping.name] = self.monotonic() + (mapping.reconcile_seconds if success else min(60, mapping.poll_seconds))
                    self.next_poll[mapping.name] = self.monotonic() + mapping.poll_seconds
        names = (due_names | signalled) - full_names
        if names:
            relevant = [row for row in signals if not row["mapping"] or row["mapping"] in names]
            success = self._sync(names, signals=relevant)
            if success:
                successful_names.update(names)
            else:
                failed = True
            for mapping in self.config.mappings:
                if mapping.name in names:
                    self.next_poll[mapping.name] = self.monotonic() + mapping.poll_seconds
        # A global signal is acknowledged only after every configured mapping
        # ran successfully. Receipts remain separately retained for dedupe.
        acknowledged = []
        for row in signals:
            required = {row["mapping"]} if row["mapping"] else all_names
            if required <= successful_names:
                acknowledged.append((row["id"],))
        if acknowledged:
            with self.store.db:
                self.store.db.executemany("DELETE FROM signals WHERE id=?", acknowledged)
        if failed:
            self.signal_retry_after = self.monotonic() + 15

    def run(self):
        from .webhooks import start_server
        if self.config.public_url:
            self.server, _ = start_server(self.config)
            LOG.info("Webhook receiver listening on %s:%s", self.config.webhook_host, self.config.webhook_port)
        LOG.info("Service started mappings=%d polling_enabled=true", len(self.config.mappings))
        try:
            while not self.stop.is_set():
                try:
                    self.tick()
                except Exception as error:
                    LOG.error("Service tick failed (%s); retrying", type(error).__name__)
                    self._meta("last_service_error", {"time": self.now(), "type": type(error).__name__})
                    self.stop.wait(5)
                self.stop.wait(0.25)
        finally:
            if self.server:
                self.server.shutdown()
                self.server.server_close()
            LOG.info("Service stopped")
