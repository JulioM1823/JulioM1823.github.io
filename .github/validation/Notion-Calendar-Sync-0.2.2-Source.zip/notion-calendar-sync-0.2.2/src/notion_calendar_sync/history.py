"""Conservative, one-time historical matching; never used for normal imports."""
from collections import Counter
from datetime import datetime
import base64
import json
import re
from urllib.parse import parse_qs, urlsplit
from uuid import UUID


def uuid_key(value):
    try:
        return UUID(value).hex
    except (ValueError, TypeError, AttributeError):
        return ''


def legacy_identity(value, calendar, *, page_id=None, event_id=None):
    parts = value.split(';')
    if len(parts) < 4 or parts[2] != calendar or not uuid_key(parts[3]):
        return None
    if page_id is not None and uuid_key(parts[3]) != uuid_key(page_id):
        return None
    if event_id is not None and parts[1] != event_id:
        return None
    if not parts[1] or '/' in parts[1] or len(parts[1]) > 1024:
        return None
    return parts[3], parts[1]


def calendar_url_identity(value):
    """Decode Google UI eid into (calendar,event), not an API ID guess."""
    try:
        url = urlsplit(value)
        if url.scheme != 'https' or url.hostname not in ('calendar.google.com', 'www.google.com'):
            return None
        if url.username or url.password or not url.path.startswith('/calendar/'):
            return None
        encoded = parse_qs(url.query).get('eid', [''])[0]
        raw = base64.urlsafe_b64decode(encoded + '=' * (-len(encoded) % 4)).decode()
        event, calendar = raw.split(' ', 1)
        if calendar.endswith('@g'):
            calendar = calendar[:-2] + '@group.calendar.google.com'
        elif calendar.endswith('@m'):
            calendar = calendar[:-2] + '@gmail.com'
        if not event or '/' in event or not calendar:
            return None
        return calendar, event
    except (ValueError, UnicodeError):
        return None


def plain(property):
    return ''.join(p.get('plain_text', p.get('text', {}).get('content', ''))
                   for p in property.get('rich_text', []))


def fingerprint(record):
    """All mapped values; only address whitespace is treated as presentation."""
    v = record.values
    if record.deleted or not v.get('title') or not v.get('time'):
        return None
    return json.dumps({'title': v['title'], 'time': v['time'],
                       'description': v.get('description', ''),
                       'location': re.sub(r'\s+', '', v.get('location', '')),
                       'recurrence': v.get('recurrence', [])}, sort_keys=True)


def corroborated(notion, google):
    try:
        n = datetime.fromisoformat(notion.raw['created_time'].replace('Z', '+00:00'))
        g = datetime.fromisoformat(google.raw['created'].replace('Z', '+00:00'))
        if abs((n - g).total_seconds()) <= 600:
            return 'all-fields-plus-nearby-creation-times'
    except (KeyError, ValueError, TypeError):
        pass
    if len(notion.values.get('location', '').strip()) >= 10 or len(notion.values.get('description', '').strip()) >= 20:
        return 'all-fields-plus-distinct-location-or-notes'
    return ''


def reschedule_fingerprint(record):
    """Identity evidence for a date-only move, requiring separate provenance."""
    v = record.values
    if not fingerprint(record) or v.get('recurrence'):
        return None
    schedule = dict(v['time'])
    start, end = schedule.pop('start'), schedule.pop('end')
    try:
        a, b = datetime.fromisoformat(start), datetime.fromisoformat(end)
        # Keep wall-clock boundaries, zone, all-day status, and duration. Only
        # the calendar date may vary in this narrow, manually invoked recovery.
        schedule['start_clock'] = a.time().isoformat()
        schedule['end_clock'] = b.time().isoformat()
        schedule['duration'] = (b.timestamp() - a.timestamp()) if a.tzinfo else (b - a).total_seconds()
    except (ValueError, TypeError):
        return None
    return json.dumps(dict(title=v['title'], time=schedule,
                           description=v.get('description', ''),
                           location=re.sub(r'\s+', '', v.get('location', ''))), sort_keys=True)


def newer_notion_reschedule(notion, google):
    if not reschedule_fingerprint(notion) or reschedule_fingerprint(notion) != reschedule_fingerprint(google):
        return False
    try:
        created_n = datetime.fromisoformat(notion.raw['created_time'].replace('Z', '+00:00'))
        created_g = datetime.fromisoformat(google.raw['created'].replace('Z', '+00:00'))
        edited_n = datetime.fromisoformat(notion.raw['last_edited_time'].replace('Z', '+00:00'))
        edited_g = datetime.fromisoformat(google.raw['updated'].replace('Z', '+00:00'))
        a = datetime.fromisoformat(notion.values['time']['start'])
        b = datetime.fromisoformat(google.values['time']['start'])
        day_gap = abs((a.date() - b.date()).days)
        return (abs((created_n - created_g).total_seconds()) <= 600 and
                edited_n > edited_g and 0 < day_gap <= 7 and
                (len(notion.values.get('description', '').strip()) >= 20 or
                 len(notion.values.get('location', '').strip()) >= 10))
    except (KeyError, ValueError, TypeError):
        return False


def historical_trash_evidence(mapping, notion, google):
    """Prove an old linked page was trashed; never infer this from a 404."""
    if (not notion.deleted or not notion.raw.get('in_trash') or
        notion.raw.get('ncs_out_of_scope') or google.deleted or not google.eligible or
        google.raw.get('attendees') or google.raw.get('attendeesOmitted') or
        google.values.get('recurrence') or google.raw.get('recurringEventId') or
        notion.raw.get('ncs_peer_id') not in (None, '', google.id) or
        google.raw.get('ncs_mapping') not in (None, '', mapping.name)):
        return False
    if google.raw.get('ncs_peer_id') and uuid_key(google.raw['ncs_peer_id']) != uuid_key(notion.id):
        return False
    for section in google.raw.get('extendedProperties', {}).values():
        for key, value in section.items():
            if not key.startswith('nad_') or key.startswith('nad_status_'):
                continue
            identity = legacy_identity(value, mapping.google_calendar, page_id=notion.id, event_id=google.id)
            if identity:
                return True
    return False


def importable_history(mapping, notions, googles, occupied_g=()):
    """Find Calendar-only records after checking the whole Notion data source.

    Existing/foreign identities and possible counterparts are held, never
    merged or cloned. Recurring masters and explicit exceptions remain distinct.
    """
    occupied_g = set(occupied_g)
    claimed, by_title = set(), {}
    for n in notions:
        props = n.raw.get('properties', {})
        marker = plain(props.get(mapping.properties.get('google_event_id', ''), {})).strip()
        if marker:
            claimed.add(marker)
        old = legacy_identity(plain(props.get('Notion Automations Events Data', {})), mapping.google_calendar, page_id=n.id)
        if old:
            claimed.add(old[1])
        url = calendar_url_identity(props.get(mapping.properties.get('google_url', ''), {}).get('url') or '')
        if url and url[0] == mapping.google_calendar:
            claimed.add(url[1])
        by_title.setdefault(n.values.get('title', ''), []).append(n)
    keys = Counter(fingerprint(g) for g in googles if fingerprint(g))
    uids = Counter((g.raw.get('iCalUID'), json.dumps(g.raw.get('originalStartTime'), sort_keys=True)
                    if g.raw.get('recurringEventId') else 'master-or-single')
                   for g in googles if not g.deleted and g.raw.get('iCalUID'))
    proposed, held = [], Counter()
    for g in googles:
        if g.id in occupied_g:
            continue
        if g.deleted or not g.eligible:
            held['cancelled-or-unsupported'] += 1
            continue
        raw = g.raw
        if (g.id in claimed or raw.get('ncs_peer_id') or raw.get('ncs_mapping') or
            any(k.startswith('nad_') and not k.startswith('nad_status_')
                for section in raw.get('extendedProperties', {}).values() for k in section) or
            re.search(r'notion\.(?:so|com)', raw.get('source', {}).get('url', ''))):
            held['existing-or-unverified-notion-identity'] += 1
            continue
        uid = (raw.get('iCalUID'), json.dumps(raw.get('originalStartTime'), sort_keys=True)
               if raw.get('recurringEventId') else 'master-or-single')
        if keys[fingerprint(g)] != 1 or (uid[0] and uids[uid] != 1):
            held['ambiguous-calendar-duplicates'] += 1
            continue
        candidates = by_title.get(g.values.get('title', ''), [])
        possible = False
        for n in candidates:
            # A legacy occurrence is not its series master.
            old = legacy_identity(plain(n.raw.get('properties', {}).get('Notion Automations Events Data', {})),
                                  mapping.google_calendar, page_id=n.id)
            if g.values.get('recurrence') and old and old[1].startswith(g.id + '_'):
                continue
            if not n.values.get('time'):
                possible = True
                break
            a, b = n.values['time'], g.values['time']
            try:
                same_instants = all(datetime.fromisoformat(a[k].replace('Z', '+00:00')) ==
                                    datetime.fromisoformat(b[k].replace('Z', '+00:00')) for k in ('start', 'end'))
            except (ValueError, KeyError):
                same_instants = False
            if same_instants or (reschedule_fingerprint(n) == reschedule_fingerprint(g) and corroborated(n, g)):
                possible = True
                break
        if possible:
            held['possible-existing-counterpart'] += 1
            continue
        proposed.append({'google_id': g.id, 'reason': 'unclaimed-provider-id-after-full-database-audit'})
    return proposed, dict(held)


def plan_pairs(mapping, notions, googles, occupied_n=(), occupied_g=(), other_notions=()):
    """Return disjoint existing pairs. No creations, deletions, or fuzzy matching.

    Prefer stored IDs. Missing IDs can be recovered only from unique agreement
    of every mapped value plus separate location/notes or creation evidence.
    Repeated titles/dates alone are never a sufficient match.
    """
    occupied_n = {uuid_key(x) or x for x in occupied_n}
    occupied_g = set(occupied_g)
    nindex = {uuid_key(n.id) or n.id: n for n in notions}
    gindex = {g.id: g for g in googles}
    nk = Counter(fingerprint(n) for n in [*notions, *other_notions] if fingerprint(n))
    gk = Counter(fingerprint(g) for g in googles if fingerprint(g))
    proposals, stable, rejected = [], [], Counter()
    def add(n, g, evidence):
        key = uuid_key(n.id) or n.id
        if key in occupied_n or g.id in occupied_g:
            rejected['occupied'] += 1
            return
        if n.deleted or g.deleted or not n.eligible or not g.eligible:
            rejected['deleted-or-ineligible'] += 1
            return
        if (n.raw.get('ncs_peer_id') not in (None, '', g.id) or
            g.raw.get('ncs_mapping') not in (None, '', mapping.name) or
            (g.raw.get('ncs_peer_id') and (not uuid_key(g.raw['ncs_peer_id']) or uuid_key(g.raw['ncs_peer_id']) != uuid_key(n.id)))):
            rejected['foreign-owner'] += 1
            return
        proposals.append({'notion_id': n.id, 'google_id': g.id, 'evidence': evidence})
        occupied_n.add(key); occupied_g.add(g.id)
    for n in notions:
        props = n.raw.get('properties', {})
        old = legacy_identity(plain(props.get('Notion Automations Events Data', {})),
                              mapping.google_calendar, page_id=n.id)
        url = calendar_url_identity(props.get(mapping.properties.get('google_url', ''), {}).get('url') or '')
        ids = {old[1]} if old else set()
        if url and url[0] == mapping.google_calendar:
            ids.add(url[1])
        if len(ids) > 1:
            rejected['disagreeing-stable-identities'] += 1
        elif len(ids) == 1 and next(iter(ids)) in gindex:
            stable.append((n, gindex[next(iter(ids))], 'stored-provider-id'))
    for g in googles:
        for section in g.raw.get('extendedProperties', {}).values():
            for name, value in section.items():
                if not name.startswith('nad_') or name.startswith('nad_status_'):
                    continue
                old = legacy_identity(value, mapping.google_calendar, event_id=g.id)
                if old and uuid_key(old[0]) in nindex:
                    stable.append((nindex[uuid_key(old[0])], g, 'reciprocal-legacy-provider-id'))
    for n, g, evidence in stable:
        nclaims = {peer.id for source, peer, _ in stable if source.id == n.id}
        gclaims = {source.id for source, peer, _ in stable if peer.id == g.id}
        if len(nclaims) != 1 or len(gclaims) != 1:
            rejected['ambiguous-stable-identities'] += 1
            continue
        add(n, g, evidence)
    fingerprints = {fingerprint(g): g for g in googles if fingerprint(g) and gk[fingerprint(g)] == 1}
    for n in notions:
        key = fingerprint(n)
        if not key or nk[key] != 1 or gk[key] != 1:
            continue
        # A lost known peer must not be silently replaced with a similar item.
        if plain(n.raw.get('properties', {}).get('Notion Automations Events Data', {})) or n.raw.get('ncs_peer_id'):
            continue
        g = fingerprints[key]
        if any(name.startswith('nad_') and not name.startswith('nad_status_')
               for section in g.raw.get('extendedProperties', {}).values() for name in section):
            continue
        evidence = corroborated(n, g)
        if evidence:
            add(n, g, evidence)
    # Date-only moves need stronger provenance than an unchanged item: unique
    # full content, same duration/clock/zone, creation within ten minutes,
    # descriptive notes/location, and a strictly newer Notion version.
    nr = Counter(reschedule_fingerprint(n) for n in [*notions, *other_notions] if reschedule_fingerprint(n))
    gr = Counter(reschedule_fingerprint(g) for g in googles if reschedule_fingerprint(g))
    rg = {reschedule_fingerprint(g): g for g in googles if reschedule_fingerprint(g) and gr[reschedule_fingerprint(g)] == 1}
    for n in notions:
        key = reschedule_fingerprint(n)
        if not key or nr[key] != 1 or gr[key] != 1:
            continue
        if plain(n.raw.get('properties', {}).get('Notion Automations Events Data', {})) or n.raw.get('ncs_peer_id'):
            continue
        g = rg[key]
        if any(name.startswith('nad_') and not name.startswith('nad_status_')
               for section in g.raw.get('extendedProperties', {}).values() for name in section):
            continue
        if newer_notion_reschedule(n, g):
            add(n, g, 'unique-content-near-creation-newer-notion-date')
    return proposals, dict(rejected)
