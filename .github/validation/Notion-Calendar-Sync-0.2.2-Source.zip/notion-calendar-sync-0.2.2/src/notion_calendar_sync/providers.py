"""Official REST API adapters. Missing records are never deletion evidence."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
import hashlib
import os
import re
import time
from urllib.parse import quote, urlencode
from zoneinfo import ZoneInfo

from .http import (AccessError, AmbiguousWrite, PreconditionFailed, ProviderError,
                   ReauthRequired, Transport)
from .model import Record, normalize_time
from .oauth import TokenManager

NOTION_VERSION = '2026-03-11'
NOTION_BASE = 'https://api.notion.com/v1'
GOOGLE_BASE = 'https://www.googleapis.com/calendar/v3'


def _google_timezone(value):
    # Legacy imported events can carry GMT-05:00 rather than an IANA name.
    # IANA Etc/GMT signs are reversed (Etc/GMT+5 is UTC-05:00). Only whole
    # hours with an actual tzdb entry are translated; unknown zones still pause.
    match = re.fullmatch(r'GMT([+-])(\d{1,2}):00', value)
    if match:
        hours = int(match[2])
        value = ('Etc/GMT' + ('-' if match[1] == '+' else '+') + str(hours)) if hours else 'Etc/GMT'
    ZoneInfo(value)
    return value


@dataclass
class Scan:
    records: list[Record]
    cursor: str | None = None
    complete: bool = True
    full_membership: bool = False


def _text(value: dict | None, kind: str = 'rich_text') -> str:
    if not value:
        return ''
    return ''.join(part.get('plain_text', part.get('text', {}).get('content', ''))
                   for part in value.get(kind, []))


def _rich(value: str) -> list[dict]:
    # 100 text segments per property; never silently truncate.
    if len(value) > 200_000:
        raise ProviderError('Mapped text exceeds Notion 100 x 2000 character limit')
    return [{'type': 'text', 'text': {'content': value[i:i + 2000]}}
            for i in range(0, len(value), 2000)]


def _recurrence(value: str | list) -> list[str]:
    lines = value if isinstance(value, list) else value.replace('\r\n', '\n').split('\n')
    result = [str(line).strip() for line in lines if str(line).strip()]
    for line in result:
        if not re.match(r'^(RRULE|RDATE|EXDATE)(;[^:\r\n]+)?:[^\r\n]+$', line):
            raise ProviderError('Unsupported recurrence: use RRULE, RDATE, EXDATE RFC5545 lines only')
    return result


def _same_uuid(left: str, right: str) -> bool:
    return left.replace('-', '').lower() == right.replace('-', '').lower()


class NotionProvider:
    def __init__(self, config, transport: Transport | None = None, *, token_loader=None):
        self.config = config
        self.transport = transport or Transport(min_interval=0.36)
        self.token_loader = token_loader

    def _request(self, method, path, *, body=None, safe=None):
        token = self.token_loader() if self.token_loader else os.environ.get(self.config.notion_token_env, '')
        if not token:
            raise ReauthRequired(f'Notion token missing in {self.config.notion_token_env}')
        return self.transport.request(method, NOTION_BASE + path, body=body, safe=safe,
                                      headers={'Authorization': 'Bearer ' + token,
                                               'Notion-Version': NOTION_VERSION})

    def validate(self, mapping) -> dict:
        schema = self._request('GET', '/data_sources/' + quote(mapping.notion_data_source, safe=''))
        properties = schema.get('properties', {})
        required = {'title': 'title', 'date': 'date', 'google_event_id': 'rich_text'}
        optional = {'description': 'rich_text', 'location': 'rich_text', 'google_url': 'url',
                    'recurrence': 'rich_text', 'timezone': 'rich_text', 'sync_enabled': 'checkbox'}
        for field, kind in {**required, **optional}.items():
            name = mapping.properties.get(field)
            if not name:
                if field in required:
                    raise ProviderError(f'Mapping requires a Notion {field} property')
                continue
            prop = properties.get(name)
            if not prop:
                prop = next((p for p in properties.values() if p.get('id') == name), None)
            if not prop or prop.get('type') != kind:
                raise ProviderError(f'Notion mapped property {name!r} must have type {kind}')
        scope = getattr(mapping, 'notion_select_property', '')
        if scope:
            prop = properties.get(scope) or next((p for p in properties.values() if p.get('id') == scope), {})
            if prop.get('type') != 'select' or getattr(mapping, 'notion_select_value', '') not in [o.get('name') for o in prop.get('select', {}).get('options', [])]:
                raise ProviderError('Configured Notion category must be an existing select option')
        return {'id': schema.get('id'), 'properties': {name: p.get('type') for name, p in properties.items()},
                'notion_version': NOTION_VERSION}

    def _property(self, properties: dict, name: str | None) -> dict:
        if not name:
            return {}
        return properties.get(name) or next((p for p in properties.values() if p.get('id') == name), {})

    def _record(self, mapping, page: dict) -> Record:
        props = page.get('properties', {})
        p = lambda key: self._property(props, mapping.properties.get(key))
        marker = _text(p('google_event_id'))
        raw = dict(page, ncs_peer_id=marker)
        deleted = bool(page.get('in_trash') or page.get('archived'))
        values = {'title': _text(p('title'), 'title')}
        for field in ('description', 'location'):
            if mapping.properties.get(field):
                values[field] = _text(p(field))
        if mapping.properties.get('recurrence'):
            try:
                values['recurrence'] = _recurrence(_text(p('recurrence')))
            except ProviderError as exc:
                return Record(str(page['id']), values, page.get('last_edited_time', ''), deleted,
                              False, str(exc), page.get('url', ''), raw)
        eligible, reason = True, ''
        if page.get('is_archived') and not deleted:
            eligible, reason = False, 'Notion page is archived (distinct from trash); synchronization paused'
        if mapping.properties.get('sync_enabled') and not p('sync_enabled').get('checkbox'):
            eligible, reason = False, 'Notion synchronization checkbox is disabled'
        parent = page.get('parent', {})
        source = parent.get('data_source_id')
        if not source or not _same_uuid(source, mapping.notion_data_source):
            eligible, reason = False, 'Notion page moved outside configured data source'
        scope = getattr(mapping, 'notion_select_property', '')
        if scope and (self._property(props, scope).get('select') or {}).get('name') != mapping.notion_select_value:
            eligible, reason = False, 'Notion page is outside configured category scope'
            raw['ncs_out_of_scope'] = True
        if not source or not _same_uuid(source, mapping.notion_data_source):
            raw['ncs_out_of_scope'] = True
        dt = p('date').get('date')
        if dt and dt.get('start'):
            start, end = dt['start'], dt.get('end')
            tz = _text(p('timezone')).strip() or dt.get('time_zone') or mapping.timezone
            try:
                if len(start) == 10:
                    # All-day dates have no event-specific timezone in Google.
                    tz = mapping.timezone
                    # Notion's date range endpoints are inclusive; Google end is exclusive.
                    last = date.fromisoformat(end or start)
                    end = (last + timedelta(days=1)).isoformat()
                values['time'] = normalize_time(start, end, tz, mapping.default_duration_minutes)
            except (ValueError, TypeError, OverflowError, KeyError) as exc:
                eligible, reason = False, 'Invalid or unsupported Notion date/time'
        else:
            eligible, reason = False, 'Notion date is empty; linked item is paused without deletion'
        if not deleted and (not props or any(not p(key) for key, name in mapping.properties.items() if name)):
            eligible, reason = False, 'Incomplete Notion page response: a mapped property is missing'
        for key, name in mapping.properties.items():
            if not name:
                continue
            prop = p(key)
            parts = prop.get('title', prop.get('rich_text', []))
            mention_count = sum(1 for part in parts if part.get('type') == 'mention' and
                                part.get('mention', {}).get('type') in ('page', 'user'))
            if not deleted and (prop.get('has_more') or mention_count >= 25):
                eligible, reason = False, 'Mapped Notion text may contain omitted mentions; full property pagination is outside plain-source mapping'

        return Record(str(page['id']), values, page.get('last_edited_time', ''), deleted,
                      eligible, reason, page.get('url', ''), raw)

    def _query(self, mapping, *, filter=None, archived: bool = False) -> list[dict]:
        body = {'page_size': 100, 'is_archived': archived}
        scope = getattr(mapping, 'notion_select_property', '')
        if scope:
            category = {'property': scope, 'select': {'equals': mapping.notion_select_value}}
            body['filter'] = {'and': [category, filter]} if filter else category
        elif filter:
            body['filter'] = filter
        rows, seen = [], set()
        while True:
            data = self._request('POST', '/data_sources/' + quote(mapping.notion_data_source, safe='') + '/query', body=body, safe=True)
            if not isinstance(data.get('results'), list) or not isinstance(data.get('has_more'), bool):
                raise ProviderError('Incomplete Notion query response')
            if data.get('request_status', {}).get('type') == 'incomplete':
                raise ProviderError('Notion query exceeded its result limit; narrow the selected data source before synchronization')
            rows.extend(data['results'])
            if not data['has_more']:
                break
            cursor = data.get('next_cursor')
            if not cursor or cursor in seen:
                raise ProviderError('Invalid Notion pagination cursor')
            seen.add(cursor)
            body['start_cursor'] = cursor
        return rows

    def scan(self, mapping, cursor=None, full=False) -> Scan:
        # Save scan-start watermark; overlap covers second-level timestamp precision and slow pagination.
        watermark = datetime.now(timezone.utc).isoformat()
        filter = None
        full_membership = bool(full or not cursor or not getattr(mapping, 'notion_incremental', False))
        if not full_membership:
            try:
                since = datetime.fromisoformat(cursor.replace('Z', '+00:00')) - timedelta(seconds=120)
                filter = {'timestamp': 'last_edited_time', 'last_edited_time': {'on_or_after': since.isoformat()}}
            except ValueError:
                raise ProviderError('Invalid persisted Notion watermark; run sync --full') from None
        records = {}
        for archived in (False, True):
            for page in self._query(mapping, filter=filter, archived=archived):
                record = self._record(mapping, page)
                records[record.id] = record
        return Scan(list(records.values()), watermark, full_membership=full_membership)

    def get(self, mapping, id) -> Record:
        data = self._request('GET', '/pages/' + quote(id, safe=''))
        if not data.get('id') or data.get('object') != 'page':
            raise ProviderError('Incomplete Notion page response')
        return self._record(mapping, data)

    def _properties(self, mapping, values: dict) -> dict:
        output = {}
        for field, value in values.items():
            key = {'time': 'date'}.get(field, field)
            name = mapping.properties.get(key)
            if not name:
                continue
            if field == 'title':
                output[name] = {'title': _rich(str(value))}
            elif field in ('description', 'location', 'google_event_id'):
                output[name] = {'rich_text': _rich(str(value))}
            elif field == 'recurrence':
                output[name] = {'rich_text': _rich('\n'.join(_recurrence(value)))}
            elif field == 'google_url':
                output[name] = {'url': value or None}
            elif field == 'sync_enabled':
                output[name] = {'checkbox': bool(value)}
            elif field == 'time':
                if not value:
                    raise ProviderError('Cleared dates pause synchronization; never clear a remote date automatically')
                canonical = normalize_time(value['start'], value['end'], value['timezone'], mapping.default_duration_minutes)
                if canonical['all_day']:
                    end = (date.fromisoformat(canonical['end']) - timedelta(days=1)).isoformat()
                    output[name] = {'date': {'start': canonical['start'],
                                             'end': end if end != canonical['start'] else None,
                                             'time_zone': None}}
                    if mapping.properties.get('timezone'):
                        output[mapping.properties['timezone']] = {'rich_text': _rich(canonical['timezone'])}
                else:
                    if mapping.properties.get('timezone'):
                        # Notion coerces a range's end to its start's fixed offset.
                        # Use UTC for BOTH endpoints so a range crossing DST keeps
                        # its exact instants; retain the IANA zone separately.
                        endpoints = {key: datetime.fromisoformat(canonical[key]).astimezone(timezone.utc).isoformat()
                                     for key in ('start', 'end')}
                        output[name] = {'date': dict(endpoints, time_zone=None)}
                        output[mapping.properties['timezone']] = {'rich_text': _rich(canonical['timezone'])}
                    else:
                        zone = ZoneInfo(canonical['timezone'])
                        for endpoint in ('start', 'end'):
                            wall = datetime.fromisoformat(canonical[endpoint]).replace(tzinfo=None)
                            if wall.replace(tzinfo=zone, fold=0).utcoffset() != wall.replace(tzinfo=zone, fold=1).utcoffset():
                                raise ProviderError('Ambiguous DST wall time requires a mapped timezone rich_text property')
                        start = datetime.fromisoformat(canonical['start']).replace(tzinfo=None).isoformat()
                        end = datetime.fromisoformat(canonical['end']).replace(tzinfo=None).isoformat()
                        output[name] = {'date': {'start': start, 'end': end, 'time_zone': canonical['timezone']}}
        return output

    def create(self, mapping, values, operation_id, peer_id='', *, recovery_only=False) -> Record:
        if not peer_id or not mapping.properties.get('google_event_id'):
            raise ProviderError('Notion creation requires a stable Google event identity property')
        filter = {'property': mapping.properties['google_event_id'], 'rich_text': {'equals': peer_id}}
        found = {}
        for archived in (False, True):
            for page in self._query(mapping, filter=filter, archived=archived):
                found[page['id']] = page
        if len(found) > 1:
            raise ProviderError('Multiple Notion pages contain the same Google event identity; explicit linking required')
        if found:
            return self._record(mapping, next(iter(found.values())))
        if recovery_only:
            raise AmbiguousWrite('Notion creation outcome unknown; marker not yet visible; manual acknowledgement required before replay')
        properties = self._properties(mapping, dict(values, google_event_id=peer_id))
        if getattr(mapping, 'notion_select_property', ''):
            properties[mapping.notion_select_property] = {'select': {'name': mapping.notion_select_value}}
        if mapping.properties.get('sync_enabled'):
            properties.update(self._properties(mapping, {'sync_enabled': True}))
        data = self._request('POST', '/pages', body={'parent': {'type': 'data_source_id', 'data_source_id': mapping.notion_data_source},
                                                    'properties': properties}, safe=False)
        if not data.get('id'):
            raise AmbiguousWrite('Notion creation response omitted page identity')
        return self._record(mapping, data)

    def update(self, mapping, id, values, version='') -> Record:
        current = self.get(mapping, id)
        if current.deleted or not current.eligible:
            raise PreconditionFailed('Notion item deleted or ineligible before update')
        if version and current.version != version:
            raise PreconditionFailed('Notion item changed before update (Notion has no atomic If-Match)')
        properties = self._properties(mapping, values)
        if not properties:
            return current
        # Do not auto-retry a conditional PATCH; refetch/remerge after uncertain outcome.
        return self._record(mapping, self._request('PATCH', '/pages/' + quote(id, safe=''), body={'properties': properties}, safe=False))

    def archive(self, mapping, id, version='') -> Record:
        current = self.get(mapping, id)
        if current.deleted:
            return current
        if not current.eligible:
            raise PreconditionFailed('Notion item became ineligible before archive')
        if version and current.version != version:
            raise PreconditionFailed('Notion item changed before archive')
        data = self._request('PATCH', '/pages/' + quote(id, safe=''), body={'in_trash': True}, safe=False)
        return self._record(mapping, data)

    def set_links(self, mapping, id, peer_id, peer_url='') -> Record:
        current = self.get(mapping, id)
        if current.deleted:
            return current
        existing = current.raw.get('ncs_peer_id', '')
        if existing and existing != peer_id:
            raise PreconditionFailed('Notion page already points to a different Google event')
        changes = {'google_event_id': peer_id}
        props = current.raw.get('properties', {})
        url = self._property(props, mapping.properties.get('google_url')).get('url') or ''
        if mapping.properties.get('google_url') and peer_url and url != peer_url:
            changes['google_url'] = peer_url
        if existing == peer_id:
            changes.pop('google_event_id', None)
        if not changes:
            return current
        data = self._request('PATCH', '/pages/' + quote(id, safe=''), body={'properties': self._properties(mapping, changes)}, safe=False)
        return self._record(mapping, data)


class GoogleProvider:
    def __init__(self, config, transport: Transport | None = None, tokens: TokenManager | None = None):
        self.config = config
        self.transport = transport or Transport(min_interval=0.1)
        self.tokens = tokens or TokenManager(config.google_client_path, config.google_token_path)
        self.last_reset = False

    def _request(self, method, path, *, body=None, safe=None, version=''):
        for force in (False, True):
            headers = {'Authorization': 'Bearer ' + self.tokens.access_token(force=force)}
            if version:
                headers['If-Match'] = version
            try:
                return self.transport.request(method, GOOGLE_BASE + path, body=body, safe=safe, headers=headers)
            except ReauthRequired:
                if force:
                    raise
        raise ReauthRequired('Google authorization rejected')

    def _events_path(self, mapping) -> str:
        return '/calendars/' + quote(mapping.google_calendar, safe='') + '/events'

    def validate(self, mapping) -> dict:
        data = self._request('GET', '/users/me/calendarList/' + quote(mapping.google_calendar, safe=''))
        if data.get('accessRole') not in ('writer', 'owner'):
            raise AccessError('Selected Google calendar is not writable')
        return {key: data.get(key) for key in ('id', 'summary', 'timeZone', 'accessRole')}

    def _record(self, mapping, event: dict) -> Record:
        marker = event.get('extendedProperties', {}).get('private', {})
        raw = dict(event, ncs_peer_id=marker.get('ncs_page', ''), ncs_mapping=marker.get('ncs_mapping', ''))
        deleted = event.get('status') == 'cancelled'
        values = {'title': event.get('summary', '')}
        for field in ('description', 'location'):
            if mapping.properties.get(field):
                values[field] = event.get(field, '')
        recurrence = event.get('recurrence', [])
        if mapping.properties.get('recurrence'):
            values['recurrence'] = list(recurrence)
        eligible, reason = True, ''
        if event.get('eventType', 'default') != 'default':
            eligible, reason = False, 'Special Google event type is outside synchronization scope'
        if not mapping.allow_attendees and (event.get('attendees') or event.get('attendeesOmitted')):
            eligible, reason = False, 'Events with attendees are excluded to prevent meeting notifications'
        if event.get('locked'):
            eligible, reason = False, 'Locked Google event is not writable'
        if recurrence and not mapping.properties.get('recurrence'):
            eligible, reason = False, 'Recurring series requires a mapped recurrence property'
        if event.get('recurringEventId') and not mapping.properties.get('recurrence'):
            eligible, reason = False, 'Recurring occurrence requires configured recurrence support'
        try:
            if recurrence:
                _recurrence(recurrence)
            start, end = event.get('start', {}), event.get('end', {})
            if start.get('date'):
                values['time'] = normalize_time(start['date'], end.get('date'), mapping.timezone, mapping.default_duration_minutes)
            elif start.get('dateTime'):
                tz = _google_timezone(start.get('timeZone') or end.get('timeZone') or mapping.timezone)
                values['time'] = normalize_time(start['dateTime'], end.get('dateTime'), tz, mapping.default_duration_minutes)
            elif not deleted:
                eligible, reason = False, 'Incomplete Google event start/end response'
        except (ValueError, TypeError, OverflowError, KeyError, ProviderError):
            eligible, reason = False, 'Invalid or unsupported Google event time/recurrence'
        return Record(str(event['id']), values, event.get('etag', ''), deleted, eligible,
                      reason, event.get('htmlLink', ''), raw)

    def scan(self, mapping, cursor=None, full=False) -> Scan:
        self.last_reset = False
        while True:
            query = {'maxResults': 250, 'singleEvents': 'false', 'showDeleted': 'true'}
            if cursor and not full:
                query['syncToken'] = cursor
            rows, seen = [], set()
            try:
                while True:
                    data = self._request('GET', self._events_path(mapping) + '?' + urlencode(query))
                    if not isinstance(data.get('items', []), list):
                        raise ProviderError('Incomplete Google events response')
                    rows.extend(self._record(mapping, event) for event in data.get('items', []))
                    if not data.get('nextPageToken'):
                        token = data.get('nextSyncToken')
                        if not token:
                            raise ProviderError('Google completed response omitted synchronization token')
                        return Scan(rows, token, full_membership='syncToken' not in query)
                    token = data['nextPageToken']
                    if token in seen:
                        raise ProviderError('Repeated Google pagination token')
                    seen.add(token)
                    query['pageToken'] = token
            except ProviderError as exc:
                if exc.status == 410 and cursor and not full:
                    full, cursor, self.last_reset = True, None, True
                    continue
                raise

    def get(self, mapping, id) -> Record:
        try:
            event = self._request('GET', self._events_path(mapping) + '/' + quote(id, safe=''))
        except ProviderError as exc:
            # A 410 HTTP status by itself can also mean an expired collection token;
            # require an explicit cancelled event payload before propagating deletion.
            if exc.status == 410:
                raise AccessError('Google event no longer retrievable; deletion not proven', 410) from None
            raise
        if not event.get('id'):
            raise ProviderError('Incomplete Google event response')
        return self._record(mapping, event)

    def _body(self, mapping, values: dict, *, occurrence: bool = False) -> dict:
        output = {}
        for field, value in values.items():
            if field == 'title':
                output['summary'] = str(value)
            elif field in ('description', 'location') and mapping.properties.get(field):
                output[field] = str(value)
            elif field == 'time':
                if not value:
                    raise ProviderError('Cleared dates pause synchronization')
                canonical = normalize_time(value['start'], value['end'], value['timezone'], mapping.default_duration_minutes)
                if canonical['all_day']:
                    # PATCH merges nested objects; clear the previous representation.
                    output['start'] = {'date': canonical['start'], 'dateTime': None, 'timeZone': None}
                    output['end'] = {'date': canonical['end'], 'dateTime': None, 'timeZone': None}
                else:
                    output['start'] = {'date': None, 'dateTime': canonical['start'], 'timeZone': canonical['timezone']}
                    output['end'] = {'date': None, 'dateTime': canonical['end'], 'timeZone': canonical['timezone']}
            elif field == 'recurrence':
                if occurrence:
                    if value:
                        raise ProviderError('An occurrence cannot be changed into a recurring series')
                elif mapping.properties.get('recurrence'):
                    output['recurrence'] = _recurrence(value)
        return output

    @staticmethod
    def event_id(operation_id: str) -> str:
        return 'ncs' + hashlib.sha256(operation_id.encode()).hexdigest()[:40]

    def create(self, mapping, values, operation_id, peer_id='', *, recovery_only=False) -> Record:
        id = self.event_id(operation_id)
        body = self._body(mapping, values)
        if not body.get('start'):
            raise ProviderError('Google creation requires a valid event time')
        body.update(id=id, extendedProperties={'private': {'ncs_page': peer_id,
                                                           'ncs_mapping': mapping.name,
                                                           'ncs_operation': operation_id}})
        try:
            data = self._request('POST', self._events_path(mapping) + '?sendUpdates=none', body=body, safe=True)
        except ProviderError as exc:
            if exc.status != 409:
                raise
            current = self.get(mapping, id)
            private = current.raw.get('extendedProperties', {}).get('private', {})
            if private.get('ncs_operation') != operation_id or private.get('ncs_page') != peer_id:
                raise ProviderError('Deterministic Google event ID is already used by another item') from None
            return current
        if not data.get('id'):
            raise AmbiguousWrite('Google creation response omitted event identity')
        return self._record(mapping, data)

    def update(self, mapping, id, values, version='') -> Record:
        current = self.get(mapping, id)
        if current.deleted or not current.eligible:
            raise PreconditionFailed('Google item deleted or ineligible before update')
        if version and current.version != version:
            raise PreconditionFailed('Google event changed before update')
        body = self._body(mapping, values, occurrence=bool(current.raw.get('recurringEventId')))
        if not body:
            return current
        # Conditional PATCH cannot be replayed after a lost response; engine refetches.
        data = self._request('PATCH', self._events_path(mapping) + '/' + quote(id, safe='') + '?sendUpdates=none',
                             body=body, safe=False, version=current.version)
        return self._record(mapping, data)

    def archive(self, mapping, id, version='') -> Record:
        try:
            current = self.get(mapping, id)
        except AccessError as exc:
            # Only archive() is called with an already-proven peer deletion and durable intent.
            # Google 410 after our previous DELETE is an idempotent completion, never a scan tombstone.
            if exc.status == 410:
                return Record(id, {}, deleted=True, raw={'status': 'cancelled'})
            raise
        if current.deleted:
            return current
        if not current.eligible:
            raise PreconditionFailed('Google event became ineligible before cancellation')
        if version and current.version != version:
            raise PreconditionFailed('Google event changed before cancellation')
        try:
            self._request('DELETE', self._events_path(mapping) + '/' + quote(id, safe='') + '?sendUpdates=none',
                          version=current.version, safe=False)
        except ProviderError as exc:
            if exc.status != 410:
                raise
        current.deleted = True
        current.raw['status'] = 'cancelled'
        return current

    def set_links(self, mapping, id, peer_id, peer_url='') -> Record:
        current = self.get(mapping, id)
        if current.deleted:
            return current
        if not current.eligible:
            raise PreconditionFailed('Google event became ineligible before linking')
        private = dict(current.raw.get('extendedProperties', {}).get('private', {}))
        if private.get('ncs_page') and not _same_uuid(private['ncs_page'], peer_id):
            # Recurring instances can inherit their master's private metadata. Override
            # only after proving that this is exactly the master's marker, never an
            # independent instance link. The instance ID remains the mutation target.
            inherited = False
            if current.raw.get('recurringEventId'):
                master = self.get(mapping, current.raw['recurringEventId'])
                master_private = master.raw.get('extendedProperties', {}).get('private', {})
                inherited = (master_private.get('ncs_mapping') == mapping.name and
                             master_private.get('ncs_page') == private.get('ncs_page'))
            if not inherited:
                raise PreconditionFailed('Google event is already linked to another Notion page')
        if private.get('ncs_mapping') and private['ncs_mapping'] != mapping.name:
            raise PreconditionFailed('Google event is already linked in a different mapping')
        body = {}
        if private.get('ncs_page') != peer_id or private.get('ncs_mapping') != mapping.name:
            private.update(ncs_page=peer_id, ncs_mapping=mapping.name)
            body['extendedProperties'] = {'private': private}
        # Google only exposes source to the creator; do not replace unrelated source metadata.
        source = current.raw.get('source', {})
        if peer_url and (not source or source.get('title') == 'Notion (NCS)'):
            desired = {'url': peer_url, 'title': 'Notion (NCS)'}
            if source != desired:
                body['source'] = desired
        if not body:
            return current
        data = self._request('PATCH', self._events_path(mapping) + '/' + quote(id, safe='') + '?sendUpdates=none',
                             body=body, safe=False, version=current.version)
        return self._record(mapping, data)

    def watch(self, mapping, channel_id, token, address) -> dict:
        if not address.startswith('https://'):
            raise ProviderError('Google webhook URL must use public HTTPS')
        body = {'id': channel_id, 'type': 'web_hook', 'address': address, 'token': token,
                'expiration': str(int((time.time() + 6 * 24 * 3600) * 1000))}
        return self._request('POST', self._events_path(mapping) + '/watch', body=body, safe=False)

    def stop_channel(self, id, resource_id):
        return self._request('POST', '/channels/stop', body={'id': id, 'resourceId': resource_id}, safe=True)
