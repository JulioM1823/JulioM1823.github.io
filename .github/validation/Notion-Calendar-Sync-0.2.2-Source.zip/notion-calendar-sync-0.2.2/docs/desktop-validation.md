# Desktop release validation — 2026-11-09

This records the initial 0.2.0 release. The [0.2.1 follow-up](desktop-platform-validation-20261109.md) now provides successful native Windows and Intel Mac runs plus real-provider desktop checks; its results supersede the unverified-platform boundaries below.

Release: **0.2.0**. The desktop UI reuses the existing engine, SQLite journal, conflict policy, reversible two-way deletion and bounded gzip transport. It uses a separate per-user desktop directory and native credential vault. The existing Raspberry Pi deployment was not modified or restarted as part of desktop packaging.

## Actually tested

- **262 automated tests passed in 5.043 seconds on the macOS Apple Silicon build host** (Python 3.14.0). This includes the original 196 sync tests and 66 desktop tests. The existing tests cover duplicate prevention, mapped-field preservation, independent/concurrent edits, deletion/cancellation, time zones/DST, recurrence exceptions, pagination, throttling, expired tokens, permission loss, interrupted writes and repeated reconciliation.
- Desktop tests exercise read-only preview write guards, first-sync consent, stale/expired preview rejection, backups, unchanged-pair identity retention, reconnect/OAuth storage hooks, bounded native credential chunking, interrupted credential updates, diagnostics allowlisting, worker/process supervision, malformed configuration and pending conflict resolution.
- Nine native Tk UI tests construct the wizard and all pages, verify typed mapping and explicit confirmation, and exercise an asynchronous mocked setup-to-dashboard flow. Nine discovery tests cover duplicate names, pagination, database/data-source IDs/URLs, multiple data sources and writable calendars.
- The source and frozen macOS application both passed the offline `--smoke-test`: actual native window creation and clean shutdown, with no account/network operations. Computer use also opened the packaged application normally and visually verified the real connection/setup window, with no accounts connected and no Pi configuration imported.
- A real **macOS Keychain** create/read/update/delete roundtrip passed in a unique disposable service namespace; the entry was removed. Existing user credentials were not read. [Aggregate native credential evidence](desktop-native-credentials.json).
- OAuth tests use a real localhost callback server with a fake Google token response. They prove PKCE/state checking (including rejection of a wrong state), native-storage hooks, refresh/cancellation behavior and absence of plaintext client/token files. They do not claim Google consent or arbitrary user account grants were tested live.
- Cross-platform tests mock Windows Credential Manager, byte-range process locks, startup registry writes and filesystem portability. Native Windows credential blobs are bounded/chunked and checksum-verified; no plaintext fallback exists.
- Packaging tests verify source allowlists, runtime hash enforcement, traversal rejection and exclusion of observed Pi configuration, private reports, screenshots, credentials, state and backups. Final portable archives are checked for required runtime/Tk/time-zone components and known credential exclusion. Source modules in the Windows archive are compared byte-for-byte with the release source.

## Downloads and build boundaries

- **macOS:** actual `.app` and `.dmg` bundles include a bundled Python/Tk runtime and dependency license notices. The `universal2` download contains both Apple Silicon and Intel machine code; an `arm64`-only alternative is also available. Execution was tested on this Apple Silicon Mac. **Intel execution is unverified**, even though its machine code is included. Builds are ad-hoc signed by the build tooling but **not signed with a trusted Developer ID or notarized**; normal macOS download approval may be required.
- **Windows x64:** an actual portable application ZIP and optional per-user installer are assembled here from the hash-pinned official full Windows Python runtime, Tcl/Tk, timezone data and app source. It requires no preinstalled Python, administrator rights or network access to install. **Windows execution is unverified**: native Credential Manager calls, GUI rendering, shortcuts, installer execution and startup-at-login must be validated on Windows. The artifact manifest marks this explicitly.
- **Native frozen Windows executable:** build definitions and CI jobs are included. This Windows-native build was not executed here and is not represented as a locally tested download. The separate private-runtime Windows ZIP above is the actual Windows artifact assembled on this host.
- `.github/workflows/desktop-build.yml` provides native OS/CPU tests and builds when the owner runs it in an appropriate repository. No remote repository was created, no code was published and no workflow run is implied.

Every artifact has a SHA-256 sibling and a machine-readable build manifest. Checksums are integrity aids, not a trusted signing identity. The source ZIP uses a generic README and a strict documentation/configuration allowlist so personal Pi deployment evidence is not distributed. Build outputs live under `dist/desktop/`.

## Account setup still required for a new user

Each user must create/grant a Notion integration, supply their own Google Desktop OAuth client, authorize Calendar access in their browser, select the intended source/calendar and review the mapping/preview. The application guides these steps but cannot grant itself Notion access or create a universally verified Google OAuth identity without developer account setup. Google External/Testing credentials can expire after seven days; follow the production/Workspace guidance in the [user guide](desktop.md).

Never run the Pi sync, another desktop instance or another sync provider against the same logical pair concurrently. Local process locks protect one computer; separate computers do not share a lock. Database and calendar selection/mapping changes pause the current worker and require a fresh preview; old state/identities are retained in their original profile. Restoring credentials alone is not a substitute for migrating the relationship history.

Live API behavior of the underlying engine was previously exercised on the Pi, including both deletion directions and bandwidth optimization. Those earlier results do not establish live account setup success for this new desktop shell. No real user events were created, modified or deleted during desktop validation.
