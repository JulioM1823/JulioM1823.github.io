"""Desktop account discovery uses API pagination and explicit stable identities."""
import tempfile
import unittest
from pathlib import Path

from notion_calendar_sync.desktop_backend import DesktopController, notion_id, suggest_mapping
from notion_calendar_sync.http import AccessError, ProviderError


SOURCE = 'd16a3bdc-2654-4788-a891-59c023e3d1f1'
OTHER = 'e26b4ced-3765-4899-b9a2-60d134f4e2a2'
DATABASE = 'f37c5dfe-4876-49aa-8ab3-71e24505f3b3'


class Secrets:
    def get(self, key):return None
    def set(self, key, value):raise AssertionError('Discovery must not change credentials')
    def delete(self, key):raise AssertionError('Discovery must not change credentials')


class Provider:
    def __init__(self, *responses):self.responses=list(responses);self.calls=[]
    def _request(self, method, path, **kwargs):
        self.calls.append((method, path, kwargs))
        response=self.responses.pop(0)
        if isinstance(response, Exception):raise response
        return response


class DesktopDiscoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.notion,self.google=Provider(),Provider()
        self.controller=DesktopController(directory=Path(self.temp.name),secret_store=Secrets(),
             provider_factory=lambda _: (self.notion,self.google),autorun=False)
        self.addCleanup(self.controller.close)

    def test_database_search_paginates_duplicate_names_without_merging_ids(self):
        title=[{'plain_text':'My calendar'}]
        self.notion.responses=[{'results':[{'id':SOURCE,'title':title,'parent':{'database_id':DATABASE}}], 'has_more':True,'next_cursor':'page-2'},
                               {'results':[{'id':OTHER,'title':title}], 'has_more':False}]
        rows=self.controller.databases('calendar')
        self.assertEqual([r['id'] for r in rows],[SOURCE,OTHER])
        self.assertEqual(rows[0]['name'],rows[1]['name'])
        self.assertEqual(rows[0]['database_id'],DATABASE)
        self.assertEqual(self.notion.calls[1][2]['body']['start_cursor'],'page-2')
        self.assertEqual(self.notion.calls[0][2]['body']['query'],'calendar')
        self.assertTrue(all(call[0]=='POST' and call[2]['safe'] for call in self.notion.calls))

    def test_search_rejects_missing_or_repeated_page_cursor(self):
        for results in [[{'results':[], 'has_more':True}],
                        [{'results':[], 'has_more':True,'next_cursor':'same'}, {'results':[],'has_more':True,'next_cursor':'same'}]]:
            with self.subTest(results=results):
                self.notion.responses=results
                with self.assertRaises(ProviderError):self.controller.databases()

    def test_database_id_and_url_show_all_internal_data_sources(self):
        self.notion.responses=[{'object':'database','data_sources':[{'id':SOURCE,'name':'Research'},{'id':OTHER,'name':'Research'}]}]
        rows=self.controller.data_sources('https://www.notion.so/My-Calendar-'+DATABASE.replace('-','')+'?v='+OTHER.replace('-',''))
        self.assertEqual([r['id'] for r in rows],[SOURCE,OTHER])
        self.assertEqual(self.notion.calls[0][1],'/databases/'+DATABASE)

    def test_direct_data_source_id_falls_back_to_data_source_endpoint(self):
        self.notion.responses=[AccessError('Not a database',404),{'object':'data_source','id':SOURCE,'title':[{'text':{'content':'Direct source'}}]}]
        rows=self.controller.data_sources(SOURCE)
        self.assertEqual(rows,[{'id':SOURCE,'name':'Direct source'}])
        self.assertEqual(self.notion.calls[-1][1],'/data_sources/'+SOURCE)

    def test_permission_loss_does_not_create_a_database_or_property(self):
        self.notion.responses=[AccessError('No access',403),AccessError('No access',404)]
        with self.assertRaises(AccessError):self.controller.data_sources(DATABASE)
        self.assertTrue(all(call[0]=='GET' for call in self.notion.calls))

    def test_calendars_paginates_and_excludes_readonly_calendars(self):
        self.google.responses=[{'items':[{'id':'owner','summary':'Same name','accessRole':'owner'}, {'id':'reader','summary':'Read only','accessRole':'reader'}], 'nextPageToken':'a/b'},
                               {'items':[{'id':'writer','summary':'Same name','summaryOverride':'My calendar','accessRole':'writer'}]}]
        rows=self.controller.calendars()
        self.assertEqual(rows,[{'id':'owner','name':'Same name'},{'id':'writer','name':'My calendar'}])
        self.assertIn('pageToken=a%2Fb',self.google.calls[1][1])
        self.assertTrue(all('minAccessRole=writer' in call[1] for call in self.google.calls))

    def test_calendar_repeated_cursor_is_not_accepted(self):
        self.google.responses=[{'items':[],'nextPageToken':'again'},{'items':[],'nextPageToken':'again'}]
        with self.assertRaises(ProviderError):self.controller.calendars()

    def test_mapping_suggestions_are_typed_and_do_not_reuse_a_property(self):
        schema={'properties':{'Task':{'id':'title','type':'title'},'When':{'id':'D','type':'date'},'Note':{'id':'N','type':'rich_text'},
                              'Location':{'id':'L','type':'number'},'Google calendar':{'id':'G','type':'url'},'NCS Event ID':{'id':'I','type':'rich_text'}}}
        mapping=suggest_mapping(schema)
        self.assertEqual(mapping['title'],'Task');self.assertEqual(mapping['date'],'When')
        self.assertEqual(mapping['google_event_id'],'NCS Event ID');self.assertEqual(mapping['location'],'')
        used=[value for value in mapping.values() if value]
        self.assertEqual(len(set(used)),len(used))
        self.assertEqual(schema['properties']['Location']['type'],'number')

    def test_identity_parser_accepts_slugged_urls_and_rejects_ambiguity(self):
        self.assertEqual(notion_id('https://www.notion.so/work/Calendar-'+SOURCE.replace('-','')+'?v='+OTHER.replace('-','')),SOURCE)
        self.assertEqual(notion_id(SOURCE.replace('-','')),SOURCE)
        for invalid in ['My calendar','https://www.notion.so/'+SOURCE+'/'+OTHER,'']:
            with self.assertRaises(ValueError):notion_id(invalid)
