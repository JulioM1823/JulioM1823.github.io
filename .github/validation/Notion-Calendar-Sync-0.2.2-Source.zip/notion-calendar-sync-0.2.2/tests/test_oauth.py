import json
import os
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch
import threading
import urllib.parse
import urllib.request
import hashlib
import base64
from notion_calendar_sync.http import ProviderError, ReauthRequired
from notion_calendar_sync.oauth import TokenManager, secure_write, load_client, SCOPES, authorize


class FakeTransport:
    def __init__(self, result): self.result = result; self.calls = []
    def request(self, *args, **kwargs):
        self.calls.append((args, kwargs))
        if isinstance(self.result, Exception): raise self.result
        return self.result


class OAuthTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.client = Path(self.tmp.name) / 'client.json'
        self.token = Path(self.tmp.name) / 'token.json'
        self.client.write_text(json.dumps({'installed': {'client_id': 'client', 'client_secret': 'secret'}}))

    def test_private_atomic_token_file(self):
        secure_write(self.token, {'access_token': 'one'})
        if os.name != 'nt':  # POSIX modes are not Windows ACLs; native vault is tested separately.
            self.assertEqual(self.token.stat().st_mode & 0o777, 0o600)
        secure_write(self.token, {'access_token': 'two'})
        self.assertEqual(json.loads(self.token.read_text())['access_token'], 'two')
        self.assertEqual(len(list(Path(self.tmp.name).iterdir())), 2)

    def test_cached_access_token(self):
        secure_write(self.token, {'access_token': 'cached', 'expires_at': time.time() + 3600})
        transport = FakeTransport({})
        self.assertEqual(TokenManager(self.client, self.token, transport).access_token(), 'cached')
        self.assertFalse(transport.calls)

    def test_refresh_and_persist_preserves_refresh_token(self):
        secure_write(self.token, {'access_token': 'old', 'refresh_token': 'offline', 'expires_at': 0})
        transport = FakeTransport({'access_token': 'new', 'expires_in': 3600})
        self.assertEqual(TokenManager(self.client, self.token, transport).access_token(), 'new')
        saved = json.loads(self.token.read_text())
        self.assertEqual(saved['refresh_token'], 'offline')
        self.assertGreater(saved['expires_at'], time.time())
        self.assertEqual(transport.calls[0][1]['form']['grant_type'], 'refresh_token')

    def test_revoked_refresh_clear_reauthorization(self):
        secure_write(self.token, {'refresh_token': 'offline'})
        transport = FakeTransport(ProviderError('no', 400, 'invalid_grant'))
        with self.assertRaises(ReauthRequired): TokenManager(self.client, self.token, transport).access_token()

    def test_missing_token(self):
        with self.assertRaises(ReauthRequired): TokenManager(self.client, self.token).access_token()

    def test_web_client_rejected(self):
        self.client.write_text('{"web":{"client_id":"x"}}')
        with self.assertRaises(ReauthRequired): load_client(self.client)

    def test_no_full_calendar_scope(self):
        self.assertNotIn('https://www.googleapis.com/auth/calendar', SCOPES)


class OAuthLoopbackTests(unittest.TestCase):
    def test_pkce_and_state_roundtrip_persists_offline_token(self):
        with tempfile.TemporaryDirectory() as tmp:
            client, token = Path(tmp) / 'client.json', Path(tmp) / 'token.json'
            client.write_text(json.dumps({'installed': {'client_id': 'id', 'client_secret': 'secret'}}))
            transport = FakeTransport({'access_token': 'access', 'refresh_token': 'refresh', 'expires_in': 3600})
            browser_requests = []
            threads = []
            def browser(url):
                values = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
                browser_requests.append(values)
                callback = values['redirect_uri'][0] + '?' + urllib.parse.urlencode({'code': 'test-code', 'state': values['state'][0]})
                def send_callback():
                    with urllib.request.urlopen(callback, timeout=3) as response:
                        response.read()
                thread = threading.Thread(target=send_callback)
                threads.append(thread); thread.start()
            with patch('notion_calendar_sync.oauth.webbrowser.open', side_effect=browser), patch('builtins.print'):
                result = authorize(client, token, transport=transport, timeout=5)
            for thread in threads: thread.join(timeout=5)
            self.assertTrue(result['authorized'])
            self.assertEqual(json.loads(token.read_text())['refresh_token'], 'refresh')
            form = transport.calls[0][1]['form']
            challenge = base64.urlsafe_b64encode(hashlib.sha256(form['code_verifier'].encode()).digest()).rstrip(b'=').decode()
            self.assertEqual(browser_requests[0]['code_challenge'], [challenge])
            self.assertEqual(browser_requests[0]['code_challenge_method'], ['S256'])
            self.assertEqual(form['code'], 'test-code')
            if os.name != 'nt':  # POSIX modes are not Windows ACLs; native vault is tested separately.
                self.assertEqual(token.stat().st_mode & 0o777, 0o600)
