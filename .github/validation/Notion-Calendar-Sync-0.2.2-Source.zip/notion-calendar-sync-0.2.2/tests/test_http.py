import io
import json
import unittest
import urllib.error
from notion_calendar_sync.http import (Transport, AccessError, AmbiguousWrite, ProviderError,
                                       ReauthRequired, RetryableError, PreconditionFailed)


class Response(io.BytesIO):
    def __enter__(self): return self
    def __exit__(self, *args): self.close()


class Opener:
    def __init__(self, *results): self.results = list(results); self.calls = []
    def open(self, req, timeout):
        self.calls.append(req)
        result = self.results.pop(0)
        if isinstance(result, Exception): raise result
        return Response(json.dumps(result).encode())


def error(status, body=None, headers=None):
    return urllib.error.HTTPError('https://provider.invalid', status, 'secret error detail', headers or {},
                                  io.BytesIO(json.dumps(body or {}).encode()))


class TransportTests(unittest.TestCase):
    def make(self, *results):
        self.sleeps = []
        self.opener = Opener(*results)
        return Transport(opener=self.opener, sleep=self.sleeps.append,
                         monotonic=lambda: 0, random_uniform=lambda *_: 0)

    def test_rate_limit_honors_retry_after(self):
        transport = self.make(error(429, headers={'Retry-After': '2'}), {'ok': True})
        self.assertEqual(transport.request('GET', 'https://provider.invalid'), {'ok': True})
        self.assertGreaterEqual(max(self.sleeps), 2)

    def test_network_get_retries(self):
        transport = self.make(urllib.error.URLError('secret'), {'ok': True})
        self.assertTrue(transport.request('GET', 'https://provider.invalid')['ok'])
        self.assertEqual(len(self.opener.calls), 2)

    def test_ambiguous_create_does_not_retry(self):
        transport = self.make(error(503), {'duplicate': True})
        with self.assertRaises(AmbiguousWrite):
            transport.request('POST', 'https://provider.invalid', body={'x': 1})
        self.assertEqual(len(self.opener.calls), 1)

    def test_network_create_ambiguous(self):
        transport = self.make(urllib.error.URLError('secret'))
        with self.assertRaises(AmbiguousWrite): transport.request('POST', 'https://provider.invalid')

    def test_safe_deterministic_create_retries(self):
        transport = self.make(error(503), {'ok': True})
        self.assertTrue(transport.request('POST', 'https://provider.invalid', safe=True)['ok'])

    def test_permission_missing_never_deleted(self):
        for status in (403, 404):
            transport = self.make(error(status))
            with self.assertRaises(AccessError): transport.request('GET', 'https://provider.invalid')
            self.assertEqual(len(self.opener.calls), 1)

    def test_401_requires_authorization(self):
        with self.assertRaises(ReauthRequired): self.make(error(401)).request('GET', 'https://provider.invalid')

    def test_http_error_responses_are_closed_on_retry_and_failure(self):
        limited = error(429)
        self.make(limited, {'ok': True}).request('GET', 'https://provider.invalid')
        self.assertTrue(limited.closed)
        rejected = error(401)
        with self.assertRaises(ReauthRequired):
            self.make(rejected).request('GET', 'https://provider.invalid')
        self.assertTrue(rejected.closed)

    def test_412_requires_remerge(self):
        with self.assertRaises(PreconditionFailed): self.make(error(412)).request('PATCH', 'https://provider.invalid')

    def test_bounded_retries(self):
        transport = self.make(*(error(529) for _ in range(4)))
        with self.assertRaises(RetryableError): transport.request('GET', 'https://provider.invalid')
        self.assertEqual(len(self.opener.calls), 4)

    def test_errors_do_not_expose_response_body(self):
        transport = self.make(error(400, {'error': {'message': 'credential-secret'}, 'detail': 'private event'}))
        with self.assertRaises(ProviderError) as caught: transport.request('GET', 'https://provider.invalid')
        self.assertNotIn('secret', str(caught.exception))
        self.assertNotIn('private', str(caught.exception))

    def test_https_required(self):
        with self.assertRaises(ProviderError): self.make().request('GET', 'http://provider.invalid')

    def test_retry_after_body(self):
        self.assertEqual(Transport._retry_after(None, {'additional_data': {'retry_after': '4'}}), 4)


class CompressionTests(unittest.TestCase):
    def response(self, raw, encoding='gzip'):
        response = Response(raw)
        response.headers = {'Content-Encoding': encoding}
        return response

    def transport(self, response):
        class RawOpener:
            def open(self, req, timeout):
                self.request = req
                return response
        opener = RawOpener()
        return Transport(opener=opener), opener

    def test_gzip_preserves_complete_unicode_document_and_negotiates(self):
        import gzip
        document = {'items': [{'title': 'Café 🌌', 'unrelated': {'metadata': [1, 2]}}],
                    'nextPageToken': 'page-two', 'nextSyncToken': 'cursor'}
        response = self.response(gzip.compress(json.dumps(document, ensure_ascii=False).encode()))
        transport, opener = self.transport(response)
        self.assertEqual(transport.request('GET', 'https://provider.invalid'), document)
        self.assertEqual(opener.request.get_header('Accept-encoding'), 'gzip')
        self.assertIn('gzip', opener.request.get_header('User-agent'))
        self.assertTrue(response.closed)

    def test_uncompressed_fallback_is_identical(self):
        for encoding in ('', 'identity'):
            response = self.response(b'{"items": [], "nextSyncToken": "unchanged"}', encoding)
            transport, _ = self.transport(response)
            self.assertEqual(transport.request('GET', 'https://provider.invalid'),
                             {'items': [], 'nextSyncToken': 'unchanged'})

    def test_corrupt_truncated_trailing_and_unsupported_responses_fail_closed(self):
        import gzip
        good = gzip.compress(b'{"items": []}')
        cases = [(good[:-4], 'gzip'), (good+b'extra', 'gzip'), (b'private invalid gzip', 'gzip'),
                 (good[:-8]+b'12345678', 'gzip'), (b'{}', 'br'),
                 (gzip.compress(b'{"partial":'), 'gzip')]
        for raw, encoding in cases:
            with self.subTest(encoding=encoding, raw_length=len(raw)):
                response = self.response(raw, encoding)
                transport, _ = self.transport(response)
                with self.assertRaises(RetryableError) as caught:
                    transport.request('GET', 'https://provider.invalid')
                self.assertNotIn('private', str(caught.exception))
                self.assertTrue(response.closed)

    def test_invalid_compressed_create_is_ambiguous_and_not_replayed(self):
        response = self.response(b'bad-gzip')
        transport, _ = self.transport(response)
        with self.assertRaises(AmbiguousWrite):
            transport.request('POST', 'https://provider.invalid', body={'title': 'private'})
        self.assertTrue(response.closed)

    def test_compressed_and_expanded_size_limits(self):
        import gzip
        for raw, encoding in [(b'x'*101, ''), (gzip.compress(b' '*101), 'gzip')]:
            with self.assertRaises(ValueError):
                Transport._read_json(self.response(raw, encoding), limit=100)

    def test_compressed_rate_limit_and_permission_errors_keep_semantics(self):
        import gzip
        for code in (403, 404, 429, 503):
            err = urllib.error.HTTPError('https://provider.invalid', code, 'private',
                    {'Content-Encoding': 'gzip', 'Retry-After': '0'},
                    io.BytesIO(gzip.compress(b'{"code": "test"}')))
            opener = Opener(err, {'ok': True})
            transport = Transport(opener=opener, sleep=lambda _: None)
            if code in (403, 404):
                with self.assertRaises(AccessError):
                    transport.request('GET', 'https://provider.invalid')
                self.assertEqual(len(opener.calls), 1)
            else:
                self.assertEqual(transport.request('GET', 'https://provider.invalid'), {'ok': True})
            self.assertTrue(err.closed)
