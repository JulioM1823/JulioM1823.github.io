import os
from datetime import datetime
from pathlib import Path
import tempfile
import unittest

from notion_calendar_sync.config import ConfigError, load_config
from notion_calendar_sync.model import normalize_time, merge_fields
from notion_calendar_sync.store import Store


class ModelTests(unittest.TestCase):
    def test_all_day_default_and_exclusive_multi_day(self):
        self.assertEqual(normalize_time('2026-10-30')['end'], '2026-10-31')
        self.assertEqual(normalize_time('2026-10-30', '2026-11-03')['end'], '2026-11-03')

    def test_offsets_and_timezone_changes_keep_instant(self):
        value = normalize_time('2026-10-30T12:00:00-06:00', '2026-10-30T13:00:00-06:00', 'America/New_York')
        self.assertEqual(value['start'], '2026-10-30T14:00:00-04:00')
        self.assertEqual(value['timezone'], 'America/New_York')

    def test_dst_spring_default_duration_real_elapsed_hour(self):
        value = normalize_time('2026-03-08T01:30:00-07:00', None, 'America/Denver')
        self.assertEqual(value['end'], '2026-03-08T03:30:00-06:00')

    def test_fall_fold_offsets_remain_distinct_and_valid(self):
        value = normalize_time('2026-11-01T01:30:00-06:00', '2026-11-01T01:30:00-07:00', 'America/Denver')
        self.assertNotEqual(value['start'], value['end'])

    def test_naive_ambiguous_and_nonexistent_time_rejected(self):
        for start in ['2026-11-01T01:30:00', '2026-03-08T02:30:00']:
            with self.subTest(start=start), self.assertRaises(ValueError):
                normalize_time(start, None, 'America/Denver')

    def test_invalid_ranges_rejected(self):
        for start, end in [('2026-10-30', '2026-10-30'), ('2026-10-30T13:00:00Z', '2026-10-30T12:00:00Z'),
                           ('2026-10-30T13:00:00Z', '2026-10-31')]:
            with self.subTest(start=start), self.assertRaises(ValueError):
                normalize_time(start, end)

    def test_independent_merge_and_atomic_schedule(self):
        base = {'title': 'a', 'time': 't', 'recurrence': []}
        merged, conflicts = merge_fields(base, dict(base, title='b'), dict(base, time='u'), base)
        self.assertEqual(conflicts, [])
        self.assertEqual(merged['title'], 'b')
        self.assertEqual(merged['time'], 'u')
        merged, conflicts = merge_fields(base, dict(base, time='u'), dict(base, recurrence=['rule']), base)
        self.assertEqual(conflicts, ['time', 'recurrence'])


class ConfigStoreTests(unittest.TestCase):
    def config_text(self):
        return '''[service]
state_path="state/sync.sqlite3"
[[mappings]]
name="example"
notion_data_source="source"
google_calendar="calendar"
[mappings.properties]
title="Task"
date="Date"
google_event_id="ID"
timezone="Zone"
'''

    def load_text(self, text):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'config.toml'
            path.write_text(text)
            return load_config(path)

    def test_explicit_schema_and_relative_paths(self):
        config = self.load_text(self.config_text())
        self.assertTrue(config.state_path.is_absolute())
        self.assertFalse(config.mappings[0].notion_incremental)
        self.assertEqual(config.mappings[0].properties['title'], 'Task')

    def test_config_errors_prevent_overlap_wrong_fields_and_bad_timing(self):
        text = self.config_text()
        variants = [text.replace('name="example"', 'name="example"\npoll_seconds=1'),
                    text.replace('name="example"', 'name="example"\nconflict_policy="newest"'),
                    text.replace('name="example"', 'name="example"\ntimezone="not/a/zone"'),
                    text.replace('title="Task"', 'title="Date"'),
                    text.replace('google_event_id="ID"', ''),
                    text.replace('[service]', '[service]\npublic_url="http://public.example"'),
                    text.replace('timezone="Zone"', 'typo="Zone"')]
        for variant in variants:
            with self.subTest(config=variant), self.assertRaises(ConfigError):
                self.load_text(variant)

    def test_store_modes_restart_signals_and_backup(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'private' / 'sync.db'
            with Store(path) as store:
                store.signal('notion', signal_id='a')
                store.signal('notion', signal_id='a')
                store.backup(Path(directory) / 'copy.db')
            if os.name != 'nt':  # POSIX modes are not Windows ACLs; native vault is tested separately.
                self.assertEqual(path.stat().st_mode & 0o777, 0o600)
                self.assertEqual(path.parent.stat().st_mode & 0o777, 0o700)
            with Store(path) as store:
                self.assertEqual(store.db.execute('SELECT COUNT(*) FROM signals').fetchone()[0], 1)
            with Store(Path(directory) / 'copy.db') as store:
                self.assertEqual(store.db.execute('SELECT COUNT(*) FROM signals').fetchone()[0], 1)
