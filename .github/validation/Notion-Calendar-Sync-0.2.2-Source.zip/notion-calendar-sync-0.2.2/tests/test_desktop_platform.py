"""Native credential adapters are exercised without touching the user's vault."""
import os
import ctypes
import json
from pathlib import Path
import plistlib
import tempfile
import types
import unittest
from unittest.mock import patch

from notion_calendar_sync.desktop_platform import (
    APP_NAME, SERVICE_NAME, SecretJSONStore, SecretStore, SecretStoreError,
    _Credential, _MacKeychain, _WindowsCredentials, app_data_dir, set_startup,
    startup_enabled,
)


class Function:
    def __init__(self, callback): self.callback = callback
    def __call__(self, *args): return self.callback(*args)


class FakeMac:
    def __init__(self):
        self.items = {}; self.buffers = []; self.freed = 0; self.released = 0
        self.failure = 0; self.race = False
        for name in ('SecKeychainFindGenericPassword', 'SecKeychainAddGenericPassword',
                     'SecKeychainItemModifyAttributesAndData', 'SecKeychainItemDelete',
                     'SecKeychainItemFreeContent', 'CFRelease'):
            setattr(self, name, Function(getattr(self, name.removeprefix('SecKeychain').replace('CFRelease', 'release'))))

    def FindGenericPassword(self, _, sl, service, al, account, length, data, item):
        if self.failure: return self.failure
        key = (service[:sl], account[:al])
        if key not in self.items: return -25300
        identifier, value = self.items[key]
        ctypes.cast(item, ctypes.POINTER(ctypes.c_void_p))[0] = identifier
        if data is not None:
            buffer = ctypes.create_string_buffer(value); self.buffers.append(buffer)
            ctypes.cast(length, ctypes.POINTER(ctypes.c_uint32))[0] = len(value)
            ctypes.cast(data, ctypes.POINTER(ctypes.c_void_p))[0] = ctypes.cast(buffer, ctypes.c_void_p)
        return 0

    def AddGenericPassword(self, _, sl, service, al, account, size, data, item):
        key = (service[:sl], account[:al])
        if self.race:
            self.race = False; self.items[key] = (100, b'other writer')
            return -25299
        self.items[key] = (100+len(self.items), ctypes.string_at(data, size))
        ctypes.cast(item, ctypes.POINTER(ctypes.c_void_p))[0] = self.items[key][0]
        return 0

    def ItemModifyAttributesAndData(self, item, _, size, data):
        for key, (identifier, value) in self.items.items():
            if identifier == item.value:
                self.items[key] = (identifier, ctypes.string_at(data, size)); return 0
        return -25300

    def ItemDelete(self, item):
        for key, (identifier, _) in list(self.items.items()):
            if identifier == item.value: del self.items[key]; return 0
        return -25300

    def ItemFreeContent(self, *_): self.freed += 1; return 0
    def release(self, *_): self.released += 1


class FakeWindows:
    def __init__(self):
        self.items = {}; self.error = 0; self.freed = 0; self.kept = []; self.denied = False
        for name in ('CredReadW', 'CredWriteW', 'CredDeleteW', 'CredFree'):
            setattr(self, name, Function(getattr(self, '_'+name)))

    def _CredReadW(self, target, kind, flags, output):
        if self.denied: self.error = 5; return 0
        if target not in self.items: self.error = 1168; return 0
        value = self.items[target]
        buffer = (ctypes.c_ubyte*len(value)).from_buffer_copy(value)
        credential = _Credential(Type=1, CredentialBlobSize=len(value), CredentialBlob=buffer)
        pointer = ctypes.pointer(credential); self.kept.extend([buffer, credential, pointer])
        ctypes.cast(output, ctypes.POINTER(ctypes.POINTER(_Credential)))[0] = pointer
        return 1

    def _CredWriteW(self, pointer, flags):
        if self.denied: self.error = 5; return 0
        credential = ctypes.cast(pointer, ctypes.POINTER(_Credential)).contents
        assert credential.Type == 1 and credential.Persist == 2
        self.items[credential.TargetName] = ctypes.string_at(credential.CredentialBlob, credential.CredentialBlobSize)
        return 1

    def _CredDeleteW(self, target, kind, flags):
        if self.denied: self.error = 5; return 0
        if target not in self.items: self.error = 1168; return 0
        del self.items[target]; return 1

    def _CredFree(self, pointer): self.freed += 1


class FakeRegistry:
    HKEY_CURRENT_USER = 1
    REG_SZ = 1
    def __init__(self): self.values = {}
    def __enter__(self): return self
    def __exit__(self, *_): pass
    def CreateKey(self, hive, key): self.last_hive = hive; return self
    def OpenKey(self, hive, key): return self
    def SetValueEx(self, key, name, unused, kind, value): self.values[name] = value
    def QueryValueEx(self, key, name):
        if name not in self.values: raise FileNotFoundError()
        return self.values[name], self.REG_SZ
    def DeleteValue(self, key, name):
        if name not in self.values: raise FileNotFoundError()
        del self.values[name]


class DesktopPlatformTests(unittest.TestCase):
    def test_mac_roundtrip_update_unicode_and_native_memory_release(self):
        api = FakeMac(); store = _MacKeychain('test-service', api, api)
        self.assertIsNone(store.get('notion'))
        store.set('notion', 'sëcret 🌌')
        self.assertEqual(store.get('notion'), 'sëcret 🌌')
        store.set('notion', 'refreshed')
        self.assertEqual(store.get('notion'), 'refreshed')
        self.assertEqual(len(api.items), 1)
        self.assertEqual(api.freed, 2)
        store.delete('notion'); store.delete('notion')
        self.assertIsNone(store.get('notion'))
        self.assertGreater(api.released, api.freed)

    def test_mac_insert_race_updates_existing_credential(self):
        api = FakeMac(); api.race = True
        store = _MacKeychain('test-service', api, api)
        store.set('token', 'winner')
        self.assertEqual(store.get('token'), 'winner')
        self.assertEqual(len(api.items), 1)

    def test_mac_locked_vault_fails_without_writing_or_exposing_secret(self):
        api = FakeMac(); api.failure = -25308
        store = _MacKeychain('test-service', api, api)
        for action in [lambda: store.set('token', 'do-not-log-this'), lambda: store.get('token')]:
            with self.assertRaises(SecretStoreError) as caught: action()
            self.assertNotIn('do-not-log-this', str(caught.exception))
            self.assertIn('Unlock', str(caught.exception))
        self.assertEqual(api.items, {})

    def test_windows_roundtrip_and_native_allocation_release(self):
        api = FakeWindows(); store = _WindowsCredentials('test-service', api, lambda: api.error)
        self.assertIsNone(store.get('token'))
        store.set('token', 'secret 🌌')
        self.assertEqual(store.get('token'), 'secret 🌌')
        store.set('token', 'refreshed')
        self.assertEqual(store.get('token'), 'refreshed')
        self.assertEqual(len(api.items), 1)
        self.assertEqual(api.freed, len(api.kept)//3)
        store.delete('token'); store.delete('token')
        self.assertIsNone(store.get('token'))

    def test_windows_refuses_truncation_and_permission_failure(self):
        api = FakeWindows(); store = _WindowsCredentials('test-service', api, lambda: api.error)
        with self.assertRaises(SecretStoreError): store.set('token', 'x'*(1024*1024+1))
        self.assertFalse(api.items)
        api.denied = True
        with self.assertRaises(SecretStoreError) as caught: store.set('token', 'do-not-log-this')
        self.assertNotIn('do-not-log-this', str(caught.exception))
        self.assertFalse(api.items)

    def test_windows_large_unicode_grant_chunks_roundtrip_replace_and_delete(self):
        api = FakeWindows(); store = _WindowsCredentials('test-service', api, lambda: api.error)
        first = 'token🌌'*2500
        store.set('token', first)
        self.assertEqual(store.get('token'), first)
        self.assertTrue(all(len(value) <= 2560 for value in api.items.values()))
        original_targets = set(api.items)
        store.set('token', 'refreshed grant '*600)
        self.assertEqual(store.get('token'), 'refreshed grant '*600)
        self.assertEqual(set(api.items) & original_targets, {'test-service:token'})
        store.delete('token')
        self.assertFalse(api.items)

    def test_windows_chunk_failure_keeps_old_committed_grant(self):
        api = FakeWindows(); store = _WindowsCredentials('test-service', api, lambda: api.error)
        original = 'old grant '*700
        store.set('token', original)
        original_items = dict(api.items)
        original_write = store.write
        calls = []
        def fail_second(pointer, flags):
            calls.append(True)
            if len(calls) == 2:
                api.error = 5
                return 0
            return original_write(pointer, flags)
        store.write = fail_second
        with self.assertRaises(SecretStoreError): store.set('token', 'new grant '*900)
        self.assertEqual(store.get('token'), original)
        self.assertEqual(api.items, original_items)

    def test_windows_commit_then_process_death_keeps_complete_new_grant(self):
        api = FakeWindows(); store = _WindowsCredentials('test-service', api, lambda: api.error)
        store.set('token', 'old grant '*700)
        original_write = store.write
        def crash_after_commit(pointer, flags):
            result = original_write(pointer, flags)
            credential = ctypes.cast(pointer, ctypes.POINTER(_Credential)).contents
            if credential.TargetName == 'test-service:token':
                raise SystemExit('simulated death after atomic native write')
            return result
        store.write = crash_after_commit
        with self.assertRaises(SystemExit): store.set('token', 'new grant '*900)
        restarted = _WindowsCredentials('test-service', api, lambda: api.error)
        self.assertEqual(restarted.get('token'), 'new grant '*900)

    def test_windows_reader_retries_racing_manifest_cleanup(self):
        api = FakeWindows(); store = _WindowsCredentials('test-service', api, lambda: api.error)
        store.set('token', 'old grant '*700)
        old_manifest = store._manifest(store._read_raw('token'))
        original_read = store._read_raw
        triggered = []
        def racing_read(key):
            if ':chunk:'+old_manifest['generation']+':' in key and not triggered:
                triggered.append(True)
                store.set('token', 'new grant '*900)
            return original_read(key)
        store._read_raw = racing_read
        self.assertEqual(store.get('token'), 'new grant '*900)

    def test_windows_corrupt_chunks_fail_closed_and_reserved_prefix_roundtrips(self):
        api = FakeWindows(); store = _WindowsCredentials('test-service', api, lambda: api.error)
        store.set('token', 'grant '*1000)
        chunk = next(key for key in api.items if ':chunk:' in key)
        api.items[chunk] = b'corrupt-but-private'
        with self.assertRaises(SecretStoreError) as caught: store.get('token')
        self.assertNotIn('private', str(caught.exception))
        store.set('token', store.PREFIX+'literal input')
        self.assertEqual(store.get('token'), store.PREFIX+'literal input')
        store.set('token', 'small replacement')
        self.assertEqual(api.items, {'test-service:token': b'small replacement'})

    def test_windows_corrupt_manifest_can_be_reconnected_or_removed(self):
        api = FakeWindows(); store = _WindowsCredentials('test-service', api, lambda: api.error)
        api.items['test-service:token'] = (store.PREFIX+'invalid-json').encode()
        with self.assertRaises(SecretStoreError): store.get('token')
        store.set('token', 'new authorized grant')
        self.assertEqual(store.get('token'), 'new authorized grant')
        api.items['test-service:token'] = (store.PREFIX+'invalid-json').encode()
        store.delete('token')
        self.assertIsNone(store.get('token'))

    def test_json_adapter_missing_invalid_and_complete_refresh_replacement(self):
        api = FakeMac(); store = SecretStore(backend=_MacKeychain('test-service', api, api))
        tokens = SecretJSONStore(store)
        with self.assertRaises(SecretStoreError): tokens.load()
        original = {'access_token': 'one', 'refresh_token': 'refresh', 'expires_at': 123}
        tokens.save(original); self.assertEqual(tokens.load(), original)
        tokens.save(dict(original, access_token='two', expires_at=456))
        self.assertEqual(tokens.load()['access_token'], 'two')
        store.set('google-token', 'do-not-log-invalid-json')
        with self.assertRaises(SecretStoreError) as caught: tokens.load()
        self.assertNotIn('do-not-log-invalid-json', str(caught.exception))
        tokens.delete()
        self.assertIsNone(store.get('google-token'))

    def test_unsupported_os_fails_closed_and_keys_are_validated(self):
        with self.assertRaises(SecretStoreError): SecretStore(platform='Linux')
        api = FakeMac(); store = SecretStore(backend=_MacKeychain('test-service', api, api))
        for key in ('', 'bad\x00key', 'x'*257, None):
            with self.assertRaises(ValueError): store.set(key, 'secret')
        with self.assertRaises(TypeError): store.set('key', {})
        self.assertFalse(api.items)

    def test_mac_startup_is_opt_in_per_user_and_preserves_exact_arguments(self):
        with tempfile.TemporaryDirectory() as directory:
            self.assertFalse(startup_enabled(platform='Darwin', home=directory))
            command = ['/Applications/Notion Calendar Sync.app/Contents/MacOS/ncs-desktop', '--background']
            set_startup(True, command, platform='Darwin', home=directory)
            path = Path(directory)/'Library'/'LaunchAgents'/(SERVICE_NAME+'.plist')
            data = plistlib.loads(path.read_bytes())
            self.assertEqual(data['ProgramArguments'], command)
            self.assertTrue(data['RunAtLoad'])
            if os.name != 'nt':  # POSIX modes are not Windows ACLs; native vault is tested separately.
                self.assertEqual(path.stat().st_mode & 0o777, 0o600)
            self.assertTrue(startup_enabled(platform='Darwin', home=directory))
            set_startup(False, platform='Darwin', home=directory)
            set_startup(False, platform='Darwin', home=directory)
            self.assertFalse(path.exists())

    def test_windows_startup_uses_current_user_and_quotes_spaces(self):
        registry = FakeRegistry()
        with patch.dict('sys.modules', {'winreg': registry}):
            self.assertFalse(startup_enabled(platform='Windows'))
            set_startup(True, [r'C:\Users\Example User\App\Sync.exe', '--background'], platform='Windows')
            self.assertEqual(registry.last_hive, registry.HKEY_CURRENT_USER)
            self.assertEqual(registry.values[APP_NAME], '"C:\\Users\\Example User\\App\\Sync.exe" --background')
            self.assertTrue(startup_enabled(platform='Windows'))
            set_startup(False, platform='Windows'); set_startup(False, platform='Windows')
            self.assertFalse(startup_enabled(platform='Windows'))

    def test_data_directories_are_separate_from_pi_state(self):
        with tempfile.TemporaryDirectory() as directory:
            mac = app_data_dir(platform='Darwin', home=directory)
            windows = app_data_dir(platform='Windows', home=directory)
            self.assertEqual(mac, Path(directory)/'Library'/'Application Support'/APP_NAME)
            self.assertEqual(windows, Path(directory)/'AppData'/'Local'/APP_NAME)
            if os.name != 'nt':  # POSIX modes are not Windows ACLs; native vault is tested separately.
                self.assertEqual(mac.stat().st_mode & 0o777, 0o700)
            self.assertTrue(windows.is_dir())
