"""Independent regressions for identity ownership and crash/recovery behavior."""
from copy import deepcopy
import hashlib
from pathlib import Path
import tempfile
import unittest

from notion_calendar_sync.config import Config, Mapping
from notion_calendar_sync.engine import Engine
from notion_calendar_sync.http import AccessError, AmbiguousWrite, PreconditionFailed
from notion_calendar_sync.model import Record, normalize_time
from notion_calendar_sync.providers import Scan
from notion_calendar_sync.store import Store


VALUES = {"title": "Example", "time": normalize_time("2026-11-03T10:00:00-07:00", "2026-11-03T11:00:00-07:00", "America/Denver"), "description": "Notes", "location": "Room"}


class MemoryProvider:
    def __init__(self, side):
        self.side = side
        self.records = {}
        self.writes = []
        self.errors = {}
        self.hidden = set()
        self.crash_after = None
        self.counter = 0

    def record(self, identifier, values=None, **kwargs):
        raw = {"parent": {"data_source_id": "source"}} if self.side == "notion" else {}
        raw.update(kwargs.pop("raw", {}))
        record = Record(identifier, deepcopy(values or VALUES), version="v1", raw=raw, url="https://example.test/" + identifier, **kwargs)
        self.records[identifier] = deepcopy(record)
        return record

    def validate(self, mapping):
        return {"validated": True}

    def scan(self, mapping, cursor=None, full=False):
        return Scan([deepcopy(record) for id, record in self.records.items() if id not in self.hidden], "cursor")

    def get(self, mapping, identifier):
        if identifier in self.errors:
            raise self.errors[identifier]
        if identifier not in self.records:
            raise AccessError("Missing access", 404)
        return deepcopy(self.records[identifier])

    def _written(self, action, record):
        self.counter += 1
        record.version = f"v{self.counter + 1}"
        self.records[record.id] = deepcopy(record)
        self.writes.append((action, record.id))
        if self.crash_after == action:
            self.crash_after = None
            raise SystemExit("simulated process death after remote commit")
        return deepcopy(record)

    def create(self, mapping, values, operation_id, peer_id="", *, recovery_only=False):
        for record in self.records.values():
            if record.raw.get("operation_id") == operation_id:
                return deepcopy(record)
        if recovery_only and self.side == "notion":
            raise AmbiguousWrite("Notion marker not visible")
        identifier = self.side + hashlib.sha256(operation_id.encode()).hexdigest()[:20]
        raw = {"operation_id": operation_id, "ncs_peer_id": peer_id}
        if self.side == "google":
            raw["ncs_mapping"] = mapping.name
        else:
            raw["parent"] = {"data_source_id": mapping.notion_data_source}
        return self._written("create", Record(identifier, deepcopy(values), raw=raw))

    def update(self, mapping, identifier, values, version=""):
        record = self.get(mapping, identifier)
        if version and record.version != version:
            raise PreconditionFailed("Version mismatch")
        record.values.update(deepcopy(values))
        return self._written("update", record)

    def archive(self, mapping, identifier, version=""):
        try:
            record = self.get(mapping, identifier)
        except AccessError as error:
            if error.status == 410:
                return Record(identifier, {}, deleted=True)
            raise
        record.deleted = True
        return self._written("archive", record)

    def set_links(self, mapping, identifier, peer_id, peer_url=""):
        record = self.get(mapping, identifier)
        desired = {"ncs_peer_id": peer_id}
        if self.side == "google":
            desired["ncs_mapping"] = mapping.name
        if all(record.raw.get(key) == value for key, value in desired.items()):
            return record
        record.raw.update(desired)
        return self._written("links", record)


class EngineReviewTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.mapping = Mapping("work", "source", "calendar", properties={"title": "Name", "date": "Date", "description": "Notes", "location": "Location", "google_event_id": "Identity"})
        self.config = Config(state_path=Path(self.directory.name) / "state.sqlite3", mappings=[self.mapping])
        self.store = Store(self.config.state_path)
        self.addCleanup(self.store.close)
        self.notion = MemoryProvider("notion")
        self.google = MemoryProvider("google")
        self.engine = Engine(self.config, self.store, self.notion, self.google)

    def linked_pair(self):
        self.notion.record("page", raw={"ncs_peer_id": "event"})
        self.google.record("event", raw={"ncs_peer_id": "page", "ncs_mapping": "work"})
        self.engine.sync(full=True)
        self.notion.writes.clear()
        self.google.writes.clear()

    def test_repeated_reconciliation_and_own_metadata_do_not_write_again(self):
        self.notion.record("page")
        self.engine.sync()
        self.assertEqual(1, len(self.google.records))
        self.notion.writes.clear()
        self.google.writes.clear()
        for full in (False, False, True, True):
            self.engine.sync(full=full)
        self.assertEqual([], self.notion.writes)
        self.assertEqual([], self.google.writes)
        self.assertEqual(1, self.store.db.execute("SELECT COUNT(*) FROM links").fetchone()[0])

    def test_crash_after_google_create_adopts_same_remote_item(self):
        self.notion.record("page")
        self.google.crash_after = "create"
        with self.assertRaises(SystemExit):
            self.engine.sync()
        self.assertEqual("inflight", self.store.db.execute("SELECT status FROM operations").fetchone()[0])
        self.engine = Engine(self.config, self.store, self.notion, self.google)
        self.engine.sync()
        self.assertEqual(1, len(self.google.records))
        self.assertEqual(1, len([write for write in self.google.writes if write[0] == "create"]))
        self.assertEqual("active", self.store.db.execute("SELECT status FROM links").fetchone()[0])

    def test_crash_after_notion_create_recovers_marker_without_second_post(self):
        self.google.record("event")
        self.notion.crash_after = "create"
        with self.assertRaises(SystemExit):
            self.engine.sync()
        self.engine = Engine(self.config, self.store, self.notion, self.google)
        self.engine.sync()
        self.assertEqual(1, len(self.notion.records))
        self.assertEqual(1, len([write for write in self.notion.writes if write[0] == "create"]))

    def test_crash_after_update_reuses_successful_patch_without_feedback(self):
        self.linked_pair()
        self.notion.records["page"].values["title"] = "Edited title"
        self.google.crash_after = "update"
        with self.assertRaises(SystemExit):
            self.engine.sync()
        self.engine = Engine(self.config, self.store, self.notion, self.google)
        self.engine.sync()
        self.engine.sync(full=True)
        self.assertEqual("Edited title", self.google.records["event"].values["title"])
        self.assertEqual(1, len([write for write in self.google.writes if write[0] == "update"]))
        self.assertEqual([], self.notion.writes)
        self.assertEqual(0, self.store.db.execute("SELECT COUNT(*) FROM conflicts WHERE status='open'").fetchone()[0])

    def test_permission_loss_and_scan_absence_never_archive_or_clone(self):
        self.linked_pair()
        self.notion.hidden.add("page")
        self.notion.errors["page"] = AccessError("permission revoked", 403)
        self.engine.sync(full=True)
        self.assertFalse(self.google.records["event"].deleted)
        self.assertEqual([], self.google.writes)
        self.assertEqual(1, len(self.google.records))
        self.assertEqual("retry", self.store.db.execute("SELECT status FROM links").fetchone()[0])

    def test_transient_get_failure_retries_next_poll_even_when_scan_unchanged(self):
        self.linked_pair()
        self.notion.records["page"].values["title"] = "User edit"
        self.notion.errors["page"] = AccessError("temporarily unavailable", 503)
        self.engine.sync()
        self.assertEqual("Example", self.google.records["event"].values["title"])
        del self.notion.errors["page"]
        self.engine.sync()
        self.assertEqual("User edit", self.google.records["event"].values["title"])

    def test_unmatched_transient_get_failure_retries_next_poll(self):
        self.notion.record("page")
        self.notion.errors["page"] = AccessError("temporarily unavailable", 503)
        self.engine.sync()
        self.assertEqual(0, len(self.google.records))
        del self.notion.errors["page"]
        self.engine.sync()
        self.assertEqual(1, len(self.google.records))

    def test_pending_update_rechecks_current_stable_identity_before_write(self):
        self.linked_pair()
        link_id = self.store.db.execute("SELECT id FROM links").fetchone()[0]
        self.notion.records["page"].values["title"] = "Pending user title"
        self.engine._enqueue(self.mapping, link_id, "google", "update", {
            "patch": {"title": "Pending user title"}, "expected": {"title": "Example"},
            "source_side": "notion", "source_id": "page", "source_expected": {"title": "Pending user title"}})
        self.google.records["event"].raw.update(ncs_peer_id="different-page", ncs_mapping="other")
        self.engine.sync()
        self.assertEqual("Example", self.google.records["event"].values["title"])
        self.assertEqual([], self.google.writes)

    def test_positive_google_cancellation_tombstone_survives_get_410(self):
        self.linked_pair()
        self.google.records["event"].deleted = True
        self.google.records["event"].raw["status"] = "cancelled"
        self.google.records["event"].values = {}
        self.google.errors["event"] = AccessError("Gone after cancellation", 410)
        self.engine.sync()
        self.assertTrue(self.notion.records["page"].deleted)
        self.assertEqual("deleted", self.store.db.execute("SELECT status FROM links").fetchone()[0])
        self.assertEqual([("archive", "page")], self.notion.writes)

    def test_google_410_after_successful_cancel_recovers_durable_delete(self):
        self.linked_pair()
        self.notion.records["page"].deleted = True
        self.google.crash_after = "archive"
        with self.assertRaises(SystemExit):
            self.engine.sync()
        self.google.errors["event"] = AccessError("Gone after our successful delete", 410)
        self.engine = Engine(self.config, self.store, self.notion, self.google)
        self.engine.sync()
        self.assertEqual("deleted", self.store.db.execute("SELECT status FROM links").fetchone()[0])
        self.assertEqual(1, len([write for write in self.google.writes if write[0] == "archive"]))

    def test_stable_marker_cannot_adopt_google_event_owned_by_other_mapping(self):
        changed = deepcopy(VALUES)
        changed["title"] = "Different mapped content"
        self.notion.record("page", changed, raw={"ncs_peer_id": "event"})
        self.google.record("event", raw={"ncs_peer_id": "different-page", "ncs_mapping": "other"})
        self.engine.sync(full=True)
        self.assertEqual([], self.google.writes)
        self.assertEqual([], self.notion.writes)
        self.assertEqual(0, self.store.db.execute("SELECT COUNT(*) FROM links").fetchone()[0])

    def test_changed_marker_on_existing_link_blocks_writes_to_wrong_identity(self):
        self.linked_pair()
        self.notion.records["page"].raw["ncs_peer_id"] = "another-event"
        self.notion.records["page"].values["title"] = "Do not apply to old peer"
        self.engine.sync(full=True)
        self.assertEqual("Example", self.google.records["event"].values["title"])
        self.assertEqual([], self.google.writes)
        self.assertEqual("another-event", self.notion.records["page"].raw["ncs_peer_id"])

    def test_two_pages_claiming_same_event_never_clone_or_silently_merge(self):
        self.notion.record("page-a", raw={"ncs_peer_id": "event"})
        self.notion.record("page-b", raw={"ncs_peer_id": "event"})
        self.google.record("event")
        report = self.engine.sync(full=True)
        self.assertEqual(1, len(self.google.records))
        self.assertEqual(2, len(self.notion.records))
        self.assertEqual(1, self.store.db.execute("SELECT COUNT(*) FROM links").fetchone()[0])
        self.assertTrue(any(item["action"] in {"identity_conflict", "link_required"} for item in report))


if __name__ == "__main__":
    unittest.main()
