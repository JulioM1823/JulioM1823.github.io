"""Native Windows checks plus installer rollback contract checks on every host."""
import importlib.util
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]


class WindowsInstallerContractTests(unittest.TestCase):
    def test_upgrade_stages_before_renaming_previous_installation(self):
        text=(ROOT/'packaging/windows-install.vbs').read_text()
        self.assertIn('fso.CopyFolder source & "\\runtime", stage & "\\runtime", True',text)
        self.assertIn('fso.CopyFolder source & "\\Licenses", stage & "\\Licenses", True',text)
        self.assertLess(text.index('fso.CopyFolder source & "\\runtime"'),text.index('fso.MoveFolder target, backup'))
        self.assertLess(text.index('fso.MoveFolder target, backup'),text.index('fso.MoveFolder stage, target'))
        self.assertIn('fso.MoveFolder backup, target',text)
        self.assertNotIn('fso.DeleteFolder target',text)
        self.assertNotIn('fso.DeleteFolder backup',text)

    def test_native_installer_test_path_does_not_change_shortcuts_or_launch(self):
        text=(ROOT/'packaging/windows-install.vbs').read_text()
        test_exit=text.index('If testing Then\n    WScript.Echo "installed"')
        self.assertLess(test_exit,text.index('shell.CreateShortcut'))
        self.assertIn('--test-root',text)
        self.assertIn('--simulate-promotion-failure',text)


@unittest.skipUnless(sys.platform=='win32','Requires native Windows APIs; no emulation claim')
class WindowsNativeAcceptanceTests(unittest.TestCase):
    def test_actual_native_credential_manager_and_process_locks(self):
        spec=importlib.util.spec_from_file_location('windows_platform_check',ROOT/'scripts/windows_platform_check.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        result=module.run_checks()
        self.assertTrue(result['passed'])
        self.assertTrue(result['native_windows'])
        self.assertIn('native credential deleted',result['checks'])
        self.assertIn('native second writer rejected',result['checks'])
