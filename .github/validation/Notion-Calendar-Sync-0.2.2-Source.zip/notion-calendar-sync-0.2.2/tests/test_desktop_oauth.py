"""Desktop authorization uses native-vault hooks, never plaintext token paths."""
import base64
from contextlib import redirect_stdout
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
import threading
import time
import types
import unittest
from unittest.mock import patch
import urllib.error
import urllib.parse
import urllib.request

from notion_calendar_sync.desktop_platform import SecretJSONStore
from notion_calendar_sync.http import ProviderError, ReauthRequired
from notion_calendar_sync.oauth import authorize, SCOPES, TokenManager, secure_write
from notion_calendar_sync.service import StateLock
import notion_calendar_sync.oauth as oauth
import notion_calendar_sync.service as service


class MemoryVault:
    def __init__(self): self.values = {}
    def get(self, key): return self.values.get(key)
    def set(self, key, value): self.values[key] = value
    def delete(self, key): self.values.pop(key, None)


class Transport:
    def __init__(self, response): self.response = response; self.calls = []
    def request(self, *args, **kwargs):
        self.calls.append((args, kwargs))
        if isinstance(self.response, Exception): raise self.response
        return dict(self.response)


class DesktopOAuthTests(unittest.TestCase):
    def test_loopback_pkce_state_and_secure_vault_hooks_without_files(self):
        with tempfile.TemporaryDirectory() as directory:
            client = Path(directory)/'must-not-read-client.json'
            token = Path(directory)/'must-not-write-token.json'
            vault = SecretJSONStore(MemoryVault())
            transport = Transport({'access_token': 'access', 'refresh_token': 'offline',
                                   'expires_in': 3600, 'id_token': 'must-not-persist'})
            seen = []; requests = []; threads = []
            def url_ready(url):
                values = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
                seen.append(values)
                redirect = values['redirect_uri'][0]
                def callback():
                    bad = redirect+'?'+urllib.parse.urlencode({'state': 'wrong-state', 'code': 'untrusted'})
                    try:
                        urllib.request.urlopen(bad, timeout=5)
                    except urllib.error.HTTPError as error:
                        requests.append(error.code); error.close()
                    good = redirect+'?'+urllib.parse.urlencode({'state': values['state'][0], 'code': 'validated-code'})
                    with urllib.request.urlopen(good, timeout=5) as response:
                        requests.append(response.status); response.read()
                thread = threading.Thread(target=callback); threads.append(thread); thread.start()
            with patch.object(oauth, 'load_client', side_effect=AssertionError('plaintext client fallback')), \
                 patch.object(oauth, 'secure_write', side_effect=AssertionError('plaintext token fallback')), \
                 redirect_stdout(io.StringIO()):
                result = authorize(client, token, open_browser=False, timeout=10, transport=transport,
                    client_loader=lambda: {'client_id': 'desktop-id', 'client_secret': 'desktop-secret'},
                    token_saver=vault.save, url_callback=url_ready)
            for thread in threads: thread.join(timeout=5)
            self.assertEqual(requests, [400, 200])
            self.assertTrue(result['authorized'])
            self.assertEqual(vault.load()['refresh_token'], 'offline')
            self.assertNotIn('id_token', vault.load())
            self.assertGreater(vault.load()['expires_at'], time.time())
            self.assertEqual(list(Path(directory).iterdir()), [])
            values = seen[0]
            self.assertEqual(set(values['scope'][0].split()), set(SCOPES))
            self.assertEqual(values['access_type'], ['offline'])
            self.assertEqual(values['code_challenge_method'], ['S256'])
            form = transport.calls[0][1]['form']
            self.assertEqual(form['code'], 'validated-code')
            self.assertEqual(form['redirect_uri'], values['redirect_uri'][0])
            challenge = base64.urlsafe_b64encode(hashlib.sha256(form['code_verifier'].encode()).digest()).rstrip(b'=').decode()
            self.assertEqual(values['code_challenge'], [challenge])

    def test_cancel_does_not_replace_existing_offline_grant(self):
        vault = SecretJSONStore(MemoryVault()); vault.save({'refresh_token': 'retained'})
        cancel = threading.Event(); cancel.set(); urls = []
        transport = Transport({'access_token': 'unexpected'})
        with patch.object(oauth, 'secure_write', side_effect=AssertionError('plaintext fallback')):
            with self.assertRaises(ReauthRequired):
                authorize(None, None, open_browser=False, timeout=2, transport=transport,
                    client_loader=lambda: {'client_id': 'desktop-id'}, token_saver=vault.save,
                    url_callback=urls.append, cancel=cancel)
        self.assertEqual(vault.load(), {'refresh_token': 'retained'})
        self.assertFalse(transport.calls)
        self.assertEqual(len(urls), 1)

    def test_secure_refresh_preserves_offline_grant_then_uses_cache(self):
        with tempfile.TemporaryDirectory() as directory:
            vault = SecretJSONStore(MemoryVault())
            vault.save({'refresh_token': 'offline', 'access_token': 'expired', 'expires_at': 0})
            transport = Transport({'access_token': 'refreshed', 'expires_in': 3600})
            manager = TokenManager(Path(directory)/'no-client', Path(directory)/'no-token', transport,
                client_loader=lambda: {'client_id': 'desktop-id', 'client_secret': 'secret'},
                token_loader=vault.load, token_saver=vault.save)
            with patch.object(oauth, 'secure_write', side_effect=AssertionError('plaintext fallback')):
                self.assertEqual(manager.access_token(), 'refreshed')
                self.assertEqual(manager.access_token(), 'refreshed')
            self.assertEqual(len(transport.calls), 1)
            self.assertEqual(vault.load()['refresh_token'], 'offline')
            self.assertEqual(list(Path(directory).iterdir()), [])
            self.assertTrue(transport.calls[0][1]['safe'])

    def test_revoked_native_grant_is_reported_without_replacing_vault(self):
        vault = SecretJSONStore(MemoryVault()); vault.save({'refresh_token': 'offline', 'expires_at': 0})
        transport = Transport(ProviderError('sanitized provider error', 400, 'invalid_grant'))
        manager = TokenManager('unused-client', 'unused-token', transport,
            client_loader=lambda: {'client_id': 'desktop-id'}, token_loader=vault.load, token_saver=vault.save)
        with self.assertRaises(ReauthRequired): manager.access_token()
        self.assertEqual(vault.load(), {'refresh_token': 'offline', 'expires_at': 0})

    def test_windows_file_writer_skips_posix_only_descriptor_and_directory_apis(self):
        # This is the legacy CLI path; desktop hooks above must not reach it.
        proxy = types.SimpleNamespace(name='nt', fdopen=os.fdopen, fsync=os.fsync,
            replace=os.replace, unlink=os.unlink, path=os.path,
            open=lambda *_: (_ for _ in ()).throw(AssertionError('directory opened on Windows')))
        with tempfile.TemporaryDirectory() as directory, patch.object(oauth, 'os', proxy):
            path = Path(directory)/'token.json'
            secure_write(path, {'access_token': 'test-only'})
            self.assertEqual(json.loads(path.read_text()), {'access_token': 'test-only'})

    def test_windows_state_lock_rejects_second_writer_and_releases_first_byte(self):
        active = []; calls = []
        def locking(fd, action, count):
            calls.append((fd, action, count, os.lseek(fd, 0, os.SEEK_CUR)))
            if action == 2:
                if active: raise OSError('already locked')
                active.append(fd)
            else:
                active.clear()
        proxy = types.SimpleNamespace(name='nt', open=os.open, fdopen=os.fdopen, O_RDWR=os.O_RDWR, O_CREAT=os.O_CREAT)
        windows = types.SimpleNamespace(LK_NBLCK=2, LK_UNLCK=0, locking=locking)
        with tempfile.TemporaryDirectory() as directory, patch.object(service, 'os', proxy), \
             patch.object(service, 'msvcrt', windows, create=True):
            path = Path(directory)/'sync.sqlite3'
            first, second = StateLock(path), StateLock(path)
            with first:
                with self.assertRaisesRegex(RuntimeError, 'Another ncs writer'): second.__enter__()
                self.assertIsNone(second.handle)
            with StateLock(path): pass
            self.assertIsNone(first.handle)
            self.assertEqual(Path(str(path)+'.lock').read_bytes(), b'0')
            self.assertEqual([call[1] for call in calls], [2, 2, 0, 2, 0])
            self.assertTrue(all(call[2:] == (1, 0) for call in calls))
