"""Desktop acceptance without real accounts or OS credential writes."""
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch, MagicMock

from notion_calendar_sync.desktop_backend import DesktopController, PreviewProvider, notion_id, suggest_mapping
from notion_calendar_sync.desktop import supervise
from notion_calendar_sync.http import ProviderError
from notion_calendar_sync.oauth import TokenManager, authorize
from test_engine_review import MemoryProvider

SOURCE = '11111111-2222-3333-4444-555555555555'


class MemorySecrets:
    def __init__(self):
        self.values = {'notion_token': 'PRIVATE-NOTION', 'google_token': '{"refresh_token":"PRIVATE-REFRESH"}'}
    def get(self, key): return self.values.get(key)
    def set(self, key, value): self.values[key] = value
    def delete(self, key): self.values.pop(key, None)


class DesktopBackendTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.n, self.g = MemoryProvider('notion'), MemoryProvider('google')
        self.secrets = MemorySecrets()
        self.c = DesktopController(self.tmp.name, self.secrets, provider_factory=lambda c:(self.n, self.g), autorun=False)
        self.addCleanup(self.c.close)
        self.settings = {'notion_data_source': SOURCE, 'google_calendar': 'calendar', 'timezone': 'America/Denver',
                         'properties': {'title':'Name','date':'Date','google_event_id':'Identity','description':'Notes','location':'Location'}}
    def page(self):
        self.n.record('page', raw={'parent':{'data_source_id':SOURCE}})

    def test_id_and_database_url_ignore_view_id(self):
        self.assertEqual(notion_id('https://www.notion.so/My-db-'+SOURCE.replace('-','')+'?v='+'f'*32), SOURCE)
        with self.assertRaises(ValueError): notion_id('not-a-database')

    def test_type_safe_suggestions_do_not_reuse_ambiguous_text(self):
        schema={'properties':{'Event':{'type':'title'},'When':{'type':'date'},'Note':{'type':'rich_text'},'Location':{'type':'url'},'NCS Event ID':{'type':'rich_text'}}}
        props=suggest_mapping(schema)
        self.assertEqual(props['title'],'Event');self.assertEqual(props['date'],'When')
        self.assertEqual(props['description'],'Note');self.assertEqual(props['location'],'')
        self.assertEqual(props['google_event_id'],'NCS Event ID')

    def test_preview_is_read_only_and_does_not_start(self):
        self.page();p=self.c.preview(self.settings)
        self.assertEqual(p['summary']['create'],1)
        self.assertEqual(p['report'][0]['action'],'create')
        self.assertEqual(self.n.writes+self.g.writes,[])
        self.assertFalse(self.c.state()['running'])
        self.assertFalse(self.c.state()['approved'])
        with self.assertRaises(ValueError):self.c.resume()

    def test_preview_blocks_adapter_writes_even_if_engine_regresses(self):
        wrapper=PreviewProvider(self.n)
        for method in ('create','update','archive','set_links'):
            with self.assertRaises(RuntimeError):getattr(wrapper,method)(None)

    def test_explicit_approval_backs_up_and_links_one_pair(self):
        self.page();p=self.c.preview(self.settings)
        self.c.approve(p['preview_id'])
        deadline=time.time()+5
        while not self.g.records and time.time()<deadline:time.sleep(.02)
        self.c.pause()
        self.assertEqual(len(self.g.records),1)
        self.assertEqual(len(list(Path(self.tmp.name).glob('before-first-sync-*.sqlite3'))),1)
        self.assertEqual(self.c.state()['status']['links'],[{'status':'active','count':1}])
        self.c.resume();time.sleep(.05);self.c.pause()
        self.assertEqual(len(self.g.records),1)

    def test_changed_remote_after_preview_requires_new_review(self):
        self.page();p=self.c.preview(self.settings);self.n.records['page'].values['title']='a newer edit'
        with self.assertRaisesRegex(ValueError,'changed'):self.c.approve(p['preview_id'])
        self.assertFalse(self.g.records)

    def test_expired_or_wrong_preview_never_runs(self):
        self.page();p=self.c.preview(self.settings)
        with self.assertRaises(ValueError):self.c.approve('wrong')
        self.c._preview['created']-=601
        with self.assertRaisesRegex(ValueError,'expired'):self.c.approve(p['preview_id'])
        self.assertFalse(self.g.records)

    def test_mutating_original_settings_does_not_mutate_preview(self):
        p=self.c.preview(self.settings);self.settings['google_calendar']='other'
        self.assertEqual(self.c._preview['settings']['google_calendar'],'calendar')

    def test_changing_endpoints_retains_separate_state(self):
        a=self.c._config(self.settings).state_path
        b=self.c._config(dict(self.settings,google_calendar='second')).state_path
        self.assertNotEqual(a,b)

    def test_schema_mutation_requires_confirmation_and_preserves_existing(self):
        with self.assertRaises(ValueError):self.c.create_properties(SOURCE)
        schema={'properties':{'Name':{'type':'title'},'NCS Event ID':{'type':'rich_text'}}}
        provider=MagicMock();provider._request.return_value=schema
        with patch.object(self.c,'schema',return_value=schema),patch.object(self.c,'_discovery',return_value=(provider,None)):
            self.c.create_properties(SOURCE,True)
        sent=provider._request.call_args.kwargs['body']['properties']
        self.assertNotIn('Name',sent);self.assertNotIn('NCS Event ID',sent)
        self.assertEqual(set(sent),{'NCS Time Zone','Recurrence','Calendar Link'})
        self.assertEqual(sent['Calendar Link'],{'url': {}})

    def test_diagnostics_are_allowlisted_and_contain_no_credentials_or_titles(self):
        self.c._logs=['PRIVATE-REFRESH a private event title']
        self.c.diagnostics(Path(self.tmp.name)/'diagnostics.json')
        raw=(Path(self.tmp.name)/'diagnostics.json').read_text()
        for value in ('PRIVATE','private event','google_token','notion_token'):self.assertNotIn(value,raw)

    def test_config_requires_distinct_compatible_mapping_inputs(self):
        for override in ({'properties':{'title':'Name','date':'Name','google_event_id':'Identity'}},
                         {'google_calendar':'primary'},{'timezone':'invalid-zone'},{'poll_seconds':1},
                         {'notion_select_property':'Type'}):
            with self.subTest(override=override),self.assertRaises(ValueError):self.c._config(dict(self.settings,**override))

    def test_worker_failure_is_visible_and_keeps_data(self):
        self.page();p=self.c.preview(self.settings)
        with patch('notion_calendar_sync.desktop_backend.SyncService.run',side_effect=RuntimeError('PRIVATE')):
            self.c.approve(p['preview_id']);self.c._thread.join(2)
        self.assertIn('stopped',self.c.state()['error'])
        self.assertNotIn('PRIVATE',self.c.state()['error'])
        self.assertTrue(self.c._config(self.settings).state_path.exists())

    def test_process_supervisor_restarts_crash_but_stops_on_quit(self):
        run=MagicMock(side_effect=[MagicMock(returncode=1),MagicMock(returncode=1),MagicMock(returncode=0)])
        waits=[];self.assertEqual(supervise([],run=run,sleep=waits.append),0)
        self.assertEqual(run.call_count,3);self.assertEqual(waits,[2,4])

    def test_oauth_refresh_stays_in_injected_secure_store(self):
        token={'access_token':'old','refresh_token':'PRIVATE-REFRESH','expires_at':0};saved=[]
        transport=MagicMock();transport.request.return_value={'access_token':'new','expires_in':3600}
        manager=TokenManager(Path(self.tmp.name)/'unused-client',Path(self.tmp.name)/'unused-token',transport,
                             client_loader=lambda:{'client_id':'id'},token_loader=lambda:token,token_saver=saved.append)
        self.assertEqual(manager.access_token(),'new')
        self.assertEqual(saved[0]['refresh_token'],'PRIVATE-REFRESH')
        self.assertFalse((Path(self.tmp.name)/'unused-token').exists())

    def test_closed_application_cannot_approve_or_restart(self):
        self.page();preview=self.c.preview(self.settings);self.c.close()
        with self.assertRaises(RuntimeError):self.c.approve(preview['preview_id'])
        self.assertFalse(self.g.records)

    def test_conflict_resolution_does_not_report_success_when_remote_write_pending(self):
        self.page();p=self.c.preview(self.settings);self.c.approve(p['preview_id'])
        deadline=time.time()+5
        while not self.g.records and time.time()<deadline:time.sleep(.02)
        self.c.pause()
        from notion_calendar_sync.store import Store
        from notion_calendar_sync.engine import Engine
        config=self.c._config(self.settings)
        self.n.records['page'].values['title']='Notion edit'
        next(iter(self.g.records.values())).values['title']='Google edit'
        with Store(config.state_path) as store:
            Engine(config,store,self.n,self.g).sync(full=True)
        id=self.c.conflicts()[0]['id']
        with patch('notion_calendar_sync.desktop_backend.Engine.resolve',return_value=[{'action':'retry'}]):
            result=self.c.resolve(id,'notion')
        self.assertFalse(result['resolved']);self.assertTrue(result['pending'])

    def test_nonfinite_poll_intervals_are_rejected(self):
        for key in ('poll_seconds','reconcile_seconds'):
            for value in (float('nan'),float('inf')):
                with self.assertRaises(ValueError):self.c._config(dict(self.settings,**{key:value}))

    def test_portable_runtime_isolation_survives_restart_and_login(self):
        from types import SimpleNamespace
        from notion_calendar_sync.desktop import child_command
        from notion_calendar_sync.desktop_platform import startup_command
        with patch('sys.flags',SimpleNamespace(isolated=1)):
            self.assertIn('-I',child_command([]))
            self.assertIn('-I',startup_command())
