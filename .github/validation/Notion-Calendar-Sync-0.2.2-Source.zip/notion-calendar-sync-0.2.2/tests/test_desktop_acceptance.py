"""Cross-platform desktop setup and sync acceptance with simulated APIs."""
import importlib.util
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('desktop_acceptance',Path(__file__).resolve().parents[1]/'scripts/desktop_acceptance.py')
acceptance=importlib.util.module_from_spec(spec);spec.loader.exec_module(acceptance)

class DesktopAcceptanceTests(unittest.TestCase):
    def test_full_setup_sync_and_restart_without_duplicate_or_data_loss(self):
        report=acceptance.run_acceptance()
        self.assertTrue(report['passed'])
        self.assertGreaterEqual(report['check_count'],30)
        self.assertEqual(report['duplicate_identities'],0)
        self.assertFalse(report['real_provider_accounts_accessed'])
        self.assertTrue(report['data_preservation_verified'])
