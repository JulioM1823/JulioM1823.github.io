import unittest
from datetime import datetime,timezone
from copy import deepcopy
from pathlib import Path
from notion_calendar_sync.config import Mapping,load_config,ConfigError
import tempfile
from notion_calendar_sync.engine import Engine
from notion_calendar_sync.model import Record,normalize_time
from notion_calendar_sync.providers import NotionProvider,GoogleProvider
from test_providers import page, config, FakeTransport

class ScopeBootstrapTests(unittest.TestCase):
    def setUp(self):
        self.m=Mapping('research','source-1','cal',properties={'title':'Task','date':'Date','google_event_id':'NCS Event ID'})
        self.m.notion_select_property='Type'; self.m.notion_select_value='Research'
        self.p=NotionProvider(config())
    def test_category_change_pauses_even_when_page_trashed(self):
        raw=page(in_trash=True);raw['properties']['Type']={'select':{'name':'Personal'}}
        r=self.p._record(self.m,raw)
        self.assertTrue(r.deleted);self.assertFalse(r.eligible);self.assertTrue(r.raw['ncs_out_of_scope'])
    def test_selected_category_remains_eligible(self):
        raw=page();raw['properties']['Type']={'select':{'name':'Research'}}
        self.assertTrue(self.p._record(self.m,raw).eligible)
    def test_query_scope_combines_with_incremental_filter(self):
        transport=FakeTransport({'results':[],'has_more':False})
        p=NotionProvider(config(),transport)
        p._request=lambda method,path,**kw: transport.request(method,path,**kw)
        timestamp={'timestamp':'last_edited_time','last_edited_time':{'on_or_after':'2026-10-30T00:00:00Z'}}
        p._query(self.m,filter=timestamp)
        f=transport.calls[0][1]['body']['filter']['and']
        self.assertEqual(f[0],{'property':'Type','select':{'equals':'Research'}})
        self.assertEqual(f[1],timestamp)
    def test_google_creation_assigns_category_only_to_new_notion_page(self):
        posted=[]
        def request(method,path,**kwargs):
            if path.endswith('/query'):return {'results':[],'has_more':False}
            posted.append(kwargs['body']);return page()
        self.p._request=request
        self.p.create(self.m,{'title':'Test'},'operation','google-event')
        self.assertEqual(posted[0]['properties']['Type'],{'select':{'name':'Research'}})
        self.assertNotIn('Type',self.p._properties(self.m,{'title':'Updated'}))
    def test_initial_cutoff_skips_older_or_unversioned_unlinked_items(self):
        self.m.import_since='2026-10-30T10:00:00Z'
        for side,key in [('notion','created_time'),('google','created')]:
            self.assertFalse(Engine._allow_initial_import(self.m,Record('id',{},raw={key:'2026-10-29T10:00:00Z'}),side))
            self.assertTrue(Engine._allow_initial_import(self.m,Record('id',{},raw={key:'2026-10-30T10:01:00Z'}),side))
            self.assertFalse(Engine._allow_initial_import(self.m,Record('id',{},raw={}),side))

class GoogleDatePatchTests(unittest.TestCase):
    def test_timed_to_all_day_explicitly_clears_timed_fields(self):
        p=GoogleProvider(config())
        body=p._body(Mapping('x','s','c'),{'time':normalize_time('2035-01-20','2035-01-23')})
        for field in ('start','end'):
            self.assertIsNone(body[field]['dateTime']);self.assertIsNone(body[field]['timeZone'])
            self.assertTrue(body[field]['date'])
    def test_all_day_to_timed_explicitly_clears_date(self):
        p=GoogleProvider(config())
        body=p._body(Mapping('x','s','c'),{'time':normalize_time('2035-01-20T10:00:00Z','2035-01-20T11:00:00Z')})
        for field in ('start','end'):
            self.assertIsNone(body[field]['date']);self.assertTrue(body[field]['dateTime'])

class MultipleScopeConfigTests(unittest.TestCase):
    def load_pair(self, second_value='Writing', second_property='Type'):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'config.toml'
            parts=[]
            for name,value,prop in [('research','Research','Type'),('writing',second_value,second_property)]:
                parts.append('[[mappings]]\nname="'+name+'"\nnotion_data_source="same-source"\ngoogle_calendar="'+name+'"\nnotion_select_property="'+prop+'"\nnotion_select_value="'+value+'"\n[mappings.properties]\ntitle="Name"\ndate="Date"\ngoogle_event_id="ID"\n')
            p.write_text('\n'.join(parts));return load_config(p)
    def test_disjoint_categories_allow_same_data_source(self):
        self.assertEqual(len(self.load_pair().mappings),2)
    def test_overlapping_categories_are_rejected(self):
        with self.assertRaises(ConfigError):self.load_pair('Research')
    def test_different_category_properties_do_not_prove_disjoint_scope(self):
        with self.assertRaises(ConfigError):self.load_pair('Writing','Other property')
