"""Deployment gates for recovery defects found during setup."""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from notion_calendar_sync.config import Config, Mapping
from notion_calendar_sync.engine import Engine
from notion_calendar_sync.http import AccessError, RetryableError
from notion_calendar_sync.store import Store
from test_engine import FakeProvider


class SetupRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.directory.name) / 'state.db')
        self.mapping = Mapping('test', 'data', 'calendar', properties={
            'title': 'Task', 'date': 'Date', 'google_event_id': 'ID',
            'description': 'Note', 'location': 'Location', 'recurrence': 'Rule'})
        self.config = Config(state_path=self.store.path, mappings=[self.mapping])
        self.n, self.g = FakeProvider('notion'), FakeProvider('google')
        self.engine = Engine(self.config, self.store, self.n, self.g)

    def tearDown(self):
        self.store.close()
        self.directory.cleanup()

    def test_google_lost_create_response_then_source_edit_reuses_operation(self):
        self.n.add('n1')
        original = self.g.create
        def lost(*args, **kwargs):
            result = original(*args, **kwargs)
            self.g.create = original
            raise RetryableError('Lost final response after deterministic insert')
        self.g.create = lost
        self.engine.sync()
        self.assertEqual(len(self.g.items), 1)
        self.n.edit('n1', title='Latest edit')
        self.store.db.execute('UPDATE operations SET next_attempt=0')
        self.store.db.commit()
        self.engine.sync()
        self.engine.sync()
        self.assertEqual(len(self.g.items), 1)
        self.assertEqual(next(iter(self.g.items.values())).values['title'], 'Latest edit')

    def test_crash_after_observation_commit_retries_unchanged_poll(self):
        self.n.add('n1')
        self.engine.sync()
        gid = next(iter(self.g.items))
        self.n.edit('n1', title='Must survive cursor checkpoint')
        with patch.object(self.engine, '_adopt', side_effect=SystemExit('power failure before processing')):
            with self.assertRaises(SystemExit):
                self.engine.sync()
        self.engine = Engine(self.config, self.store, self.n, self.g)
        self.engine.sync()
        self.assertEqual(self.g.items[gid].values['title'], 'Must survive cursor checkpoint')

    def test_old_unlinked_item_does_not_require_repeated_remote_get(self):
        self.mapping.import_since='2026-10-30T00:00:00Z'
        self.n.add('old',raw={'created_time':'2020-01-01T00:00:00Z'})
        with patch.object(self.n,'get',side_effect=AssertionError('Unnecessary old-item fetch')):
            r=self.engine.sync()
        self.assertEqual(len(self.g.items),0)
        self.assertTrue(any(x['action']=='link_required' for x in r))

    def test_user_edit_returned_during_link_write_is_not_hidden_by_observation(self):
        original=self.g.set_links
        def edited_during_links(mapping,id,*args,**kwargs):
            self.g.edit(id,title='User edited during link write')
            self.g.set_links=original
            return original(mapping,id,*args,**kwargs)
        self.g.set_links=edited_during_links
        self.n.add('n1');self.engine.sync()
        self.assertEqual(self.n.items['n1'].values['title'],'User edited during link write')
        # Simulate restart: the next scan equals the response we already saved,
        # but those observed values differ from the last successful common base.
        self.engine=Engine(self.config,self.store,self.n,self.g)
        self.engine.sync()
        self.assertEqual(self.n.items['n1'].values['title'],'User edited during link write')
        self.assertEqual(len(self.g.items),1)

    def test_crash_after_link_response_recovers_already_observed_user_edit(self):
        self.n.add('n1');original=self.g.set_links
        def edited_then_crash(mapping,id,*args,**kwargs):
            self.g.edit(id,title='Must survive cached observation')
            return original(mapping,id,*args,**kwargs)
        self.g.set_links=edited_then_crash
        original_metadata=self.engine._links_metadata
        def metadata_then_crash(*args):
            original_metadata(*args)
            raise SystemExit('power loss after write response was persisted')
        with patch.object(self.engine,'_links_metadata',metadata_then_crash):
            with self.assertRaises(SystemExit):self.engine.sync()
        self.g.set_links=original
        path=self.store.path;self.store.close();self.store=Store(path)
        self.engine=Engine(self.config,self.store,self.n,self.g)
        self.engine.sync()
        self.assertEqual(self.n.items['n1'].values['title'],'Must survive cached observation')
        self.assertEqual(len(self.g.items),1)

    def test_unchanged_conflict_does_not_block_each_poll_with_extra_reads(self):
        self.n.add('n1');self.engine.sync();gid=next(iter(self.g.items))
        self.n.edit('n1',title='N conflict');self.g.edit(gid,title='G conflict')
        self.engine.sync()
        self.assertEqual(self.store.db.execute("SELECT count(*) FROM conflicts WHERE status='open'").fetchone()[0],1)
        with patch.object(self.n,'get',side_effect=AssertionError('Unnecessary unchanged-conflict fetch')),patch.object(self.g,'get',side_effect=AssertionError('Unnecessary unchanged-conflict fetch')):
            self.engine.sync()
            self.engine.sync(full=True)
        self.n.edit('n1',title='New user change')
        self.engine.sync(full=True)
        row=self.store.db.execute("SELECT notion FROM conflicts WHERE status='open'").fetchone()[0]
        self.assertIn('New user change',row)

    def test_unchanged_paused_link_skips_reads_and_resumes_after_change(self):
        self.n.add('n1');self.engine.sync();gid=next(iter(self.g.items))
        self.n.items['n1'].eligible=False
        self.engine.sync()
        self.assertEqual(self.store.db.execute('select status from links').fetchone()[0],'paused')
        self.engine=Engine(self.config,self.store,self.n,self.g)
        with patch.object(self.n,'get',side_effect=AssertionError('Unnecessary paused-item fetch')):
            self.engine.sync()
        self.n.items['n1'].eligible=True
        self.n.edit('n1',title='Resumed after restoring eligibility')
        self.engine.sync()
        self.assertEqual(self.g.items[gid].values['title'],'Resumed after restoring eligibility')
        self.assertEqual(self.store.db.execute('select status from links').fetchone()[0],'active')

    def test_legacy_unavailable_identity_is_retained_and_rechecks_without_deletion(self):
        self.n.add('n1')
        with self.store.db:
            self.store.db.execute("INSERT INTO links(mapping,notion_id,google_id,status) VALUES('test','n1','lost','historical-unavailable')")
        with patch.object(self.n,'get',side_effect=AssertionError('Read unavailable Calendar peer first')):
            report=self.engine.sync(full=True)
        self.assertTrue(any(r['action']=='historical_unavailable' for r in report))
        self.assertFalse(any(r.get('error') for r in report))
        self.assertEqual(self.store.db.execute('select status from links').fetchone()[0],'historical-unavailable')
        self.assertEqual(len(self.g.items),0)
        self.assertFalse(self.n.items['n1'].deleted)
        with patch.object(self.g,'get',side_effect=AssertionError('Unnecessary held-history read')):
            self.engine.sync()

    def test_restored_legacy_peer_resumes_same_pair_without_recreation(self):
        self.n.add('n1')
        with self.store.db:
            self.store.db.execute("INSERT INTO links(mapping,notion_id,google_id,status) VALUES('test','n1','restored','historical-unavailable')")
        self.engine.sync(full=True)
        self.g.add('restored')
        self.engine.sync()
        self.assertEqual(self.store.db.execute('select status from links').fetchone()[0],'active')
        self.assertEqual(len(self.g.items),1)
        self.assertEqual(len(self.n.items),1)

    def test_out_of_scope_pause_ignores_expected_missing_membership_then_resumes(self):
        self.n.add('n1');self.engine.sync();gid=next(iter(self.g.items))
        self.n.items['n1'].eligible=False;self.n.items['n1'].raw['ncs_out_of_scope']=True
        self.engine.sync();self.n.omit.add('n1')
        original=self.n.scan
        def full_membership(*args,**kw):
            result=original(*args,**kw);result.full_membership=True;return result
        with patch.object(self.n,'scan',side_effect=full_membership),patch.object(self.n,'get',side_effect=AssertionError('Expected scope absence')):
            self.engine.sync()
        self.n.omit.clear();self.n.items['n1'].eligible=True;self.n.items['n1'].raw['ncs_out_of_scope']=False
        self.n.edit('n1',title='Returned to Research')
        self.engine.sync()
        self.assertEqual(self.g.items[gid].values['title'],'Returned to Research')
