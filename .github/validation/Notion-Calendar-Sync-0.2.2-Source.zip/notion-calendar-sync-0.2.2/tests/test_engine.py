"""Stateful provider fakes model remote writes independently of local SQLite."""
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
import tempfile
import unittest

from notion_calendar_sync.config import Config, Mapping
from notion_calendar_sync.engine import Engine
from notion_calendar_sync.http import AccessError, AmbiguousWrite, PreconditionFailed, RetryableError
from notion_calendar_sync.model import Record, normalize_time
from notion_calendar_sync.providers import Scan
from notion_calendar_sync.store import Store


def values(**patch):
    result = {'title': 'Appointment', 'time': normalize_time('2026-10-30T12:00:00-06:00',
               '2026-10-30T13:00:00-06:00', 'America/Denver'),
              'description': '', 'location': '', 'recurrence': []}
    result.update(patch)
    return result


class FakeProvider:
    def __init__(self, side):
        self.side, self.items, self.operations, self.writes = side, {}, {}, []
        self.fail = None
        self.crash = False
        self.hidden = set()
        self.omit = set()
        self.scan_fail = False
        self.version = 1

    def validate(self, m):
        return {}

    def scan(self, m, cursor=None, full=False):
        if self.scan_fail:
            raise RetryableError('offline')
        return Scan([deepcopy(r) for k, r in self.items.items() if k not in self.omit], str(self.version))

    def get(self, m, id):
        if id in self.hidden or id not in self.items:
            raise AccessError('unavailable', 404)
        return deepcopy(self.items[id])

    def add(self, id, data=None, **kwargs):
        self.items[id] = Record(id, data or values(), version=str(self.version), url='https://example.test/' + id, **kwargs)
        self.version += 1
        return self.items[id]

    def edit(self, id, **patch):
        self.items[id].values.update(patch)
        self.items[id].version = str(self.version)
        self.version += 1

    def delete(self, id):
        self.items[id].deleted = True
        self.items[id].version = str(self.version)
        self.version += 1

    def create(self, m, data, operation_id, peer_id='', recovery_only=False):
        if operation_id in self.operations:
            return self.get(m, self.operations[operation_id])
        # Marker search also recovers imported existing Notion records.
        for item in self.items.values():
            if self.side == 'notion' and item.raw.get('ncs_peer_id') == peer_id:
                return deepcopy(item)
        if recovery_only and self.side == 'notion':
            raise AmbiguousWrite('marker not visible')
        if self.fail:
            raise self.fail
        id = self.side[0] + operation_id
        result = self.add(id, deepcopy(data), raw={'ncs_peer_id': peer_id, 'ncs_mapping': m.name})
        self.operations[operation_id] = id
        self.writes.append(('create', id, deepcopy(data)))
        if self.crash:
            self.crash = False
            raise SystemExit('simulated power cut after remote write')
        return deepcopy(result)

    def update(self, m, id, data, version=''):
        current = self.get(m, id)
        if version and current.version != version:
            raise PreconditionFailed('changed')
        if self.fail:
            raise self.fail
        self.edit(id, **deepcopy(data))
        self.writes.append(('update', id, deepcopy(data)))
        if self.crash:
            self.crash = False
            raise SystemExit('simulated power cut after remote write')
        return self.get(m, id)

    def archive(self, m, id, version=''):
        if self.fail:
            raise self.fail
        self.delete(id)
        self.writes.append(('archive', id))
        if self.crash:
            self.crash = False
            raise SystemExit('simulated power cut after remote write')
        return self.get(m, id)

    def set_links(self, m, id, peer_id, peer_url=''):
        before = deepcopy(self.items[id].raw)
        self.items[id].raw.update(ncs_peer_id=peer_id, ncs_mapping=m.name)
        if self.side == 'google' and peer_url:
            self.items[id].raw['source'] = {'url': peer_url, 'title': 'Notion (NCS)'}
        if self.side == 'notion' and m.properties.get('google_url') and peer_url:
            self.items[id].raw.setdefault('properties', {})[m.properties['google_url']] = {'url': peer_url}
        if before != self.items[id].raw:
            self.writes.append(('links', id, peer_id))
        return self.get(m, id)


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'sync.db'
        self.store = Store(self.path)
        self.mapping = Mapping('test', 'data', 'calendar', properties={
            'title': 'Task', 'date': 'Date', 'description': 'Note', 'location': 'Location',
            'google_event_id': 'ID', 'recurrence': 'Recurrence'})
        self.config = Config(state_path=self.path, mappings=[self.mapping])
        self.n, self.g = FakeProvider('notion'), FakeProvider('google')
        self.engine = Engine(self.config, self.store, self.n, self.g)

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def sync(self, **kwargs):
        return self.engine.sync(**kwargs)

    def pair(self):
        self.n.add('n1')
        result = self.sync()
        errors = [x for x in result if x['action'] in ('error', 'retry', 'ambiguous')]
        self.assertEqual(errors, [], result)
        row = self.store.db.execute('SELECT * FROM links').fetchone()
        return row['notion_id'], row['google_id']

    def force_retry(self):
        with self.store.db:
            self.store.db.execute('UPDATE operations SET next_attempt=0')

    def test_notion_create_and_no_feedback(self):
        n, g = self.pair()
        before = len(self.n.writes) + len(self.g.writes)
        for _ in range(4):
            self.sync(full=True)
        self.assertEqual(len(self.g.items), 1)
        self.assertEqual(before, len(self.n.writes) + len(self.g.writes))
        self.assertEqual(self.g.items[g].raw['ncs_peer_id'], n)

    def test_google_create_and_edit(self):
        self.g.add('g1')
        self.sync()
        n = next(iter(self.n.items))
        self.g.edit('g1', title='Google edit')
        self.sync()
        self.assertEqual(self.n.items[n].values['title'], 'Google edit')
        self.n.edit(n, description='Notion edit')
        self.sync()
        self.assertEqual(self.g.items['g1'].values['description'], 'Notion edit')

    def test_independent_concurrent_edits_merge(self):
        n, g = self.pair()
        self.n.edit(n, title='Notion title')
        self.g.edit(g, location='Google room')
        self.sync()
        self.assertEqual(self.n.items[n].values, self.g.items[g].values)
        self.assertEqual(self.n.items[n].values['title'], 'Notion title')
        self.assertEqual(self.g.items[g].values['location'], 'Google room')

    def test_conflict_and_resolution_preserve_snapshots(self):
        n, g = self.pair()
        self.n.edit(n, title='N')
        self.g.edit(g, title='G')
        self.sync()
        c = self.store.db.execute("SELECT * FROM conflicts WHERE status='open'").fetchone()
        self.assertIsNotNone(c)
        self.assertEqual(self.n.items[n].values['title'], 'N')
        self.assertEqual(self.g.items[g].values['title'], 'G')
        self.engine.resolve(c['id'], 'notion')
        self.assertEqual(self.g.items[g].values['title'], 'N')
        self.assertEqual(self.store.db.execute("SELECT COUNT(*) FROM conflicts WHERE status='open'").fetchone()[0], 0)

    def test_stale_resolution_rejected(self):
        n, g = self.pair()
        self.n.edit(n, title='N')
        self.g.edit(g, title='G')
        self.sync()
        c = self.store.db.execute("SELECT id FROM conflicts WHERE status='open'").fetchone()[0]
        self.g.edit(g, location='new edit')
        with self.assertRaisesRegex(ValueError, 'changed after'):
            self.engine.resolve(c, 'notion')
        self.assertEqual(self.g.items[g].values['location'], 'new edit')

    def test_schedule_related_conflicts(self):
        n, g = self.pair()
        self.n.edit(n, time=normalize_time('2026-10-31', None, 'America/Denver'))
        self.g.edit(g, recurrence=['RRULE:FREQ=WEEKLY'])
        self.sync()
        c = self.store.db.execute("SELECT fields FROM conflicts WHERE status='open'").fetchone()
        self.assertIn('time', c[0])
        self.assertIn('recurrence', c[0])

    def test_automatic_policy_retains_conflict_versions(self):
        self.mapping.conflict_policy = 'google'
        n, g = self.pair()
        self.n.edit(n, title='N')
        self.g.edit(g, title='G')
        self.sync()
        self.assertEqual(self.n.items[n].values['title'], 'G')
        self.assertGreater(self.store.db.execute('SELECT COUNT(*) FROM conflicts').fetchone()[0], 0)

    def test_delete_both_directions_no_resurrection(self):
        n, g = self.pair()
        self.n.delete(n)
        self.sync()
        self.assertTrue(self.g.items[g].deleted)
        self.n.items[n].deleted = False  # provider UI restore doesn't implicitly resurrect peer
        self.sync(full=True)
        self.assertTrue(self.g.items[g].deleted)
        self.g.add('g-other')
        self.sync()
        n2 = [x for x in self.n.items if x != n][0]
        self.g.delete('g-other')
        self.sync()
        self.assertTrue(self.n.items[n2].deleted)

    def test_delete_vs_edit_is_conflict(self):
        n, g = self.pair()
        self.n.delete(n)
        self.g.edit(g, title='surviving user edit')
        self.sync()
        self.assertFalse(self.g.items[g].deleted)
        c = self.store.db.execute("SELECT id FROM conflicts WHERE status='open'").fetchone()[0]
        with self.assertRaisesRegex(ValueError, 'restore'):
            self.engine.resolve(c, 'google')
        self.engine.resolve(c, 'notion')
        self.assertTrue(self.g.items[g].deleted)

    def test_permission_loss_and_query_absence_never_delete(self):
        n, g = self.pair()
        self.n.omit.add(n)
        self.n.hidden.add(n)
        self.sync(full=True)
        self.assertFalse(self.g.items[g].deleted)
        self.n.hidden.clear()
        self.n.edit(n, title='access recovered')
        self.sync(full=True)
        self.assertEqual(self.g.items[g].values['title'], 'access recovered')

    def test_cleared_date_pauses_both_sides(self):
        n, g = self.pair()
        self.n.items[n].eligible = False
        self.n.items[n].values.pop('time')
        self.g.edit(g, title='keep')
        self.sync()
        self.assertFalse(self.g.items[g].deleted)
        self.assertIn('time', self.g.items[g].values)
        self.assertNotEqual(self.n.items[n].values['title'], 'keep')

    def test_same_title_date_never_merged(self):
        self.n.add('n1')
        self.g.add('g1')
        self.sync()
        self.assertEqual(len(self.n.items), 2)
        self.assertEqual(len(self.g.items), 2)

    def test_explicit_ids_adopt_and_detect_initial_conflict(self):
        self.n.add('n1', raw={'ncs_peer_id': 'g1'})
        self.g.add('g1', values(title='different'))
        result = self.sync()
        self.assertEqual(len(self.n.items), 1)
        self.assertEqual(len(self.g.items), 1)
        self.assertTrue(any(x['action'] == 'conflict' for x in result))

    def test_dry_run_does_not_change_remote_or_local_state(self):
        self.n.add('n1')
        before = '\n'.join(self.store.db.iterdump())
        result = self.sync(dry_run=True, full=True)
        self.assertTrue(any(x['action'] == 'create' for x in result))
        self.assertEqual(before, '\n'.join(self.store.db.iterdump()))
        self.assertEqual(self.g.items, {})

    def test_power_cut_after_google_create_recovers_same_id(self):
        self.n.add('n1')
        self.g.crash = True
        with self.assertRaises(SystemExit):
            self.sync()
        self.store.close()
        self.store = Store(self.path)
        self.engine = Engine(self.config, self.store, self.n, self.g)
        self.sync()
        self.assertEqual(len(self.g.items), 1)
        self.assertEqual(self.store.db.execute('SELECT google_id FROM links').fetchone()[0], next(iter(self.g.items)))

    def test_power_cut_after_notion_create_recovers_marker(self):
        self.g.add('g1')
        self.n.crash = True
        with self.assertRaises(SystemExit):
            self.sync()
        self.sync()
        self.assertEqual(len(self.n.items), 1)
        self.assertEqual(self.store.db.execute('SELECT notion_id FROM links').fetchone()[0], next(iter(self.n.items)))

    def test_power_cut_after_update_idempotent(self):
        n, g = self.pair()
        self.n.edit(n, title='new')
        self.g.crash = True
        with self.assertRaises(SystemExit):
            self.sync()
        before = len(self.g.writes)
        self.sync()
        self.assertEqual(before, len(self.g.writes))
        self.assertEqual(self.g.items[g].values['title'], 'new')

    def test_power_cut_after_archive_idempotent(self):
        n, g = self.pair()
        self.n.delete(n)
        self.g.crash = True
        with self.assertRaises(SystemExit):
            self.sync()
        self.sync()
        self.assertTrue(self.g.items[g].deleted)
        self.assertEqual(self.store.db.execute('SELECT status FROM links').fetchone()[0], 'deleted')

    def test_temporary_failure_preserves_pending_then_recovers(self):
        n, g = self.pair()
        self.n.edit(n, title='new')
        self.g.fail = RetryableError('offline')
        self.sync()
        self.assertTrue(self.store.db.execute("SELECT 1 FROM operations WHERE status='retry'").fetchone())
        self.g.fail = None
        self.force_retry()
        self.sync()
        self.assertEqual(self.g.items[g].values['title'], 'new')

    def test_conflicted_item_does_not_block_others(self):
        n, g = self.pair()
        self.n.edit(n, title='N')
        self.g.edit(g, title='G')
        self.n.add('n2', values(title='other'))
        self.sync()
        self.assertEqual(len(self.g.items), 2)
        self.assertEqual(self.g.items[g].values['title'], 'G')

    def test_incomplete_scan_does_not_advance_cursor(self):
        self.n.add('n1')
        self.g.scan_fail = True
        self.sync()
        self.assertIsNone(self.store.get_meta('cursor:test:notion'))
        self.g.scan_fail = False
        self.sync()
        self.assertEqual(len(self.g.items), 1)

    def test_changed_source_during_pending_update_not_lost(self):
        n, g = self.pair()
        self.n.edit(n, title='first')
        self.g.fail = RetryableError('offline')
        self.sync()
        self.n.edit(n, title='newer')
        self.g.fail = None
        self.force_retry()
        self.sync()
        self.sync()
        self.assertEqual(self.g.items[g].values['title'], 'newer')

    def test_exception_inherited_master_marker_not_adopted_as_master(self):
        self.n.add('n-master', values(recurrence=['RRULE:FREQ=WEEKLY']))
        self.sync()
        g_master = next(iter(self.g.items))
        self.g.add('g-exception', raw={'ncs_peer_id': 'n-master', 'ncs_mapping': 'test',
                                      'recurringEventId': g_master, 'originalStartTime': {'date': '2026-11-06'}})
        self.sync()
        self.assertEqual(len(self.n.items), 2)
        links = list(self.store.db.execute('SELECT kind FROM links'))
        self.assertIn('exception', [r[0] for r in links])
        self.g.delete('g-exception')
        self.sync()
        self.assertFalse(self.n.items['n-master'].deleted)

    def test_notification_entity_fetches_missing_query_change(self):
        n, g = self.pair()
        self.n.omit.add(n)
        self.n.edit(n, title='webhook')
        self.store.signal('notion', entity=n, signal_id='event-1')
        self.store.signal('notion', entity=n, signal_id='event-1')
        self.sync()
        self.assertEqual(self.g.items[g].values['title'], 'webhook')
        before = len(self.g.writes)
        self.sync()
        self.assertEqual(before, len(self.g.writes))


if __name__ == '__main__':
    unittest.main()
