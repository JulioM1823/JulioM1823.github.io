from copy import deepcopy
import base64
import importlib.util
from pathlib import Path
import unittest

from notion_calendar_sync.config import Mapping
from notion_calendar_sync.history import calendar_url_identity, historical_trash_evidence, importable_history, legacy_identity, plan_pairs
from notion_calendar_sync.model import Record, normalize_time

N1 = '11111111-1111-4111-8111-111111111111'
N2 = '22222222-2222-4222-8222-222222222222'


class HistoricalIdentityTests(unittest.TestCase):
    def setUp(self):
        self.m = Mapping('research', 'source', 'calendar@group.calendar.google.com', properties={
            'title': 'Task', 'date': 'Date', 'google_url': 'Link', 'google_event_id': 'ID',
            'description': 'Note', 'location': 'Location', 'recurrence': 'Recurrence'})
        self.values = dict(title='Specific task', time=normalize_time('2026-11-01', '2026-11-02'),
                           description='', location='Room 218, Science Building', recurrence=[])
        self.n = Record(N1, deepcopy(self.values), raw={'created_time': '2026-10-20T12:00:00Z'})
        self.g = Record('event-one', deepcopy(self.values), raw={'created': '2026-10-20T12:02:00Z'})

    def plan(self, ns=None, gs=None, **kw):
        return plan_pairs(self.m, ns or [self.n], gs or [self.g], **kw)[0]

    def test_full_field_and_creation_evidence_links_existing_pair(self):
        self.assertEqual(len(self.plan()), 1)

    def test_address_whitespace_is_allowed_but_other_text_is_exact(self):
        self.g.values['location'] = 'Room 218,\nScience Building'
        self.assertEqual(len(self.plan()), 1)
        self.g.values['description'] = 'Different note'
        self.assertEqual(self.plan(), [])

    def test_same_title_date_alone_without_corroboration_never_links(self):
        self.n.values['location'] = self.g.values['location'] = ''
        self.g.raw['created'] = '2020-01-01T00:00:00Z'
        self.assertEqual(self.plan(), [])

    def test_near_creation_times_can_corroborate_all_empty_optional_fields(self):
        self.n.values['location'] = self.g.values['location'] = ''
        self.assertEqual(len(self.plan()), 1)

    def test_ambiguous_multiple_pages_or_events_are_never_joined(self):
        other = deepcopy(self.n); other.id = N2
        self.assertEqual(self.plan(ns=[self.n, other]), [])
        event = deepcopy(self.g); event.id = 'event-two'
        self.assertEqual(self.plan(gs=[self.g, event]), [])

    def test_same_item_in_another_notion_category_blocks_inferred_pair(self):
        other = deepcopy(self.n); other.id = N2; other.eligible = False
        self.assertEqual(self.plan(other_notions=[other]), [])

    def test_occupied_and_foreign_owned_items_are_preserved(self):
        self.assertEqual(self.plan(occupied_n=[N1.replace('-', '')]), [])
        self.assertEqual(self.plan(occupied_g=['event-one']), [])
        self.g.raw['ncs_mapping'] = 'another-calendar'
        self.assertEqual(self.plan(), [])

    def test_lost_known_peer_is_not_replaced_by_similar_event(self):
        self.n.raw['properties'] = {'Notion Automations Events Data': {
            'rich_text': [{'plain_text': 'synced;missing-event;' + self.m.google_calendar + ';' + N1}]}}
        self.assertEqual(self.plan(), [])

    def test_stable_id_links_different_values_without_title_guess(self):
        self.n.raw['properties'] = {'Notion Automations Events Data': {
            'rich_text': [{'plain_text': 'synced;event-one;' + self.m.google_calendar + ';' + N1}]}}
        self.g.values['title'] = 'A different current title'
        self.assertEqual(self.plan()[0]['evidence'], 'stored-provider-id')

    def test_competing_stable_id_claims_are_rejected(self):
        self.n.raw['properties'] = {'Notion Automations Events Data': {
            'rich_text': [{'plain_text': 'synced;event-one;' + self.m.google_calendar + ';' + N1}]}}
        other = deepcopy(self.g); other.id = 'event-two'
        other.raw['extendedProperties'] = {'private': {'nad_source': 'synced;event-two;' + self.m.google_calendar + ';' + N1}}
        self.assertEqual(self.plan(gs=[self.g, other]), [])

    def test_legacy_identity_checks_calendar_event_and_page(self):
        v = 'synced;event-one;' + self.m.google_calendar + ';' + N1
        self.assertTrue(legacy_identity(v, self.m.google_calendar, page_id=N1))
        self.assertIsNone(legacy_identity(v, 'other-calendar', page_id=N1))
        self.assertIsNone(legacy_identity(v, self.m.google_calendar, event_id='other-event'))

    def test_url_decode_is_host_checked_and_expands_calendar_alias(self):
        encoded = base64.urlsafe_b64encode(b'event-one calendar@g').decode().rstrip('=')
        self.assertEqual(calendar_url_identity('https://www.google.com/calendar/event?eid=' + encoded),
                         (self.m.google_calendar, 'event-one'))
        self.assertIsNone(calendar_url_identity('https://evil.invalid/calendar/event?eid=' + encoded))

    def test_time_range_recurrence_and_deletion_are_not_flattened(self):
        self.g.values['recurrence'] = ['RRULE:FREQ=WEEKLY']
        self.assertEqual(self.plan(), [])
        self.g.values['recurrence'] = []; self.g.deleted = True
        self.assertEqual(self.plan(), [])

    def test_backed_up_resolution_retains_newer_project_rename(self):
        spec = importlib.util.spec_from_file_location('resolver', Path(__file__).parents[1] / 'scripts' / 'resolve_backed_up.py')
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        self.n.values['title'] = 'Morales_2025a: Task'; self.g.values['title'] = 'Morales_2024a: Task'
        self.assertEqual(module.choice(self.n, self.g)[0], 'notion')
        self.g.values['title'] = 'Expanded project title'
        self.assertEqual(module.choice(self.n, self.g)[0], 'google')

    def rescheduled(self):
        self.n.values['time'] = normalize_time('2026-11-02', '2026-11-03')
        self.n.raw['last_edited_time'] = '2026-10-30T01:59:00Z'
        self.g.raw['updated'] = '2026-10-29T11:13:00Z'

    def test_near_creation_unique_content_identifies_a_newer_date_move(self):
        self.rescheduled()
        self.assertEqual(self.plan()[0]['evidence'], 'unique-content-near-creation-newer-notion-date')

    def test_reschedule_without_provenance_or_with_changed_duration_is_rejected(self):
        self.rescheduled(); self.g.raw['created'] = '2020-01-01T00:00:00Z'
        self.assertEqual(self.plan(), [])
        self.g.raw['created'] = '2026-10-20T12:02:00Z'
        self.n.values['time'] = normalize_time('2026-11-02', '2026-11-04')
        self.assertEqual(self.plan(), [])

    def test_reschedule_with_ambiguous_content_or_newer_google_is_rejected(self):
        self.rescheduled(); other = deepcopy(self.n); other.id = N2
        self.assertEqual(self.plan(ns=[self.n, other]), [])
        self.g.raw['updated'] = '2026-10-30T05:00:00Z'
        self.assertEqual(self.plan(), [])

    def trash_pair(self):
        self.n.deleted = True; self.n.raw['in_trash'] = True
        self.g.raw['extendedProperties'] = {'private': {'nad_source': 'synced;event-one;' + self.m.google_calendar + ';' + N1}}

    def test_retirement_requires_positive_trash_and_exact_legacy_identity(self):
        self.trash_pair()
        self.assertTrue(historical_trash_evidence(self.m, self.n, self.g))
        self.n.raw['in_trash'] = False
        self.assertFalse(historical_trash_evidence(self.m, self.n, self.g))

    def test_retirement_never_cancels_meetings_series_or_out_of_scope_items(self):
        self.trash_pair()
        for record, key, value in [(self.g.raw, 'attendees', [{'email': 'person@example.invalid'}]),
                                   (self.g.values, 'recurrence', ['RRULE:FREQ=WEEKLY']),
                                   (self.n.raw, 'ncs_out_of_scope', True)]:
            record[key] = value
            self.assertFalse(historical_trash_evidence(self.m, self.n, self.g))
            del record[key]

    def test_retirement_rejects_wrong_page_calendar_and_foreign_ownership(self):
        self.trash_pair(); self.g.raw['ncs_mapping'] = 'other'
        self.assertFalse(historical_trash_evidence(self.m, self.n, self.g))
        del self.g.raw['ncs_mapping']
        self.g.raw['extendedProperties']['private']['nad_source'] = 'synced;event-one;other;' + N1
        self.assertFalse(historical_trash_evidence(self.m, self.n, self.g))

    def test_import_audit_accepts_only_unclaimed_distinct_provider_ids(self):
        self.assertEqual(len(importable_history(self.m, [], [self.g])[0]), 1)
        self.assertEqual(importable_history(self.m, [], [self.g], ['event-one'])[0], [])

    def test_import_audit_rejects_existing_counterparts_even_with_different_notes(self):
        self.n.values['description'] = 'Notion-only details'
        self.assertEqual(importable_history(self.m, [self.n], [self.g])[0], [])

    def test_import_audit_checks_other_category_identity_and_cleared_dates(self):
        self.n.eligible = False; self.n.values.pop('time')
        self.assertEqual(importable_history(self.m, [self.n], [self.g])[0], [])
        self.n.values['title'] = 'Other title'
        self.n.raw['properties'] = {'ID': {'rich_text': [{'plain_text': self.g.id}]}}
        self.assertEqual(importable_history(self.m, [self.n], [self.g])[0], [])

    def test_import_audit_never_recreates_deleted_or_foreign_known_peers(self):
        self.g.raw['extendedProperties'] = {'private': {'nad_source': 'synced;event-one;' + self.m.google_calendar + ';' + N1}}
        self.assertEqual(importable_history(self.m, [], [self.g])[0], [])
        self.g.raw = {}; self.g.deleted = True
        self.assertEqual(importable_history(self.m, [], [self.g])[0], [])

    def test_import_audit_rejects_duplicated_ical_identity_or_full_values(self):
        other = deepcopy(self.g); other.id = 'event-two'
        self.assertEqual(importable_history(self.m, [], [self.g, other])[0], [])
        self.g.raw['iCalUID'] = other.raw['iCalUID'] = 'same-uid'
        other.values['title'] = 'Another title'
        self.assertEqual(importable_history(self.m, [], [self.g, other])[0], [])
