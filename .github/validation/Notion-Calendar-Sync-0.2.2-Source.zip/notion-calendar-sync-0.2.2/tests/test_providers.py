import copy
from datetime import date
import os
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from notion_calendar_sync.http import (AccessError, AmbiguousWrite, PreconditionFailed, ProviderError,
                                       ReauthRequired)
from notion_calendar_sync.providers import NotionProvider, GoogleProvider, NOTION_VERSION


def mapping(**kwargs):
    data = dict(name='test', notion_data_source='source-1', google_calendar='calendar@example.com',
                timezone='America/Denver', default_duration_minutes=60, allow_attendees=False, notion_incremental=False,
                properties={'title': 'Task', 'date': 'Date', 'description': 'Note', 'location': 'Location',
                            'google_url': 'gCal Link', 'google_event_id': 'NCS Event ID',
                            'recurrence': 'Recurrence'})
    data.update(kwargs)
    return SimpleNamespace(**data)


def config():
    return SimpleNamespace(notion_token_env='NCS_TEST_TOKEN', google_client_path='/tmp/client-unused.json',
                           google_token_path='/tmp/token-unused.json')


def page(id='page-1', **kwargs):
    data = {'object': 'page', 'id': id, 'last_edited_time': '2026-10-30T12:00:00Z',
            'url': 'https://www.notion.so/' + id, 'parent': {'data_source_id': 'source-1'},
            'properties': {'Task': {'title': [{'plain_text': 'A title'}]},
                           'Date': {'date': {'start': '2026-11-01', 'end': None}},
                           'Note': {'rich_text': [{'plain_text': '<b>exact HTML</b>'}]},
                           'Location': {'rich_text': []}, 'NCS Event ID': {'rich_text': []},
                           'Recurrence': {'rich_text': []}, 'gCal Link': {'url': None}}}
    data.update(kwargs)
    return data


def event(id='event-1', **kwargs):
    data = {'id': id, 'summary': 'A title', 'etag': 'v1', 'status': 'confirmed',
            'start': {'date': '2026-11-01'}, 'end': {'date': '2026-11-02'},
            'description': '<b>exact HTML</b>', 'htmlLink': 'https://calendar.google.com/event?eid=x'}
    data.update(kwargs)
    return data


class FakeTransport:
    def __init__(self, *results): self.results = list(results); self.calls = []
    def request(self, *args, **kwargs):
        self.calls.append((args, kwargs))
        result = self.results.pop(0)
        if isinstance(result, Exception): raise result
        return copy.deepcopy(result)


class Tokens:
    def __init__(self): self.forces = []
    def access_token(self, force=False): self.forces.append(force); return 'token'


class NotionProviderTests(unittest.TestCase):
    def setUp(self):
        self.mapping = mapping()
        self.env = patch.dict(os.environ, {'NCS_TEST_TOKEN': 'test-token'})
        self.env.start(); self.addCleanup(self.env.stop)

    def provider(self, *results):
        self.transport = FakeTransport(*results)
        return NotionProvider(config(), self.transport)

    def test_api_version_pinned(self):
        self.provider(page()).get(self.mapping, 'page-1')
        self.assertEqual(self.transport.calls[0][1]['headers']['Notion-Version'], NOTION_VERSION)
        self.assertEqual(NOTION_VERSION, '2026-03-11')

    def test_all_day_notion_inclusive_google_exclusive(self):
        record = self.provider()._record(self.mapping, page())
        self.assertEqual(record.values['time']['end'], '2026-11-02')
        self.assertTrue(record.values['time']['all_day'])

    def test_multiday_roundtrip(self):
        source = page()
        source['properties']['Date']['date']['end'] = '2026-11-04'
        provider = self.provider()
        values = provider._record(self.mapping, source).values
        self.assertEqual(values['time']['end'], '2026-11-05')
        self.assertEqual(provider._properties(self.mapping, values)['Date']['date']['end'], '2026-11-04')

    def test_description_html_source_preserved(self):
        provider = self.provider()
        record = provider._record(self.mapping, page())
        self.assertEqual(record.values['description'], '<b>exact HTML</b>')
        self.assertEqual(provider._properties(self.mapping, record.values)['Note']['rich_text'][0]['text']['content'], '<b>exact HTML</b>')

    def test_empty_date_pause_not_deletion(self):
        source = page(); source['properties']['Date']['date'] = None
        record = self.provider()._record(self.mapping, source)
        self.assertFalse(record.eligible); self.assertFalse(record.deleted)

    def test_checkbox_disable_pause(self):
        self.mapping.properties['sync_enabled'] = 'Sync'
        source = page(); source['properties']['Sync'] = {'checkbox': False}
        record = self.provider()._record(self.mapping, source)
        self.assertFalse(record.eligible); self.assertFalse(record.deleted)

    def test_moved_page_pause(self):
        record = self.provider()._record(self.mapping, page(parent={'data_source_id': 'other'}))
        self.assertFalse(record.eligible)

    def test_positive_trash(self):
        record = self.provider(page(in_trash=True)).get(self.mapping, 'page-1')
        self.assertTrue(record.deleted)

    def test_missing_access_raises(self):
        with self.assertRaises(AccessError): self.provider(AccessError('missing', 404)).get(self.mapping, 'page-1')

    def test_scan_consumes_all_pages_and_archived(self):
        provider = self.provider({'results': [page()], 'has_more': True, 'next_cursor': 'p2'},
                                 {'results': [page('page-2')], 'has_more': False},
                                 {'results': [page('page-3', in_trash=True)], 'has_more': False})
        scan = provider.scan(self.mapping)
        self.assertEqual(len(scan.records), 3)
        self.assertEqual(self.transport.calls[1][1]['body']['start_cursor'], 'p2')
        self.assertTrue(self.transport.calls[2][1]['body']['is_archived'])

    def test_incremental_overlap(self):
        self.mapping.notion_incremental = True
        provider = self.provider({'results': [], 'has_more': False}, {'results': [], 'has_more': False})
        provider.scan(self.mapping, cursor='2026-10-30T12:00:00+00:00')
        since = self.transport.calls[0][1]['body']['filter']['last_edited_time']['on_or_after']
        self.assertEqual(since, '2026-10-30T11:58:00+00:00')

    def test_create_searches_stable_marker_before_post(self):
        provider = self.provider({'results': [page()], 'has_more': False}, {'results': [], 'has_more': False})
        record = provider.create(self.mapping, {}, 'op', 'event-1')
        self.assertEqual(record.id, 'page-1')
        self.assertEqual(len(self.transport.calls), 2)

    def test_ambiguous_notion_creation_never_blindly_replayed(self):
        provider = self.provider({'results': [], 'has_more': False}, {'results': [], 'has_more': False})
        with self.assertRaises(AmbiguousWrite): provider.create(self.mapping, {}, 'op', 'event-1', recovery_only=True)
        self.assertFalse(any(args[1].endswith('/pages') for args, _ in self.transport.calls))

    def test_create_has_peer_marker_and_no_content(self):
        provider = self.provider({'results': [], 'has_more': False}, {'results': [], 'has_more': False}, page())
        provider.create(self.mapping, {'title': 'new'}, 'op', 'event-1')
        body = self.transport.calls[-1][1]['body']
        self.assertEqual(body['parent']['data_source_id'], 'source-1')
        self.assertEqual(body['properties']['NCS Event ID']['rich_text'][0]['text']['content'], 'event-1')
        self.assertNotIn('children', body)
        self.assertFalse(self.transport.calls[-1][1]['safe'])

    def test_update_only_mapped_fields(self):
        provider = self.provider(page(), page(last_edited_time='v2'))
        provider.update(self.mapping, 'page-1', {'title': 'changed'}, '2026-10-30T12:00:00Z')
        self.assertEqual(set(self.transport.calls[-1][1]['body']), {'properties'})
        self.assertEqual(set(self.transport.calls[-1][1]['body']['properties']), {'Task'})

    def test_update_compares_version(self):
        provider = self.provider(page())
        with self.assertRaises(PreconditionFailed): provider.update(self.mapping, 'page-1', {'title': 'new'}, 'old')
        self.assertEqual(len(self.transport.calls), 1)

    def test_timed_write_uses_iana_timezone_without_offset(self):
        provider = self.provider()
        props = provider._properties(self.mapping, {'time': {'start': '2026-11-01T00:30:00-06:00',
                   'end': '2026-11-01T02:30:00-07:00', 'timezone': 'America/Denver', 'all_day': False}})
        self.assertEqual(props['Date']['date']['time_zone'], 'America/Denver')
        self.assertNotIn('-06:00', props['Date']['date']['start'])

    def test_duplicate_marker_is_reported(self):
        provider = self.provider({'results': [page(), page('page-2')], 'has_more': False}, {'results': [], 'has_more': False})
        with self.assertRaises(ProviderError): provider.create(self.mapping, {}, 'op', 'event-1')


class GoogleProviderTests(unittest.TestCase):
    def setUp(self): self.mapping = mapping()
    def provider(self, *results):
        self.transport = FakeTransport(*results)
        self.tokens = Tokens()
        return GoogleProvider(config(), self.transport, self.tokens)

    def test_incremental_pages(self):
        provider = self.provider({'items': [event()], 'nextPageToken': 'p2'}, {'items': [event('event-2')], 'nextSyncToken': 'new'})
        scan = provider.scan(self.mapping, 'old')
        self.assertEqual(scan.cursor, 'new'); self.assertEqual(len(scan.records), 2)
        self.assertIn('syncToken=old', self.transport.calls[-1][0][1])
        self.assertIn('pageToken=p2', self.transport.calls[-1][0][1])
        self.assertIn('singleEvents=false', self.transport.calls[-1][0][1])

    def test_legacy_gmt_offset_maps_to_iana_without_changing_instants(self):
        source = event(start={'dateTime': '2023-12-17T08:51:00-07:00', 'timeZone': 'GMT-05:00'},
                       end={'dateTime': '2023-12-17T10:40:00-07:00', 'timeZone': 'GMT-05:00'})
        r = self.provider()._record(self.mapping, source)
        self.assertTrue(r.eligible)
        self.assertEqual(r.values['time']['timezone'], 'Etc/GMT+5')
        self.assertEqual(r.values['time']['start'], '2023-12-17T10:51:00-05:00')
        self.assertEqual(r.values['time']['end'], '2023-12-17T12:40:00-05:00')

    def test_legacy_gmt_positive_and_zero_offsets_have_correct_sign(self):
        from notion_calendar_sync.providers import _google_timezone
        self.assertEqual(_google_timezone('GMT+05:00'), 'Etc/GMT-5')
        self.assertEqual(_google_timezone('GMT+00:00'), 'Etc/GMT')

    def test_unrecognized_offset_zone_still_preserves_and_pauses(self):
        for zone in ('GMT+05:30', 'GMT+15:00'):
            source = event(start={'dateTime': '2026-01-01T10:00:00Z', 'timeZone': zone},
                           end={'dateTime': '2026-01-01T11:00:00Z', 'timeZone': zone})
            self.assertFalse(self.provider()._record(self.mapping, source).eligible)

    def test_410_resets_token_with_full_list(self):
        provider = self.provider(ProviderError('gone', 410), {'items': [event()], 'nextSyncToken': 'new'})
        self.assertEqual(provider.scan(self.mapping, 'expired').cursor, 'new')
        self.assertNotIn('syncToken', self.transport.calls[-1][0][1])
        self.assertTrue(provider.last_reset)

    def test_missing_get_never_deleted(self):
        for status in (403, 404, 410):
            with self.assertRaises(AccessError): self.provider(AccessError('no', status)).get(self.mapping, 'id')

    def test_explicit_cancellation_tombstone(self):
        record = self.provider({'id': 'event-1', 'status': 'cancelled'}).get(self.mapping, 'event-1')
        self.assertTrue(record.deleted)

    def test_google_create_deterministic_duplicate_recovery(self):
        provider = self.provider(ProviderError('exists', 409), event(extendedProperties={'private': {
               'ncs_operation': 'operation', 'ncs_page': 'page-1'}}))
        provider.create(self.mapping, provider._record(self.mapping, event()).values, 'operation', 'page-1')
        body = self.transport.calls[0][1]['body']
        self.assertEqual(body['id'], GoogleProvider.event_id('operation'))
        self.assertIn('sendUpdates=none', self.transport.calls[0][0][1])
        self.assertNotIn('attendees', body)

    def test_update_preserves_unmapped_metadata(self):
        provider = self.provider(event(colorId='4', attendees=[], reminders={'useDefault': False}), event(etag='v2'))
        provider.update(self.mapping, 'event-1', {'title': 'new'}, 'v1')
        body = self.transport.calls[-1][1]['body']
        self.assertEqual(body, {'summary': 'new'})
        self.assertEqual(self.transport.calls[-1][1]['version'] if 'version' in self.transport.calls[-1][1] else self.transport.calls[-1][1]['headers']['If-Match'], 'v1')

    def test_attendees_default_skip_and_write_guard(self):
        source = event(attendees=[{'email': 'person@example.com'}])
        provider = self.provider(source)
        self.assertFalse(provider._record(self.mapping, source).eligible)
        with self.assertRaises(PreconditionFailed): provider.update(self.mapping, 'event-1', {'title': 'new'})
        self.assertEqual(len(self.transport.calls), 1)

    def test_attendees_default_archive_guard(self):
        provider = self.provider(event(attendees=[{'email': 'person@example.com'}]))
        with self.assertRaises(PreconditionFailed): provider.archive(self.mapping, 'event-1')
        self.assertEqual(len(self.transport.calls), 1)

    def test_recurrence_series_not_expanded(self):
        source = event(recurrence=['RRULE:FREQ=WEEKLY;BYDAY=MO'])
        provider = self.provider()
        record = provider._record(self.mapping, source)
        self.assertEqual(record.values['recurrence'], source['recurrence'])
        self.assertTrue(record.eligible)

    def test_recurrence_without_mapping_reported(self):
        self.mapping.properties.pop('recurrence')
        record = self.provider()._record(self.mapping, event(recurrence=['RRULE:FREQ=DAILY']))
        self.assertFalse(record.eligible)

    def test_occurrence_patch_uses_specific_id_and_rejects_new_series(self):
        provider = self.provider(event('instance', recurringEventId='master'), event('instance', etag='v2', recurringEventId='master'))
        provider.update(self.mapping, 'instance', {'title': 'exception'}, 'v1')
        self.assertIn('/instance?', self.transport.calls[-1][0][1])
        self.assertNotIn('recurrence', self.transport.calls[-1][1]['body'])
        provider = self.provider(event('instance', recurringEventId='master'))
        with self.assertRaises(ProviderError): provider.update(self.mapping, 'instance', {'recurrence': ['RRULE:FREQ=DAILY']})

    def test_occurrence_cancellation_keeps_series_id(self):
        provider = self.provider(event('instance', recurringEventId='master'), {})
        record = provider.archive(self.mapping, 'instance', 'v1')
        self.assertTrue(record.deleted)
        self.assertIn('/instance?', self.transport.calls[-1][0][1])
        self.assertNotIn('/master', self.transport.calls[-1][0][1])

    def test_link_metadata_merges_and_preserves_source(self):
        provider = self.provider(event(extendedProperties={'private': {'other': 'keep'}}, source={'url': 'https://example.com', 'title': 'unrelated'}), event())
        provider.set_links(self.mapping, 'event-1', 'page-1', 'https://notion.so/page-1')
        body = self.transport.calls[-1][1]['body']
        self.assertEqual(body['extendedProperties']['private']['other'], 'keep')
        self.assertNotIn('source', body)

    def test_401_refreshes_once(self):
        provider = self.provider(ReauthRequired('expired', 401), event())
        self.assertEqual(provider.get(self.mapping, 'event-1').id, 'event-1')
        self.assertEqual(self.tokens.forces, [False, True])

    def test_special_event_types_skipped(self):
        record = self.provider()._record(self.mapping, event(eventType='birthday'))
        self.assertFalse(record.eligible)

    def test_archive_recovery_410_only_in_explicit_archive(self):
        provider = self.provider(ProviderError('deleted', 410))
        self.assertTrue(provider.archive(self.mapping, 'event-1', 'v1').deleted)


class TimezonePropertyTests(unittest.TestCase):
    def test_fall_fold_offset_preserved_with_zone_property(self):
        m = mapping()
        m.properties['timezone'] = 'Time Zone'
        provider = NotionProvider(config(), FakeTransport())
        props = provider._properties(m, {'time': {'start': '2026-11-01T01:30:00-07:00',
                 'end': '2026-11-01T02:30:00-07:00', 'timezone': 'America/Denver', 'all_day': False}})
        self.assertEqual(props['Date']['date']['start'], '2026-11-01T08:30:00+00:00')
        self.assertIsNone(props['Date']['date']['time_zone'])
        self.assertEqual(props['Time Zone']['rich_text'][0]['text']['content'], 'America/Denver')

    def test_crossing_dst_range_survives_notion_single_offset_storage(self):
        from notion_calendar_sync.model import normalize_time
        m = mapping(); m.properties['timezone'] = 'Time Zone'
        provider = NotionProvider(config(), FakeTransport())
        for start, end in [('2035-03-11T01:30:00-07:00', '2035-03-11T03:30:00-06:00'),
                           ('2026-11-01T01:30:00-06:00', '2026-11-01T01:30:00-07:00')]:
            with self.subTest(start=start):
                value = normalize_time(start, end, 'America/Denver')
                props = provider._properties(m, {'time': value})
                self.assertTrue(all(props['Date']['date'][k].endswith('+00:00') for k in ('start', 'end')))
                p = page(); p['properties'].update(props)
                self.assertEqual(provider._record(m, p).values['time'], value)

    def test_fall_fold_without_zone_property_is_explicitly_unsupported(self):
        provider = NotionProvider(config(), FakeTransport())
        with self.assertRaises(ProviderError):
            provider._properties(mapping(), {'time': {'start': '2026-11-01T01:30:00-07:00',
                     'end': '2026-11-01T02:30:00-07:00', 'timezone': 'America/Denver', 'all_day': False}})


class ProviderSafetyRegressionTests(unittest.TestCase):
    def test_missing_title_with_valid_date_is_incomplete_not_clear(self):
        p = page(); del p['properties']['Task']
        record = NotionProvider(config(), FakeTransport())._record(mapping(), p)
        self.assertFalse(record.eligible)
        self.assertFalse(record.deleted)

    def test_missing_optional_mapped_property_is_incomplete(self):
        p = page(); del p['properties']['Note']
        record = NotionProvider(config(), FakeTransport())._record(mapping(), p)
        self.assertFalse(record.eligible)

    def test_page_moved_to_plain_page_is_ineligible(self):
        record = NotionProvider(config(), FakeTransport())._record(mapping(), page(parent={'type': 'page_id', 'page_id': 'other'}))
        self.assertFalse(record.eligible)

    def test_unknown_timezone_pauses_only_item(self):
        m = mapping(); m.properties['timezone'] = 'Zone'
        p = page(); p['properties']['Zone'] = {'rich_text': [{'plain_text': 'Unknown/Zone'}]}
        p['properties']['Date']['date'] = {'start': '2026-10-30T12:00:00-06:00', 'end': '2026-10-30T13:00:00-06:00'}
        record = NotionProvider(config(), FakeTransport())._record(m, p)
        self.assertFalse(record.eligible)

    def test_inherited_exception_metadata_verified_before_override(self):
        inherited = {'private': {'ncs_page': 'master-page', 'ncs_mapping': 'test', 'other': 'keep'}}
        transport = FakeTransport(event('instance', recurringEventId='master', extendedProperties=inherited),
                                  event('master', extendedProperties=inherited), event('instance'))
        provider = GoogleProvider(config(), transport, Tokens())
        provider.set_links(mapping(), 'instance', 'exception-page', 'https://notion.so/exception')
        self.assertTrue(transport.calls[-1][0][1].split('?')[0].endswith('/instance'))
        self.assertEqual(transport.calls[-1][1]['body']['extendedProperties']['private']['ncs_page'], 'exception-page')
        self.assertEqual(transport.calls[-1][1]['body']['extendedProperties']['private']['other'], 'keep')

    def test_independent_exception_metadata_not_overwritten(self):
        transport = FakeTransport(event('instance', recurringEventId='master', extendedProperties={'private': {'ncs_page': 'other-page', 'ncs_mapping': 'test'}}),
                                  event('master', extendedProperties={'private': {'ncs_page': 'master-page', 'ncs_mapping': 'test'}}))
        provider = GoogleProvider(config(), transport, Tokens())
        with self.assertRaises(PreconditionFailed):
            provider.set_links(mapping(), 'instance', 'exception-page')
        self.assertEqual(len(transport.calls), 2)


class AllDayZoneRoundtripTests(unittest.TestCase):
    def test_timed_to_all_day_replaces_zone_metadata(self):
        m = mapping(); m.properties['timezone'] = 'Zone'
        provider = NotionProvider(config(), FakeTransport())
        props = provider._properties(m, {'time': {'start': '2026-11-01', 'end': '2026-11-02',
                          'timezone': 'America/Denver', 'all_day': True}})
        source = page(); source['properties']['Zone'] = {'rich_text': [{'plain_text': 'Europe/London'}]}
        source['properties'].update(props)
        record = provider._record(m, source)
        self.assertEqual(record.values['time']['timezone'], 'America/Denver')


class ProviderCurrentApiTests(unittest.TestCase):
    def test_notion_database_archive_is_pause_not_trash(self):
        record = NotionProvider(config(), FakeTransport())._record(mapping(), page(is_archived=True))
        self.assertFalse(record.deleted)
        self.assertFalse(record.eligible)

    def test_query_result_limit_is_not_complete(self):
        transport = FakeTransport({'results': [], 'has_more': False, 'request_status': {'type': 'incomplete'}})
        with patch.dict(os.environ, {'NCS_TEST_TOKEN': 'x'}):
            with self.assertRaises(ProviderError):
                NotionProvider(config(), transport).scan(mapping())

    def test_empty_calendar_may_omit_items(self):
        provider = GoogleProvider(config(), FakeTransport({'kind': 'calendar#events', 'nextSyncToken': 'empty'}), Tokens())
        scan = provider.scan(mapping())
        self.assertEqual(scan.records, [])
        self.assertEqual(scan.cursor, 'empty')

    def test_notions_potentially_truncated_mentions_pause(self):
        p = page()
        p['properties']['Note']['rich_text'] = [{'type': 'mention', 'plain_text': 'person', 'mention': {'type': 'user', 'user': {'id': 'person'}}} for _ in range(25)]
        record = NotionProvider(config(), FakeTransport())._record(mapping(), p)
        self.assertFalse(record.eligible)
        self.assertFalse(record.deleted)

    def test_all_day_ignores_event_specific_timezone(self):
        m = mapping(); m.properties['timezone'] = 'Zone'
        p = page(); p['properties']['Zone'] = {'rich_text': [{'plain_text': 'Europe/London'}]}
        record = NotionProvider(config(), FakeTransport())._record(m, p)
        self.assertEqual(record.values['time']['timezone'], m.timezone)


class MembershipScanTests(unittest.TestCase):
    def test_default_notion_poll_is_complete_membership_even_with_watermark(self):
        transport = FakeTransport({'results': [], 'has_more': False}, {'results': [], 'has_more': False})
        with patch.dict(os.environ, {'NCS_TEST_TOKEN': 'x'}):
            scan = NotionProvider(config(), transport).scan(mapping(), cursor='2026-10-30T12:00:00+00:00')
        self.assertTrue(scan.full_membership)
        self.assertNotIn('filter', transport.calls[0][1]['body'])

    def test_optional_notion_incremental_scan_is_not_full_membership(self):
        transport = FakeTransport({'results': [], 'has_more': False}, {'results': [], 'has_more': False})
        with patch.dict(os.environ, {'NCS_TEST_TOKEN': 'x'}):
            scan = NotionProvider(config(), transport).scan(mapping(notion_incremental=True), cursor='2026-10-30T12:00:00+00:00')
        self.assertFalse(scan.full_membership)
        self.assertIn('filter', transport.calls[0][1]['body'])

    def test_google_full_membership_only_initial_or_reset(self):
        provider = GoogleProvider(config(), FakeTransport({'items': [], 'nextSyncToken': 'new'}), Tokens())
        self.assertTrue(provider.scan(mapping()).full_membership)
        provider = GoogleProvider(config(), FakeTransport({'items': [], 'nextSyncToken': 'new'}), Tokens())
        self.assertFalse(provider.scan(mapping(), cursor='old').full_membership)

    def test_google_reset_full_membership(self):
        provider = GoogleProvider(config(), FakeTransport(ProviderError('expired', 410), {'items': [], 'nextSyncToken': 'new'}), Tokens())
        self.assertTrue(provider.scan(mapping(), cursor='expired').full_membership)
