"""Native widget contracts without account access or real credentials."""
import queue
import unittest
import time
from unittest.mock import patch

from notion_calendar_sync.desktop_ui import DesktopWindow, display_name


SCHEMA = {'properties': {
    'Task': {'id': 'title', 'type': 'title'},
    'When': {'id': 'date-id', 'type': 'date'},
    'Other date': {'id': 'date-other', 'type': 'date'},
    'Stable identity': {'id': 'id-field', 'type': 'rich_text'},
    'Notes': {'id': 'notes-field', 'type': 'rich_text'},
    'Category': {'id': 'category-field', 'type': 'select', 'select': {'options': [{'name': 'Research'}, {'name': 'Personal'}]}},
}}


class Controller:
    def state(self):
        return {'configured': False, 'connected_notion': False, 'connected_google': False}

    def suggest_mapping(self, schema):
        return {'title': 'Task', 'date': 'When', 'google_event_id': 'Stable identity', 'description': 'Notes'}

    def conflicts(self):
        return []

    def close(self):
        pass


class UiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            import tkinter as tk
            root = tk.Tk()
            root.destroy()
        except Exception as exc:
            raise unittest.SkipTest('Native Tk display unavailable: '+type(exc).__name__)

    def setUp(self):
        import tkinter as tk
        self.root = tk.Tk()
        self.root.withdraw()
        self.window = DesktopWindow(Controller(), self.root)
        self.window._apply_schema(SCHEMA)
        self.window.source_id.set('d16a3bdc-2654-4788-a891-59c023e3d1f1')
        self.window.calendar_id.set('calendar@example.test')

    def tearDown(self):
        self.window._destroy()

    def test_property_dropdowns_filter_types_and_preserve_saved_ids(self):
        self.assertEqual(tuple(self.window.mapping_combos['date']['values']), ('', 'When', 'Other date'))
        self.window.mapping_vars['date'].set('date-other')
        self.window.category_property.set('category-field')
        self.window.category_value.set('Research')
        self.window._apply_schema(SCHEMA)
        self.assertEqual(self.window.mapping_vars['date'].get(), 'Other date')
        self.assertEqual(self.window.category_property.get(), 'Category')
        self.assertEqual(self.window.category_value.get(), 'Research')

    def test_required_and_duplicate_mapping_validation(self):
        settings = self.window._settings()
        self.assertEqual(settings['properties']['date'], 'When')
        self.window.mapping_vars['google_event_id'].set('')
        with self.assertRaisesRegex(ValueError, 'required'):
            self.window._settings()
        self.window.mapping_vars['google_event_id'].set('Notes')
        with self.assertRaisesRegex(ValueError, 'different'):
            self.window._settings()

    def test_editing_settings_invalidates_previous_approval(self):
        self.window.preview_id = 'immutable-preview'
        self.window.approve_button.configure(state='normal')
        self.window.duration.set('90')
        self.assertIsNone(self.window.preview_id)
        self.assertIn('disabled', self.window.approve_button.state())

    def test_changing_settings_during_preview_cannot_enable_approval(self):
        captured = []
        self.window._run = lambda label, fn, callback=None, quiet=False: captured.append(callback)
        self.window._preview()
        self.window.duration.set('120')
        captured[-1]({'preview_id': 'stale', 'summary': {'create': 2}, 'report': []})
        self.assertIsNone(self.window.preview_id)
        self.assertIn('disabled', self.window.approve_button.state())

    def test_blocked_preview_never_enables_approval(self):
        captured = []
        self.window._run = lambda label, fn, callback=None, quiet=False: captured.append(callback)
        self.window._preview()
        captured[-1]({'preview_id': 'blocked', 'blocked': True, 'report': [{'action': 'error'}]})
        self.assertIsNone(self.window.preview_id)
        self.assertIn('disabled', self.window.approve_button.state())

    def test_property_creation_requires_explicit_confirmation(self):
        calls = []
        self.window._run = lambda *args, **kw: calls.append(args)
        with patch('notion_calendar_sync.desktop_ui.messagebox.askyesno', return_value=False):
            self.window._create_properties()
        self.assertEqual(calls, [])

    def test_dashboard_exposes_health_without_raw_diagnostic_json(self):
        self.window._render_state({'configured': True, 'running': True, 'approved': True,
            'status': {'links': [{'status': 'active', 'count': 12}],
                       'operations': [{'status': 'done', 'count': 20}, {'status': 'pending', 'count': 2}],
                       'conflicts': [{'status': 'open', 'count': 1}],
                       'diagnostics': {'last_success:desktop': 1793358486}}, 'settings': {}})
        text = self.window.detail_label['text']
        self.assertIn('12 linked items', text)
        self.assertIn('2 pending operations', text)
        self.assertIn('1 conflicts', text)
        self.assertIn('Last successful sync:', text)
        self.assertNotIn('last_success:desktop', text)

    def test_name_disambiguation_keeps_full_ids(self):
        a, b = display_name({'name': 'Calendar', 'id': 'id-one'}), display_name({'name': 'Calendar', 'id': 'id-two'})
        self.assertNotEqual(a, b)
        self.assertIn('id-one', a)


class WizardFlowController(Controller):
    def __init__(self):
        self.running = False
        self.approved = False
        self.settings = {}
        self.preview_calls = 0

    def state(self):
        return {'configured': self.approved, 'approved': self.approved, 'running': self.running,
                'connected_notion': True, 'connected_google': True, 'settings': self.settings,
                'status': {'links': [{'status': 'active', 'count': 2}]}}

    def data_sources(self, identifier):
        return [{'id': 'd16a3bdc-2654-4788-a891-59c023e3d1f1', 'name': 'Calendar'}]

    def calendars(self):
        return [{'id': 'calendar@example.test', 'name': 'Calendar'}]

    def schema(self, source):
        return SCHEMA

    def preview(self, settings):
        self.settings = dict(settings)
        self.preview_calls += 1
        return {'preview_id': 'verified-preview', 'summary': {'create': 2}, 'report': [{'action': 'create', 'title': 'Offline demo'}]}

    def approve(self, preview_id):
        assert preview_id == 'verified-preview'
        self.running = self.approved = True
        return {'approved': True, 'running': True}


class AsyncWizardFlowTests(unittest.TestCase):
    def test_native_wizard_reaches_dashboard_only_after_explicit_approval(self):
        import tkinter as tk
        try:
            root = tk.Tk()
        except tk.TclError as exc:
            self.skipTest('Native Tk display unavailable: '+str(exc))
        controller = WizardFlowController()
        window = DesktopWindow(controller, root)
        root.withdraw()
        def until(predicate):
            deadline = time.monotonic()+3
            while not predicate() and time.monotonic()<deadline:
                root.update()
                time.sleep(.01)
            self.assertTrue(predicate())
        try:
            until(lambda: window.current_state.get('connected_notion'))
            window.database_query.set('d16a3bdc26544788a89159c023e3d1f1')
            window._find_databases()
            until(lambda: window.source_id.get() and window.calendar_id.get())
            window._inspect_and_continue()
            until(lambda: window.page == 'mapping')
            window._preview()
            until(lambda: window.preview_id == 'verified-preview')
            self.assertFalse(controller.running)
            with patch('notion_calendar_sync.desktop_ui.messagebox.askyesno', return_value=True) as confirmation:
                window._approve()
            self.assertIn('one sync instance', confirmation.call_args.args[1])
            until(lambda: window.page == 'dashboard' and window.current_state.get('running'))
            self.assertEqual(controller.preview_calls, 1)
            self.assertIn('2 linked items', window.detail_label['text'])
        finally:
            window._destroy()
