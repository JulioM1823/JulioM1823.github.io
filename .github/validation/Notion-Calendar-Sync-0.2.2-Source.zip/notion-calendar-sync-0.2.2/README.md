# Notion Calendar Sync

A free, MIT-licensed desktop application for two-way synchronization between Notion and Google Calendar on macOS and Windows. It includes guided account connection, schema-based field mapping, read-only previews, persistent conflicts, explicit two-way deletion, SQLite recovery and compressed API responses.

Start with the [complete public setup guide](https://juliom1823.github.io/notion-calendar-sync/), including [desktop account connection and field mapping](https://juliom1823.github.io/notion-calendar-sync/#desktop-setup). The same source package contains a headless CLI and Raspberry Pi systemd deployment files. Follow the [public Pi instructions](https://juliom1823.github.io/notion-calendar-sync/#pi-setup) or [downloadable server notes](https://juliom1823.github.io/notion-calendar-sync/downloads/server-setup.md) for that route. A public HTTPS endpoint is unnecessary for normal polling.

The source archive also includes `docs/desktop.md`, `docs/mapping.md`, `docs/security.md` and `docs/api-notes.md`, relative to the extracted source root. The online links in this README work both in its root copy and its retained `packaging/` copy.

## Install the CLI from source

Extract the entire source ZIP first. Open a terminal in the extracted `notion-calendar-sync-VERSION` folder containing `pyproject.toml`, replacing `VERSION` with the release number. The engine needs Python 3.11 or newer. Running these commands installs the package in a new local virtual environment; it does not connect accounts or synchronize provider data.

On macOS or Linux:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install .
.venv/bin/ncs --help
```

On Windows, use PowerShell and a Python 3.11+ installation with the `py` launcher. The desktop extra supplies regional time-zone data required on Windows:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install ".[desktop]"
.\.venv\Scripts\ncs.exe --help
```

Next follow the public setup guide for your Notion token and database access, your Google Desktop OAuth client, the exact configuration, Google authorization and a read-only initial preview. Keep credentials outside the source tree. The packaged desktop downloads include their own runtime and do not need this Python installation step.

## Run source tests or build the desktop application

The desktop UI needs Python with Tk support. The native builder must run on the target operating system, with the matching build dependencies. From the same extracted source root and virtual environment on macOS:

```sh
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python -m pip install -r packaging/requirements-build.txt
.venv/bin/python scripts/build-desktop.py native
```

The corresponding PowerShell commands are:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -m pip install -r packaging\requirements-build.txt
.\.venv\Scripts\python.exe scripts\build-desktop.py native
```

The included `docs/desktop.md` explains architecture-specific builds, the portable Windows runtime option and platform validation boundaries. Build tools do not authorize provider access. Native execution and controlled-response tests are distinct from Google/Notion account consent and a live provider smoke test.

## Data and license boundaries

The source archive intentionally excludes account-specific deployment reports, screenshots, observed configurations, private backups, credentials and synchronization state. Public reports that are included identify their tested platforms and distinguish controlled responses from actual provider checks. Historical personal deployment reports are not required to install the tool.

The application cannot synchronize while its host is asleep, offline or not running. Never run independent synchronizers against the same provider scope without transferring and reviewing their stable identity mappings. Do not delete SQLite history to force a new import.

Application source is [MIT](https://juliom1823.github.io/notion-calendar-sync/downloads/LICENSE.txt). The same license is included as `LICENSE` at the source root. Bundled runtime notices are in `THIRD_PARTY_NOTICES.md` at the source root and are retained with distributed application bundles.
