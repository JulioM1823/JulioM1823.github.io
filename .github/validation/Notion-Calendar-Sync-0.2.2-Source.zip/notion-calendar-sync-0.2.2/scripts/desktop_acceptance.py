#!/usr/bin/env python3
"""Offline desktop end-to-end acceptance against isolated simulated REST APIs.

Uses the actual desktop controller, official provider adapters, merge engine and
SQLite journal. It never reads real credentials or calls Notion/Google. A real
localhost OAuth callback exercises PKCE/state with a simulated token endpoint.
Run using the packaged Windows runtime or either Mac architecture's interpreter.
"""
from __future__ import annotations
import argparse
from contextlib import closing
from copy import deepcopy
from datetime import datetime, timezone
import json
from pathlib import Path
import platform
import sqlite3
import tempfile
import threading
import time
from urllib.parse import parse_qs, unquote, urlsplit
import urllib.error
import urllib.request
from unittest.mock import patch
import uuid

from notion_calendar_sync.desktop_backend import DesktopController
from notion_calendar_sync.http import AccessError, PreconditionFailed, ProviderError, RetryableError
from notion_calendar_sync.model import normalize_time
from notion_calendar_sync.oauth import authorize as real_authorize
from notion_calendar_sync.providers import NotionProvider, GoogleProvider
from notion_calendar_sync.store import Store

SOURCE='11111111-2222-4333-8444-555555555555'
OTHER='22222222-3333-4444-8555-666666666666'
DATABASE='33333333-4444-4555-8666-777777777777'
CALENDAR='acceptance-calendar'

class Vault:
    def __init__(self):self.values={}
    def get(self,key):return self.values.get(key)
    def set(self,key,value):self.values[key]=value
    def delete(self,key):self.values.pop(key,None)

class Tokens:
    def access_token(self,force=False):return 'offline-simulated-access'

class Remote:
    """Finite JSON REST fixture; no network connections or production IDs."""
    def __init__(self):
        self.lock=threading.RLock();self.pages={};self.events={};self.revision=0
        self.writes=[];self.creates={'notion':0,'google':0};self.crash_google_create=False
        self.denied=False;self.offline=False
        self.properties={name:{'id':name,'type':kind,kind:{}} for name,kind in
                         [('Subject','title'),('Window','date'),('Details','rich_text'),('Venue','rich_text'),('Identity','rich_text'),('Unrelated','rich_text')]}
        self.properties['Category']={'id':'category','type':'select','select':{'options':[{'name':'Research'},{'name':'Personal'}]}}
    def stamp(self):
        self.revision+=1
        return datetime.now(timezone.utc).isoformat(), '"rev-'+str(self.revision)+'"'
    def schema(self,id=SOURCE):return {'object':'data_source','id':id,'title':[{'plain_text':'Shared name'}],'parent':{'database_id':DATABASE},'properties':deepcopy(self.properties)}
    def rich(self,text):return [{'type':'text','plain_text':text,'text':{'content':text}}]
    def props(self,values):
        out={}
        for name,definition in self.properties.items():
            kind=definition['type'];value=deepcopy(values.get(name, [] if kind in ('title','rich_text') else None))
            if isinstance(value,str) and kind in ('title','rich_text'):value=self.rich(value)
            out[name]={'id':definition['id'],'type':kind,kind:value}
        return out
    def add_page(self,title,**values):
        id=str(uuid.uuid4());stamp,_=self.stamp()
        values={'Subject':title,'Window':{'start':'2036-01-15T10:00:00-07:00','end':'2036-01-15T11:00:00-07:00','time_zone':None},'Details':'literal <b>notes</b>','Venue':'Room A','Category':{'name':'Research'},'Unrelated':'preserve this property',**values}
        self.pages[id]={'object':'page','id':id,'url':'https://www.notion.so/'+id.replace('-',''),'parent':{'data_source_id':SOURCE},'properties':self.props(values),'in_trash':False,'is_archived':False,'created_time':stamp,'last_edited_time':stamp,'blocks':{'fixture-only':'preserve page content'}}
        return id
    def add_event(self,title,**values):
        id='fixture'+uuid.uuid4().hex;stamp,etag=self.stamp()
        self.events[id]={'id':id,'summary':title,'description':'Google notes','location':'Room G','start':{'dateTime':'2036-01-16T10:00:00-07:00','timeZone':'America/Denver'},'end':{'dateTime':'2036-01-16T11:00:00-07:00','timeZone':'America/Denver'},'status':'confirmed','etag':etag,'created':stamp,'updated':stamp,'htmlLink':'https://calendar.google.com/event?fixture='+id,'recurrence':[],'colorId':'7','transparency':'opaque','reminders':{'useDefault':False,'overrides':[{'method':'popup','minutes':7}]},'extendedProperties':{'private':{'unrelated':'preserve metadata'}},**values}
        return id
    def edit_page(self,id,**properties):
        page=self.pages[id]
        for name,value in properties.items():
            kind=self.properties[name]['type']
            page['properties'][name]={'id':self.properties[name]['id'],'type':kind,kind:self.rich(value) if isinstance(value,str) and kind in ('title','rich_text') else deepcopy(value)}
        page['last_edited_time']=self.stamp()[0]
    def edit_event(self,id,**values):
        self.events[id].update(deepcopy(values));stamp,etag=self.stamp();self.events[id].update(updated=stamp,etag=etag)
    def request(self,method,url,*,body=None,headers=None,**kwargs):
        with self.lock:return self._request(method,url,body=deepcopy(body),headers=headers or {},**kwargs)
    def _request(self,method,url,*,body,headers,**kwargs):
        if self.offline:raise RetryableError('Simulated connectivity loss')
        parsed=urlsplit(url);path=unquote(parsed.path);query=parse_qs(parsed.query)
        if parsed.netloc=='oauth2.googleapis.com':return {'access_token':'offline-access','refresh_token':'offline-refresh','expires_in':3600}
        if parsed.netloc=='api.notion.com':
            path=path.removeprefix('/v1')
            if path=='/users/me':return {'object':'user','type':'bot','id':'fixture-bot'}
            if path=='/search':
                return {'results':[self.schema(SOURCE),self.schema(OTHER)],'has_more':False,'next_cursor':None}
            if path=='/databases/'+DATABASE:return {'object':'database','id':DATABASE,'data_sources':[{'id':SOURCE,'name':'Shared name'},{'id':OTHER,'name':'Shared name'}]}
            if path.startswith('/databases/'):raise AccessError('Not a database ID',404)
            if path.startswith('/data_sources/') and path.endswith('/query'):
                records=[deepcopy(p) for p in self.pages.values() if not p['in_trash'] and p['is_archived']==body.get('is_archived',False)]
                def matches(page,f):
                    if not f:return True
                    if 'and' in f:return all(matches(page,x) for x in f['and'])
                    if 'property' in f:
                        prop=page['properties'].get(f['property'],{});kind=prop.get('type');value=prop.get(kind)
                        expected=f.get(kind,{}).get('equals')
                        if kind=='select':return (value or {}).get('name')==expected
                        if kind=='rich_text':return ''.join(x.get('plain_text',x.get('text',{}).get('content','')) for x in value)==expected
                    return True
                records=[p for p in records if matches(p,body.get('filter'))]
                # Real adapters must consume pagination, even for this tiny fixture.
                offset=int(body.get('start_cursor','0'));page=records[offset:offset+1];more=offset+1<len(records)
                return {'results':page,'has_more':more,'next_cursor':str(offset+1) if more else None}
            if path.startswith('/data_sources/'):
                if method=='PATCH':
                    for name,value in body['properties'].items():
                        kind=next(iter(value));self.properties[name]={'id':name,'type':kind,kind:deepcopy(value[kind])}
                        for p in self.pages.values():p['properties'][name]={'id':name,'type':kind,kind:[] if kind=='rich_text' else None}
                    self.writes.append(('notion','schema'));return self.schema()
                return self.schema()
            if path=='/pages' and method=='POST':
                id=self.add_page('');self.pages[id]['properties'].update(self._normalize_props(body['properties']));self.creates['notion']+=1;self.writes.append(('notion','create',id));return deepcopy(self.pages[id])
            if path.startswith('/pages/'):
                id=path.split('/')[-1]
                if id not in self.pages:raise AccessError('Simulated missing page',404)
                if method=='PATCH':
                    self.pages[id]['properties'].update(self._normalize_props(body.get('properties',{})))
                    if 'in_trash' in body:self.pages[id]['in_trash']=body['in_trash']
                    self.pages[id]['last_edited_time']=self.stamp()[0];self.writes.append(('notion','patch',id))
                return deepcopy(self.pages[id])
        if parsed.netloc=='www.googleapis.com':
            path=path.removeprefix('/calendar/v3')
            if self.denied:raise AccessError('Simulated permission loss',403)
            cal={'id':CALENDAR,'summary':'Shared calendar name','accessRole':'owner','timeZone':'America/Denver'}
            if path.startswith('/users/me/calendarList/') :return cal
            if path=='/users/me/calendarList':return {'items':[cal,dict(cal,id='second-calendar',accessRole='writer'),dict(cal,id='readonly',accessRole='reader')]}
            prefix='/calendars/'+CALENDAR+'/events'
            if path==prefix:
                if method=='GET':
                    if query.get('syncToken')==['expired']:raise ProviderError('Simulated expired token',410)
                    rows=list(self.events.values());offset=int(query.get('pageToken',['0'])[0]);page=deepcopy(rows[offset:offset+1])
                    return {'items':page,'nextPageToken':str(offset+1)} if offset+1<len(rows) else {'items':page,'nextSyncToken':'fixture-token-'+str(self.revision)}
                id=body['id']
                if id in self.events:raise ProviderError('Already exists',409)
                self.add_event('temporary')
                temporary=next(reversed(self.events));event=self.events.pop(temporary);event.update(body,id=id);self.events[id]=event
                self.creates['google']+=1;self.writes.append(('google','create',id))
                if self.crash_google_create:
                    self.crash_google_create=False;raise SystemExit('Simulated process exit after remote commit')
                return deepcopy(event)
            if path.startswith(prefix+'/'):
                id=path.removeprefix(prefix+'/')
                if id not in self.events:raise AccessError('Simulated missing event',404)
                event=self.events[id]
                if headers.get('If-Match') and headers['If-Match']!=event['etag']:raise PreconditionFailed('Simulated concurrent revision',412)
                if method=='DELETE':event['status']='cancelled';self.writes.append(('google','delete',id))
                elif method=='PATCH':
                    for key,value in body.items():
                        if key in ('extendedProperties','start','end'):
                            event.setdefault(key,{})
                            for k,v in value.items():
                                if isinstance(v,dict):event[key].setdefault(k,{}).update(v)
                                elif v is None:event[key].pop(k,None)
                                else:event[key][k]=v
                        elif value is None:event.pop(key,None)
                        else:event[key]=value
                    self.writes.append(('google','patch',id))
                if method in ('PATCH','DELETE'):
                    stamp,etag=self.stamp();event.update(updated=stamp,etag=etag)
                return deepcopy(event) if method!='DELETE' else {}
        raise AssertionError('Unimplemented simulated API route: '+method+' '+parsed.netloc+path)
    def _normalize_props(self,props):
        result={}
        for name,value in props.items():
            kind=self.properties[name]['type'];value=deepcopy(value)
            if kind in ('title','rich_text'):
                for part in value[kind]:part['plain_text']=part.get('text',{}).get('content','')
            result[name]={'id':self.properties[name]['id'],'type':kind,**value}
        return result


def run_acceptance(directory=None):
    temporary=tempfile.TemporaryDirectory(prefix='ncs-desktop-acceptance-') if directory is None else None
    root=Path(temporary.name if temporary else directory);root.mkdir(parents=True,exist_ok=True)
    remote=Remote();vault=Vault();checks=[];threads=[];controller=None;started=time.monotonic()
    def factory(config):
        return NotionProvider(config,remote,token_loader=lambda:vault.get('notion_token')),GoogleProvider(config,remote,Tokens())
    def check(name,condition):
        if not condition:raise AssertionError(name)
        checks.append(name)
    def wait(predicate,name):
        deadline=time.monotonic()+8
        while time.monotonic()<deadline:
            if predicate():return
            time.sleep(.01)
        raise AssertionError('Timed out: '+name)
    def with_db(query):
        config=controller._config(controller._saved['settings'])
        with closing(sqlite3.connect(str(config.state_path))) as db:
            db.row_factory=sqlite3.Row;return query(db)
    def pair(column,id):return with_db(lambda db:(lambda r:dict(r) if r else None)(db.execute('SELECT * FROM links WHERE '+column+'=?',(id,)).fetchone()))
    def cycle(condition,name):
        controller.resume();wait(condition,name);controller.pause()
    try:
        controller=DesktopController(root,vault,provider_factory=factory,autorun=False)
        with patch('notion_calendar_sync.desktop_backend.NotionProvider',side_effect=lambda config,token_loader=None:NotionProvider(config,remote,token_loader=token_loader)):
            controller.connect_notion('offline-simulated-notion')
        controller.connect_google(json.dumps({'installed':{'client_id':'offline-client','client_secret':'offline-client-secret'}}))
        oauth_observed={}
        def browser(url):
            values=parse_qs(urlsplit(url).query);oauth_observed.update(values)
            def callback():
                bad=values['redirect_uri'][0]+'?code=wrong&state=wrong'
                try:urllib.request.urlopen(bad,timeout=3)
                except urllib.error.HTTPError as e:
                    check('OAuth wrong-state callback rejected',e.code==400);e.close()
                good=values['redirect_uri'][0]+'?code=fixture-code&state='+values['state'][0]
                with urllib.request.urlopen(good,timeout=3) as response:check('OAuth valid-state callback accepted',response.status==200)
            t=threading.Thread(target=callback);threads.append(t);t.start()
        def oauth(*args,**kw):return real_authorize(*args,**kw,transport=remote,timeout=5)
        with patch('notion_calendar_sync.desktop_backend.authorize',side_effect=oauth),patch('notion_calendar_sync.oauth.webbrowser.open',side_effect=browser):
            controller.authorize_google()
        for t in threads:t.join(5)
        check('PKCE S256 negotiated',oauth_observed.get('code_challenge_method')==['S256'])
        check('Credentials kept out of files',not any('offline-client-secret' in p.read_text(errors='ignore') or 'offline-refresh' in p.read_text(errors='ignore') for p in root.glob('*.json')))
        rows=controller.databases('Shared');check('Duplicate names retain distinct source IDs',len(rows)==2 and len({r['id'] for r in rows})==2)
        check('Database URL enumerates multiple data sources',len(controller.data_sources('https://www.notion.so/'+DATABASE.replace('-','')))==2)
        check('Only writable calendars selectable',len(controller.calendars())==2)
        before=deepcopy(remote.properties)
        try:controller.create_properties(SOURCE)
        except ValueError:pass
        else:raise AssertionError('Schema mutation lacked explicit confirmation')
        check('Unconfirmed schema creation makes no changes',before==remote.properties)
        controller.create_properties(SOURCE,True)
        check('Confirmed schema creation preserves existing properties',all(remote.properties[k]==v for k,v in before.items()))
        mapping=controller.suggest_mapping(controller.schema(SOURCE));check('Typed title/date mapping suggested',mapping['title']=='Subject' and mapping['date']=='Window')
        settings={'notion_data_source':SOURCE,'google_calendar':CALENDAR,'timezone':'America/Denver','notion_select_property':'Category','notion_select_value':'Research','properties':{'title':'Subject','date':'Window','description':'Details','location':'Venue','google_event_id':'Identity','google_url':'Calendar Link','timezone':'NCS Time Zone','recurrence':'Recurrence'}}
        nid=remote.add_page('Acceptance Notion');gid=remote.add_event('Acceptance Google')
        page_unknown=deepcopy(remote.pages[nid]['properties']['Unrelated']);blocks=deepcopy(remote.pages[nid]['blocks']);google_unknown={k:deepcopy(remote.events[gid][k]) for k in ('colorId','transparency','reminders')}
        preview=controller.preview(settings);writes=len(remote.writes)
        check('Preview is read-only and reports both creates',preview['summary'].get('create')==2 and not controller.state()['approved'])
        try:controller.approve('not-the-preview')
        except ValueError:pass
        else:raise AssertionError('First synchronization lacked preview consent')
        check('Invalid approval performs no writes',len(remote.writes)==writes)
        controller.approve(preview['preview_id'])
        wait(lambda:pair('notion_id',nid) and pair('notion_id',nid)['status']=='active' and pair('google_id',gid) and pair('google_id',gid)['status']=='active' and all(pair(c,i)[other] for c,i,other in [('notion_id',nid,'google_id'),('google_id',gid,'notion_id')]),'both initial pairs')
        controller.pause();first=pair('notion_id',nid);second=pair('google_id',gid)
        check('Exactly two identities linked',len(remote.pages)==len(remote.events)==2)
        check('First-sync backup exists',len(list(root.glob('before-first-sync-*.sqlite3')))==1)
        n,g=factory(controller._config(settings));m=controller._config(settings).mappings[0]
        remote.edit_page(nid,Subject='Updated from Notion')
        cycle(lambda:g.get(m,first['google_id']).values['title']=='Updated from Notion','Notion edit to Google')
        remote.edit_event(gid,description='Google <b>literal notes</b>',location='Room updated')
        cycle(lambda:n.get(m,second['notion_id']).values['description']=='Google <b>literal notes</b>','Google edit to Notion')
        check('Both directions preserve exact mapped notes',n.get(m,second['notion_id']).values['location']=='Room updated')
        # Independent edits merge without a conflict, and a Notion reschedule
        # exercises the opposite direction from the Google time edits below.
        remote.edit_page(nid,Details='Independent Notion note')
        remote.edit_event(first['google_id'],location='Independent Google location')
        cycle(lambda:g.get(m,first['google_id']).values['description']=='Independent Notion note' and n.get(m,nid).values['location']=='Independent Google location','independent edits merge')
        check('Independent field edits merge without loss',not controller.conflicts())
        london=normalize_time('2036-01-20T14:00:00+00:00','2036-01-20T16:00:00+00:00','Europe/London')
        remote.edit_page(nid,Window={'start':london['start'],'end':london['end'],'time_zone':None},**{'NCS Time Zone':'Europe/London'})
        cycle(lambda:g.get(m,first['google_id']).values['time']==london,'Notion reschedule and timezone to Google')
        check('Notion time range and zone synchronize exactly',g.get(m,first['google_id']).values['time']==london)
        remote.edit_page(nid,Window=None)
        cycle(lambda:pair('notion_id',nid)['status']=='paused','cleared date pauses')
        check('Cleared date pauses without cancelling Calendar',remote.events[first['google_id']]['status']=='confirmed' and g.get(m,first['google_id']).values['time']==london)
        remote.edit_page(nid,Window={'start':london['start'],'end':london['end'],'time_zone':None})
        cycle(lambda:pair('notion_id',nid)['status']=='active','restored date resumes same pair')
        remote.edit_event(gid,start={'date':'2036-02-02'},end={'date':'2036-02-05'})
        cycle(lambda:n.get(m,second['notion_id']).values['time']['all_day'],'all-day conversion')
        check('All-day exclusive/inclusive semantics retained',remote.pages[second['notion_id']]['properties']['Window']['date']['end']=='2036-02-04')
        dst=normalize_time('2035-03-11T01:30:00-07:00','2035-03-11T03:30:00-06:00','America/Denver')
        remote.edit_event(gid,start={'dateTime':dst['start'],'timeZone':'America/Denver'},end={'dateTime':dst['end'],'timeZone':'America/Denver'})
        cycle(lambda:n.get(m,second['notion_id']).values['time']==dst,'DST range conversion')
        check('Timed DST range round-trips exact instants',n.get(m,second['notion_id']).values['time']==dst)
        remote.edit_page(nid,Subject='Conflicting Notion version');remote.edit_event(first['google_id'],summary='Conflicting Google version')
        cycle(lambda:bool(controller.conflicts()),'conflict detected')
        check('Conflict preserves both versions',n.get(m,nid).values['title']=='Conflicting Notion version' and g.get(m,first['google_id']).values['title']=='Conflicting Google version')
        resolved=controller.resolve(controller.conflicts()[0]['id'],'notion');check('Explicit conflict resolution applied',resolved['resolved'])
        cycle(lambda:g.get(m,first['google_id']).values['title']=='Conflicting Notion version','resolved values')
        config=controller._config(settings)
        with Store(config.state_path) as store:
            for _ in range(3):store.signal('google',m.name,signal_id='same-notification')
            check('Duplicate notification receipt deduplicated',store.db.execute('SELECT count(*) FROM signals').fetchone()[0]==1)
        count=len(remote.writes)
        cycle(lambda:with_db(lambda db:db.execute('SELECT count(*) FROM signals').fetchone()[0]==0),'duplicate signals processed')
        for _ in range(2):
            previous=controller.state()['status']['diagnostics'].get('last_success:desktop')
            cycle(lambda:controller.state()['status']['diagnostics'].get('last_success:desktop')!=previous,'unchanged reconciliation')
        check('Repeated reconciliation has zero feedback writes',len(remote.writes)==count)
        remote.denied=True;controller.resume();wait(lambda:bool(controller.state()['status']['diagnostics'].get('last_error:desktop')),'permission error surfaced');controller.pause()
        check('Permission loss never deletes or creates peers',len(remote.writes)==count and not remote.pages[nid]['in_trash'] and remote.events[gid]['status']=='confirmed')
        remote.denied=False;previous=controller.state()['status']['diagnostics'].get('last_success:desktop')
        cycle(lambda:controller.state()['status']['diagnostics'].get('last_success:desktop')!=previous,'permission recovery')
        check('Connectivity/access recovery retains identities',pair('notion_id',nid)['google_id']==first['google_id'] and pair('google_id',gid)['notion_id']==second['notion_id'])
        check('Unrelated Notion property and page content unchanged',remote.pages[nid]['properties']['Unrelated']==page_unknown and remote.pages[nid]['blocks']==blocks)
        check('Unrelated Google metadata unchanged',all(remote.events[gid][k]==v for k,v in google_unknown.items()) and remote.events[gid]['extendedProperties']['private']['unrelated']=='preserve metadata')
        remote.pages[nid]['in_trash']=True;remote.edit_event(gid,status='cancelled')
        cycle(lambda:pair('notion_id',nid)['status']=='deleted' and pair('google_id',gid)['status']=='deleted','two-way deletion')
        check('Notion Trash cancels exact Google peer',remote.events[first['google_id']]['status']=='cancelled')
        check('Google cancellation trashes exact Notion peer',remote.pages[second['notion_id']]['in_trash'])
        before_counts=(len(remote.pages),len(remote.events));count=len(remote.writes)
        previous=controller.state()['status']['diagnostics'].get('last_success:desktop')
        cycle(lambda:controller.state()['status']['diagnostics'].get('last_success:desktop')!=previous,'deleted reconciliation')
        check('Deletion tombstones prevent resurrection or duplicates',(len(remote.pages),len(remote.events))==before_counts and len(remote.writes)==count)
        # Crash after a real adapter's deterministic POST committed remotely,
        # before its response reached SQLite. Restart an entirely new controller.
        crash_nid=remote.add_page('Crash recovery source');remote.crash_google_create=True;created=remote.creates['google'];controller.resume()
        wait(lambda:not controller._thread.is_alive(),'injected remote-commit crash');controller.close()
        controller=DesktopController(root,vault,provider_factory=factory,autorun=True)
        wait(lambda:pair('notion_id',crash_nid) and pair('notion_id',crash_nid)['status']=='active' and pair('notion_id',crash_nid)['google_id'],'restart recovery');controller.pause()
        check('Restart after committed remote create creates only one event',remote.creates['google']==created+1)
        check('Restart retains original tombstones',pair('notion_id',nid)['status']=='deleted' and pair('google_id',gid)['status']=='deleted')
        master=remote.add_event('Recurring master',recurrence=['RRULE:FREQ=WEEKLY;COUNT=4'])
        cycle(lambda:pair('google_id',master) is not None and pair('google_id',master)['status']=='active','recurring master represented')
        master_pair=pair('google_id',master)
        check('Recurring master retains exact rule',n.get(m,master_pair['notion_id']).values['recurrence']==['RRULE:FREQ=WEEKLY;COUNT=4'])
        occurrence=remote.add_event('Modified occurrence',recurringEventId=master,originalStartTime={'dateTime':'2036-01-23T10:00:00-07:00','timeZone':'America/Denver'})
        cycle(lambda:pair('google_id',occurrence) is not None and pair('google_id',occurrence)['status']=='active','modified occurrence represented')
        occurrence_pair=pair('google_id',occurrence)
        check('Finite recurrence representation does not expand future instances',len(remote.pages)==len(remote.events)==5)
        remote.edit_event(occurrence,status='cancelled')
        cycle(lambda:pair('google_id',occurrence)['status']=='deleted','occurrence cancellation')
        check('Occurrence cancellation trashes only its own page',remote.pages[occurrence_pair['notion_id']]['in_trash'] and not remote.pages[master_pair['notion_id']]['in_trash'] and remote.events[master]['status']=='confirmed')
        remote.pages[master_pair['notion_id']]['in_trash']=True
        cycle(lambda:pair('google_id',master)['status']=='deleted','Notion master deletion')
        check('Notion master Trash cancels the corresponding series',remote.events[master]['status']=='cancelled')
        scan=g.scan(m,cursor='expired',full=False)
        check('Expired Google token recovers full listing without losing identities',g.last_reset and {r.id for r in scan.records}==set(remote.events))
        # Ensure a broken connection is not confused with deletion, then recover.
        remote.offline=True;count=len(remote.writes);controller.resume();wait(lambda:bool(controller.state()['status']['diagnostics'].get('last_error:desktop')),'offline error surfaced');controller.pause();remote.offline=False
        check('Connectivity loss preserves remote data',len(remote.writes)==count)
        previous=controller.state()['status']['diagnostics'].get('last_success:desktop');cycle(lambda:controller.state()['status']['diagnostics'].get('last_success:desktop')!=previous,'network recovery')
        with Store(config.state_path) as store:
            identities=store.db.execute('SELECT notion_id,google_id,status FROM links').fetchall()
            check('Provider identities are globally unique',len({r['notion_id'] for r in identities})==len(identities)==len({r['google_id'] for r in identities}))
            check('No incomplete operations remain',store.db.execute("SELECT count(*) FROM operations WHERE status NOT IN ('done','cancelled')").fetchone()[0]==0)
            check('SQLite integrity check passes',store.db.execute('PRAGMA quick_check').fetchone()[0]=='ok')
        controller.diagnostics(root/'redacted.json');raw=(root/'redacted.json').read_text()
        check('Diagnostics exclude credentials and event titles',not any(s in raw for s in ['offline-client-secret','offline-refresh','Acceptance Notion','Conflicting Notion']))
        return {'passed':True,'checks':checks,'check_count':len(checks),'elapsed_seconds':round(time.monotonic()-started,3),
                'platform':platform.system(),'machine':platform.machine(),'python':platform.python_version(),
                'mode':'actual DesktopController + official adapters + Engine + SQLite; isolated simulated REST providers and token endpoint; real loopback OAuth callback',
                'real_provider_accounts_accessed':False,'real_credentials_accessed':False,'remaining_relationships':len(identities),
                'remote_actual_creates':dict(remote.creates),'duplicate_identities':0,'data_preservation_verified':True}
    finally:
        if controller:controller.close()
        for t in threads:t.join(5)
        if temporary:temporary.cleanup()


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path);args=parser.parse_args()
    report=run_acceptance()
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
