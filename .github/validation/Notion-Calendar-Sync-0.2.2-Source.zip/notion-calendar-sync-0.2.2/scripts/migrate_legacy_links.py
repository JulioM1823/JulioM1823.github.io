#!/usr/bin/env python3
"""Adopt verified Notion Automations identities; never match titles/dates.

Run with the service stopped. Default is read-only. --apply writes only local
SQLite links/observations; normal sync still reviews disagreements as conflicts.
"""
import argparse,json,sys,time
from pathlib import Path
from collections import Counter
from notion_calendar_sync.config import load_config
from notion_calendar_sync.providers import NotionProvider,GoogleProvider,_text
from notion_calendar_sync.http import ProviderError
from notion_calendar_sync.store import Store
from notion_calendar_sync.service import StateLock


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',required=True);parser.add_argument('--apply',action='store_true')
    args=parser.parse_args();c=load_config(args.config);n=NotionProvider(c);g=GoogleProvider(c);counts=Counter()
    with StateLock(c.state_path),Store(c.state_path) as store:
        if args.apply:
            backup=Path(str(c.state_path)+'.before-legacy-'+str(int(time.time()))+'.backup')
            store.backup(backup)
        for m in c.mappings:
            n.validate(m);g.validate(m)
            for page in n._query(m):
                record=n._record(m,page)
                source=_text(page.get('properties',{}).get('Notion Automations Events Data',{}));parts=source.split(';')
                if len(parts)<4 or parts[2]!=m.google_calendar or parts[3].replace('-','')!=record.id.replace('-',''):
                    counts['no_verified_legacy_identity']+=1;continue
                if not parts[1] or '/' in parts[1] or len(parts[1])>1024:
                    counts['invalid_legacy_identity']+=1;continue
                existing=store.db.execute('SELECT * FROM links WHERE mapping=? AND (notion_id=? OR google_id=?)',(m.name,record.id,parts[1])).fetchall()
                if existing:
                    counts['already_linked_or_occupied']+=1;continue
                try: peer=g.get(m,parts[1])
                except ProviderError:
                    counts['unavailable_google_item']+=1;continue
                if peer.raw.get('ncs_mapping') not in (None,'',m.name):
                    counts['foreign_owner']+=1;continue
                if peer.raw.get('ncs_peer_id') and peer.raw['ncs_peer_id'].replace('-','')!=record.id.replace('-',''):
                    counts['foreign_owner']+=1;continue
                counts['verified_links']+=1
                if not record.eligible or not peer.eligible:counts['paused_links']+=1
                elif any(record.values.get(k)!=peer.values.get(k) for k in m.mapped_fields):counts['initial_differences_for_review']+=1
                if args.apply:
                    with store.db:
                        store.db.execute('INSERT INTO links(mapping,notion_id,google_id,kind) VALUES(?,?,?,?)',(m.name,record.id,peer.id,'exception' if peer.raw.get('recurringEventId') else 'series' if peer.values.get('recurrence') else 'single'))
                        store.put_record(m.name,'notion',record);store.put_record(m.name,'google',peer)
        print(json.dumps({'applied_to_local_state':args.apply,'counts':dict(counts)},indent=2))

if __name__=='__main__': main()
