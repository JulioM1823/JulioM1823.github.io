#!/bin/sh
# Run from the source tree: sudo ./scripts/install-pi.sh
# Installs code/service; DOES NOT enable synchronization or overwrite config.
set -eu
if [ "$(id -u)" -ne 0 ]; then
    echo 'Run with sudo from the source directory.' >&2
    exit 1
fi
source_dir=$(CDPATH='' cd -- "$(dirname -- "$0")/.." && pwd)
if [ ! -r /etc/os-release ]; then
    echo 'Expected Raspberry Pi OS / Debian. See docs/deployment.md.' >&2
    exit 1
fi
. /etc/os-release
case "${VERSION_CODENAME:-unknown}" in
    bookworm|trixie) ;;
    *) echo 'Supported deployment target: Raspberry Pi OS Bookworm/Trixie.' >&2; exit 1 ;;
esac
architecture=$(dpkg --print-architecture)
case "$architecture" in
    arm64|armhf) ;;
    *) echo 'This installer targets arm64/armhf Raspberry Pi OS only.' >&2; exit 1 ;;
esac
if systemctl is-active --quiet ncs.service; then
    echo "Stop ncs.service before installation/upgrade." >&2
    exit 1
fi
apt-get update
apt-get install -y python3 python3-venv python3-pip python3-setuptools python3-wheel tzdata ca-certificates sqlite3
python3 -c 'import sys; assert sys.version_info >= (3,11), "Python 3.11+ is required"'
if ! id ncs >/dev/null 2>&1; then
    adduser --system --group --home /var/lib/ncs --no-create-home ncs
fi
install -d -o root -g root -m 0755 /opt/ncs /opt/ncs/app
install -d -o root -g ncs -m 0750 /etc/ncs
install -d -o ncs -g ncs -m 0700 /var/lib/ncs
# Copy source only; no local config, OAuth credentials, or database.
rm -rf /opt/ncs/app/src
cp -R "$source_dir/src" /opt/ncs/app/
cp -R "$source_dir/docs" "$source_dir/examples" "$source_dir/scripts" /opt/ncs/app/
install -m 0644 "$source_dir/pyproject.toml" "$source_dir/README.md" "$source_dir/LICENSE" /opt/ncs/app/
python3 -m venv --system-site-packages /opt/ncs/venv
/opt/ncs/venv/bin/python -m pip install --no-index --no-deps --no-build-isolation --upgrade /opt/ncs/app
if [ ! -e /etc/ncs/config.toml ]; then
    install -o root -g ncs -m 0640 "$source_dir/examples/config.toml" /etc/ncs/config.toml
    sed -i 's|"../state/sync.sqlite3"|"/var/lib/ncs/sync.sqlite3"|; s|"../secrets/google-token.json"|"/var/lib/ncs/google-token.json"|; s|"../secrets/google-client.json"|"/etc/ncs/google-client.json"|' /etc/ncs/config.toml
fi
if [ ! -e /etc/ncs/secrets.env ]; then
    install -o root -g root -m 0600 "$source_dir/examples/secrets.env.example" /etc/ncs/secrets.env
fi
install -o root -g root -m 0644 "$source_dir/deploy/ncs.service" /etc/systemd/system/ncs.service
install -o root -g root -m 0644 "$source_dir/deploy/journald@ncs.conf" /etc/systemd/journald@ncs.conf
install -o root -g root -m 0755 "$source_dir/deploy/ncs-control" /usr/local/bin/ncs-control
systemctl daemon-reload
echo "Installed for $VERSION_CODENAME/$architecture. Configure /etc/ncs, authorize Google, then inspect and dry-run. Service remains disabled."
