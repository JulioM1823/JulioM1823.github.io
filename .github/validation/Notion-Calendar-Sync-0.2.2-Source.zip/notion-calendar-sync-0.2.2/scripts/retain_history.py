#!/usr/bin/env python3
"""Retain verified legacy relationships whose peers are unavailable/out of scope.

Only local SQLite is changed. No remote fields, creation, trash or cancellation
is performed. A missing peer stays unknown, not deleted. Reviewed unavailable
history is periodically rechecked by the daemon without retrying every poll.
"""
import argparse
from collections import Counter
from dataclasses import replace
import json
import os
from pathlib import Path

from notion_calendar_sync.config import load_config
from notion_calendar_sync.history import calendar_url_identity, legacy_identity, plain
from notion_calendar_sync.http import AccessError
from notion_calendar_sync.providers import NotionProvider, GoogleProvider
from notion_calendar_sync.service import StateLock
from notion_calendar_sync.store import Store
from resolve_backed_up import append_private


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config', required=True)
    ap.add_argument('--lookups', required=True, type=Path)
    ap.add_argument('--directory', required=True, type=Path)
    ap.add_argument('--apply', action='store_true')
    args = ap.parse_args(); c = load_config(args.config); m = c.mappings[0]
    n, g = NotionProvider(c), GoogleProvider(c)
    os.umask(0o077); args.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    counts = Counter()
    with StateLock(c.state_path), Store(c.state_path) as s:
        n.validate(m); g.validate(m)
        source = replace(m, notion_select_property='', notion_select_value='')
        pages = n.scan(source, full=True).records
        # Include the referenced pages that have positively returned in_trash.
        seen = {r.id for r in pages}
        for row in json.loads(args.lookups.read_text())['notion_lookups']:
            if row['notion_id'] not in seen:
                pages.append(n.get(m, row['notion_id']))
        if args.apply and not (args.directory / 'before.sqlite3').exists():
            s.backup(args.directory / 'before.sqlite3')
        for record in pages:
            props = record.raw.get('properties', {})
            old = legacy_identity(plain(props.get('Notion Automations Events Data', {})), m.google_calendar, page_id=record.id)
            url = calendar_url_identity(props.get(m.properties.get('google_url', ''), {}).get('url') or '')
            ids = {old[1]} if old else set()
            if url and url[0] == m.google_calendar:
                ids.add(url[1])
            if len(ids) != 1:
                continue
            gid = next(iter(ids))
            rows = list(s.db.execute('SELECT * FROM links WHERE mapping=? AND (notion_id=? OR google_id=?)', (m.name, record.id, gid)))
            if rows:
                counts['already_owned'] += 1
                continue
            nr = n.get(m, record.id)
            try:
                gr = g.get(m, gid)
            except AccessError as exc:
                if nr.raw.get('ncs_out_of_scope'):
                    counts['outside_scope_without_accessible_peer'] += 1
                    continue
                gr = None; status = 'historical-unavailable'; http_status = exc.status
            else:
                http_status = None
                if nr.eligible and not nr.deleted and not gr.deleted and gr.eligible:
                    raise RuntimeError('An unexpected accessible pair needs ordinary verified linking first')
                if not nr.raw.get('ncs_out_of_scope') and nr.deleted:
                    raise RuntimeError('A proven in-scope deletion must use the backed-up retirement tool')
                status = 'paused'
            append_private(args.directory / 'originals.jsonl', {
                'notion_id': nr.id, 'google_id': gid, 'status': status, 'http_status': http_status,
                'notion': json.loads(nr.to_json()), 'google': json.loads(gr.to_json()) if gr else None})
            if args.apply:
                with s.db:
                    s.db.execute('INSERT INTO links(mapping,notion_id,google_id,status) VALUES(?,?,?,?)',
                                 (m.name, nr.id, gid, status))
                    s.put_record(m.name, 'notion', nr)
                    if gr:
                        s.put_record(m.name, 'google', gr)
            counts[status] += 1
        result = {'applied': args.apply, 'counts': dict(counts), 'remote_writes': 0,
                  'directory': str(args.directory)}
        (args.directory / 'summary.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
