#!/usr/bin/env python3
"""Run real API checks using only newly created, uniquely named test items.

The engine's scans are bounded to IDs created by this run. Existing appointments
are never imported or modified. Run with the daemon stopped and --apply.
"""
import argparse,json,uuid,time,os
from pathlib import Path
from dataclasses import replace
from notion_calendar_sync.config import load_config
from notion_calendar_sync.providers import NotionProvider,GoogleProvider,Scan
from notion_calendar_sync.model import normalize_time
from notion_calendar_sync.http import AccessError
from notion_calendar_sync.store import Store
from notion_calendar_sync.engine import Engine
from notion_calendar_sync.service import StateLock

class Isolated:
    def __init__(self,provider): self.provider=provider;self.ids=set();self.last={};self.writes=[]
    def validate(self,m): return self.provider.validate(m)
    def get(self,m,id):
        try:r=self.provider.get(m,id)
        except AccessError as e:
            if e.status==410 and id in self.last and self.last[id].deleted:return self.last[id]
            raise
        self.last[id]=r;return r
    def scan(self,m,cursor=None,full=False):return Scan([self.get(m,id) for id in self.ids],None)
    def write(self,method,m,*args,**kwargs):
        r=getattr(self.provider,method)(m,*args,**kwargs);self.ids.add(r.id);self.last[r.id]=r;self.writes.append((method,r.id));return r
    def create(self,*a,**kw):return self.write('create',*a,**kw)
    def update(self,*a,**kw):return self.write('update',*a,**kw)
    def archive(self,*a,**kw):return self.write('archive',*a,**kw)
    def set_links(self,*a,**kw):return self.write('set_links',*a,**kw)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--config',required=True);ap.add_argument('--apply',action='store_true',required=True)
    args=ap.parse_args();c=load_config(args.config);m=replace(c.mappings[0],name='smoke-'+uuid.uuid4().hex[:10],import_since='')
    prefix='NCS-SMOKE-'+uuid.uuid4().hex[:12];path=c.state_path.parent/(m.name+'.sqlite3');c=replace(c,state_path=path,mappings=[m])
    n,g=Isolated(NotionProvider(c)),Isolated(GoogleProvider(c));checks=[];started=time.monotonic();report={'prefix':prefix,'checks':checks,'provider_calls_are_live':True,'batch_processing_seconds':[]}
    def check(name,condition):
        if not condition:raise AssertionError(name)
        checks.append(name)
    with StateLock(load_config(args.config).state_path),Store(path) as state:
        e=Engine(c,state,n,g)
        def sync():
            tick=time.monotonic();r=e.sync();report['batch_processing_seconds'].append(round(time.monotonic()-tick,3))
            check('batch-no-provider-errors',not any(x.get('error') or x['action'] in ('replan','retry','ambiguous','pending') for x in r))
            return r
        v={'title':prefix+' N-to-G','time':normalize_time('2035-01-15T10:00:00-07:00','2035-01-15T11:00:00-07:00',m.timezone),'description':'Disposable sync acceptance test','location':'Test location','recurrence':[]}
        try:
            props=n.provider._properties(m,v)
            if m.notion_select_property:props[m.notion_select_property]={'select':{'name':m.notion_select_value}}
            page=n.provider._request('POST','/pages',body={'parent':{'type':'data_source_id','data_source_id':m.notion_data_source},'properties':props},safe=False)
            nid=page['id'];n.ids.add(nid);sync();row=state.db.execute('SELECT * FROM links WHERE notion_id=?',(nid,)).fetchone();gid=row['google_id']
            check('notion-create-linked-once',bool(gid) and len(g.ids)==1)
            n.update(m,nid,{'title':prefix+' N edited'});sync();check('notion-title-same-google-id',g.get(m,gid).values['title']==prefix+' N edited')
            g.update(m,gid,{'description':'Google <b>source</b>','location':'Google room'});sync();check('google-notes-location-same-notion-id',n.get(m,nid).values['description']=='Google <b>source</b>' and n.get(m,nid).values['location']=='Google room')
            day=normalize_time('2035-01-20','2035-01-23',m.timezone);g.update(m,gid,{'time':day});sync();nr=n.get(m,nid);check('inclusive-exclusive-all-day-roundtrip',nr.values['time']==day and nr.raw['properties'][m.properties['date']]['date']['end']=='2035-01-22')
            timed=normalize_time('2035-03-11T01:30:00-07:00','2035-03-11T03:30:00-06:00',m.timezone);g.update(m,gid,{'time':timed});sync();check('all-day-to-timed-and-DST-instants',n.get(m,nid).values['time']==timed)
            n.update(m,nid,{'title':prefix+' N conflict'});g.update(m,gid,{'title':prefix+' G conflict'});sync();conflict=state.db.execute("SELECT id FROM conflicts WHERE status='open'").fetchone();check('conflict-preserves-both-versions',bool(conflict) and n.get(m,nid).values['title']!=g.get(m,gid).values['title'])
            e.resolve(conflict['id'],'notion');check('manual-resolution-same-identities',g.get(m,gid).values['title']==prefix+' N conflict')
            before=len(n.writes)+len(g.writes);sync();sync();check('unchanged-reconciliation-zero-writes',before==len(n.writes)+len(g.writes))
            n.archive(m,nid);sync();check('notion-trash-cancels-exact-google-event',g.get(m,gid).deleted)
            second=dict(v,title=prefix+' G-to-N');event=g.create(m,second,uuid.uuid4().hex,'');sync();row=state.db.execute('SELECT * FROM links WHERE google_id=?',(event.id,)).fetchone();nid2=row['notion_id'];check('google-create-linked-once',bool(nid2) and n.get(m,nid2).raw['properties'][m.notion_select_property]['select']['name']==m.notion_select_value)
            g.update(m,event.id,{'title':prefix+' G edited'});sync();check('google-title-same-notion-id',n.get(m,nid2).values['title']==prefix+' G edited')
            g.archive(m,event.id);sync();check('google-cancel-trashes-exact-notion-page',n.get(m,nid2).deleted)
            sync();check('tombstones-prevent-recreation',state.db.execute("SELECT COUNT(*) FROM links WHERE status='deleted'").fetchone()[0]==2 and len(n.ids)==2 and len(g.ids)==2)
            report['passed']=True;report['logical_pairs']=[{'notion':nid,'google':gid},{'notion':nid2,'google':event.id}]
        finally:
            for provider in (n,g):
                for id in provider.ids:
                    try:
                        r=provider.get(m,id)
                        if not r.deleted:provider.archive(m,id,r.version)
                    except Exception:pass
            report['elapsed_seconds']=round(time.monotonic()-started,3)
            out=c.state_path.parent/'live-smoke-report.json';temporary=out.with_suffix('.tmp')
            fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
            with os.fdopen(fd,'w') as stream:json.dump(report,stream,indent=2)
            os.replace(temporary,out)
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
