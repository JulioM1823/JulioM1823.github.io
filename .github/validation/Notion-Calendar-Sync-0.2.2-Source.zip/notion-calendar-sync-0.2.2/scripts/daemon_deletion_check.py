#!/usr/bin/env python3
"""Check two-way deletion through the existing worker using disposable items only.

Run as ncs with its protected environment, with the daemon running. This driver
never runs a second sync engine or modifies existing appointments. It saves
private originals before deleting its own test items and watches two later
successful polling passes for resurrection or additional per-item writes.
"""
import argparse
from contextlib import closing
import json
import os
from pathlib import Path
import sqlite3
import time
import uuid

from notion_calendar_sync.config import load_config
from notion_calendar_sync.http import AccessError
from notion_calendar_sync.model import normalize_time
from notion_calendar_sync.providers import GoogleProvider, NotionProvider


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config', required=True)
    ap.add_argument('--directory', type=Path, required=True)
    ap.add_argument('--apply', action='store_true', required=True)
    ap.add_argument('--timeout', type=float, default=240)
    args = ap.parse_args()
    os.umask(0o077)
    args.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    c = load_config(args.config)
    m = c.mappings[0]
    n, g = NotionProvider(c), GoogleProvider(c)
    prefix = 'NCS-DELETE-' + uuid.uuid4().hex[:12]
    report = {'prefix': prefix, 'mode': 'running systemd worker; real configured polling',
              'poll_seconds': m.poll_seconds, 'pairs': [], 'checks': [], 'passed': False}
    known = {'notion': set(), 'google': set()}
    google_operation = uuid.uuid4().hex

    def save():
        target = args.directory / 'report.json'
        temporary = target.with_suffix('.tmp')
        with temporary.open('w') as stream:
            json.dump(report, stream, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(target)

    def read(query):
        with closing(sqlite3.connect('file:' + str(c.state_path) + '?mode=ro', uri=True)) as db:
            db.row_factory = sqlite3.Row
            return query(db)

    def wait(name, query, timeout=None):
        start = time.monotonic()
        while time.monotonic() - start < (timeout or args.timeout):
            result = read(query)
            if result:
                report['checks'].append({'name': name, 'seconds_from_source_ack_or_wait_start': round(time.monotonic()-start, 3)})
                save()
                print(name + ' passed', flush=True)
                return result
            time.sleep(.5)
        raise TimeoutError(name)

    def linked(db, column, id):
        row = db.execute('SELECT * FROM links WHERE mapping=? AND '+column+'=? AND status=\'active\'', (m.name, id)).fetchone()
        return dict(row) if row and row['notion_id'] and row['google_id'] and json.loads(row['base']) else None

    def operation_count(db):
        return db.execute('SELECT count(*) FROM operations WHERE link_id IN (?,?)', tuple(p['link_id'] for p in report['pairs'])).fetchone()[0]

    def verify_deleted(pair):
        assert n.get(m, pair['notion_id']).deleted, 'Notion page is not in Trash'
        try:
            assert g.get(m, pair['google_id']).deleted, 'Google event is not cancelled'
        except AccessError as exc:
            # A 410 alone is not evidence. Require the worker's positive
            # cancelled event observation as well as its durable tombstone.
            def explicit(db):
                row = db.execute("SELECT record FROM observations WHERE mapping=? AND side='google' AND item_id=?", (m.name, pair['google_id'])).fetchone()
                return row and json.loads(row[0])['deleted']
            assert exc.status == 410 and read(explicit)

    save()
    report['google_operation_id'] = google_operation
    save()
    try:
        values = {'title': prefix+' Notion source',
                  'time': normalize_time('2036-01-15T10:00:00-07:00', '2036-01-15T11:00:00-07:00', m.timezone),
                  'description': 'Disposable two-way deletion verification', 'location': '', 'recurrence': []}
        props = n._properties(m, values)
        if m.notion_select_property:
            props[m.notion_select_property] = {'select': {'name': m.notion_select_value}}
        if m.properties.get('sync_enabled'):
            props.update(n._properties(m, {'sync_enabled': True}))
        nid = n._request('POST', '/pages', body={'parent': {'type': 'data_source_id', 'data_source_id': m.notion_data_source}, 'properties': props}, safe=False)['id']
        known['notion'].add(nid)
        report['created_notion_id'] = nid
        save()
        # Deterministic Google create identity is known even after a lost response.
        known['google'].add(g.event_id(google_operation))
        event = g.create(m, dict(values, title=prefix+' Google source'), google_operation, '')
        report['created_google_id'] = event.id
        save()
        first = wait('Notion source linked to exactly one Google event', lambda db: linked(db, 'notion_id', nid))
        second = wait('Google source linked to exactly one Notion page', lambda db: linked(db, 'google_id', event.id))
        assert first['id'] != second['id']
        for direction, row in [('Notion to Google', first), ('Google to Notion', second)]:
            known['notion'].add(row['notion_id'])
            known['google'].add(row['google_id'])
            nr, gr = n.get(m, row['notion_id']), g.get(m, row['google_id'])
            assert nr.values['title'].startswith(prefix) and gr.values['title'].startswith(prefix)
            assert all(nr.values.get(k) == gr.values.get(k) for k in m.mapped_fields)
            report['pairs'].append({'direction': direction, 'link_id': row['id'], 'notion_id': nr.id, 'google_id': gr.id})
            with (args.directory/'originals.jsonl').open('a') as f:
                f.write(json.dumps({'notion': json.loads(nr.to_json()), 'google': json.loads(gr.to_json())})+'\n')
                f.flush()
                os.fsync(f.fileno())
            save()
        n.archive(m, first['notion_id'])
        wait('Notion Trash propagated to Google cancellation', lambda db: db.execute("SELECT 1 FROM links WHERE id=? AND status='deleted'", (first['id'],)).fetchone())
        verify_deleted(report['pairs'][0])
        g.archive(m, second['google_id'])
        wait('Google deletion propagated to Notion Trash', lambda db: db.execute("SELECT 1 FROM links WHERE id=? AND status='deleted'", (second['id'],)).fetchone())
        verify_deleted(report['pairs'][1])
        count = read(operation_count)
        # Detect successful new worker batches using its durable diagnostic.
        for i in range(2):
            key = 'last_success:' + m.name
            previous = read(lambda db: (db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone() or ['null'])[0])
            wait('Later successful poll '+str(i+1)+' retains deletions', lambda db: (db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone() or [previous])[0] != previous,
                 timeout=max(args.timeout, m.poll_seconds+60))
            assert read(operation_count) == count, 'Unexpected additional operations for deleted items'
            for pair in report['pairs']:
                assert read(lambda db: db.execute("SELECT 1 FROM links WHERE id=? AND notion_id=? AND google_id=? AND status='deleted'", (pair['link_id'], pair['notion_id'], pair['google_id'])).fetchone())
                verify_deleted(pair)
        # Full read-only listings also check for live copies with the unique prefix.
        for provider in (n, g):
            assert not [r.id for r in provider.scan(m, full=True).records if not r.deleted and r.values.get('title', '').startswith(prefix)], 'Live test copy remains'
        assert len(known['notion']) == len(known['google']) == 2
        report['duplicate_live_test_items'] = 0
        report['resurrected_items'] = 0
        report['additional_test_operations_after_deletion'] = read(operation_count) - count
        report['passed'] = True
        save()
    finally:
        cleanup = []
        for side, provider in [('notion', n), ('google', g)]:
            for id in known[side]:
                try:
                    r = provider.get(m, id)
                    if not r.deleted:
                        assert r.values.get('title', '').startswith(prefix)
                        provider.archive(m, id, r.version)
                except AccessError as exc:
                    if exc.status != 410:
                        cleanup.append({'side': side, 'id': id, 'error': type(exc).__name__})
                except Exception as exc:
                    cleanup.append({'side': side, 'id': id, 'error': type(exc).__name__})
        report['cleanup_errors'] = cleanup
        if cleanup:
            report['passed'] = False
        save()
    print(json.dumps(report, indent=2))
    if not report['passed']:
        raise RuntimeError('Deletion verification did not pass')


if __name__ == '__main__':
    main()
