#!/usr/bin/env python3
"""Resolve currently open migration conflicts, retaining every original version.

This is an explicit administrative action, not the daemon's future policy.
Calendar values win, except a newer Notion Morales_2025 project rename wins
over the otherwise identical Morales_2024 title. Existing metadata writes do
not establish field-level recency, so coarse page timestamps are not compared.
The default only previews decisions. --apply requires the daemon to be stopped.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import time

from notion_calendar_sync.config import load_config
from notion_calendar_sync.engine import Engine
from notion_calendar_sync.providers import NotionProvider, GoogleProvider
from notion_calendar_sync.service import StateLock
from notion_calendar_sync.store import Store


def choice(notion, google):
    n, g = notion.values.get('title', ''), google.values.get('title', '')
    if ('Morales_2025' in n and 'Morales_2024' in g and
            n == g.replace('Morales_2024', 'Morales_2025')):
        return 'notion', 'retain-the-newer-project-name'
    return 'google', 'retain-calendar-schedule-and-richer-migration-fields'


def append_private(path, value):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    with os.fdopen(fd, 'a') as stream:
        stream.write(json.dumps(value, sort_keys=True) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config', required=True)
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--directory', type=Path)
    args = ap.parse_args()
    c = load_config(args.config)
    n, g = NotionProvider(c), GoogleProvider(c)
    os.umask(0o077)
    directory = args.directory or c.state_path.parent / ('conflict-repair-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    counts = Counter()
    with StateLock(c.state_path), Store(c.state_path) as s:
        if args.apply and not (directory / 'before.sqlite3').exists():
            s.backup(directory / 'before.sqlite3')
        engine = Engine(c, s, n, g)
        rows = list(s.db.execute("SELECT * FROM conflicts WHERE status='open' ORDER BY id"))
        for row in rows:
            m = next(m for m in c.mappings if m.name == row['mapping'])
            link = s.db.execute('SELECT * FROM links WHERE id=?', (row['link_id'],)).fetchone()
            nr, gr = n.get(m, link['notion_id']), g.get(m, link['google_id'])
            preferred, rule = choice(nr, gr)
            decision = {'conflict_id': row['id'], 'link_id': link['id'], 'prefer': preferred,
                        'rule': rule, 'time': time.time(), 'notion': json.loads(nr.to_json()),
                        'google': json.loads(gr.to_json())}
            append_private(directory / 'originals.jsonl', decision)
            counts['prefer_' + preferred] += 1
            if not args.apply:
                continue
            # Refresh the conflict snapshot if provider values changed during
            # review. Every new version is backed up before trying again.
            for attempt in range(3):
                current = s.db.execute("SELECT id FROM conflicts WHERE link_id=? AND status='open' ORDER BY id DESC LIMIT 1", (link['id'],)).fetchone()
                if not current:
                    break
                try:
                    report = engine.resolve(current['id'], preferred)
                except ValueError as exc:
                    if 'Item changed after conflict' not in str(exc):
                        raise
                    nr, gr = n.get(m, link['notion_id']), g.get(m, link['google_id'])
                    preferred, rule = choice(nr, gr)
                    append_private(directory / 'originals.jsonl', dict(decision, attempt=attempt + 1,
                                   notion=json.loads(nr.to_json()), google=json.loads(gr.to_json()),
                                   prefer=preferred, rule=rule, time=time.time()))
                    continue
                if any(x.get('error') or x['action'] in ('pending', 'replan', 'retry', 'ambiguous') for x in report):
                    raise RuntimeError('Resolution deferred; durable journal and originals are preserved')
                append_private(directory / 'completed.jsonl', {'link_id': link['id'], 'conflict_id': current['id'], 'prefer': preferred})
                break
            else:
                raise RuntimeError('Item kept changing during resolution; originals retained')
            counts['resolved'] += 1
            if counts['resolved'] % 10 == 0:
                print(json.dumps({'progress': dict(counts)}), flush=True)
        counts['remaining_open'] = s.db.execute("SELECT COUNT(*) FROM conflicts WHERE status='open'").fetchone()[0]
        result = {'applied': args.apply, 'directory': str(directory), 'counts': dict(counts)}
        (directory / 'summary.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
