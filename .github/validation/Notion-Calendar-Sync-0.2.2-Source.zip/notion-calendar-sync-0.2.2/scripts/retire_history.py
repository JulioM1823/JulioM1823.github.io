#!/usr/bin/env python3
"""Propagate proven historical Notion trash to its exact Calendar counterpart.

Only explicit in_trash plus matching legacy page/event/calendar IDs qualify.
Missing access, attendee events, recurring series, and other scopes never do.
Every original is fsynced to a private audit before a reversible cancellation.
Run with the daemon stopped. The default is a preview; --apply changes events.
"""
import argparse
from collections import Counter
import json
import os
from pathlib import Path

from notion_calendar_sync.config import load_config
from notion_calendar_sync.engine import Engine
from notion_calendar_sync.history import historical_trash_evidence
from notion_calendar_sync.providers import NotionProvider, GoogleProvider
from notion_calendar_sync.service import StateLock
from notion_calendar_sync.store import Store
from resolve_backed_up import append_private


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config', required=True)
    ap.add_argument('--lookups', required=True, type=Path)
    ap.add_argument('--directory', required=True, type=Path)
    ap.add_argument('--apply', action='store_true')
    args = ap.parse_args()
    c = load_config(args.config); m = c.mappings[0]
    n, g = NotionProvider(c), GoogleProvider(c)
    os.umask(0o077)
    args.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    counts = Counter()
    with StateLock(c.state_path), Store(c.state_path) as s:
        if args.apply and not (args.directory / 'before.sqlite3').exists():
            s.backup(args.directory / 'before.sqlite3')
        engine = Engine(c, s, n, g)
        for item in json.loads(args.lookups.read_text())['notion_lookups']:
            nid, gid = item['notion_id'], item['google_id']
            occupied = list(s.db.execute('SELECT * FROM links WHERE mapping=? AND (notion_id=? OR google_id=?)', (m.name, nid, gid)))
            if occupied and (len(occupied) != 1 or occupied[0]['notion_id'] != nid or occupied[0]['google_id'] != gid):
                raise ValueError('Historical identity is already owned by a different pair')
            if occupied and occupied[0]['status'] == 'deleted':
                counts['already_retired'] += 1
                continue
            if occupied:
                # Replay only the durable archive intent for this exact pair.
                for op in list(s.db.execute("SELECT * FROM operations WHERE link_id=? AND action='archive' AND status IN ('pending','inflight','retry','ambiguous')", (occupied[0]['id'],))):
                    engine._execute(m, op)
                row = s.db.execute('SELECT status FROM links WHERE id=?', (occupied[0]['id'],)).fetchone()
                if row['status'] == 'deleted':
                    engine._tombstone(occupied[0]['id'], m)
                    counts['recovered_retirement'] += 1
                    continue
            nr, gr = n.get(m, nid), g.get(m, gid)
            if not historical_trash_evidence(m, nr, gr):
                counts['preserved_outside_strict_trash_policy'] += 1
                continue
            append_private(args.directory / 'originals.jsonl', {
                'notion_id': nid, 'google_id': gid, 'notion': json.loads(nr.to_json()),
                'google': json.loads(gr.to_json()), 'policy': 'propagate-positively-verified-Notion-trash'})
            if not args.apply:
                counts['would_cancel'] += 1
                continue
            with s.db:
                if occupied:
                    link_id = occupied[0]['id']
                else:
                    link_id = s.db.execute('INSERT INTO links(mapping,notion_id,google_id) VALUES(?,?,?)', (m.name, nid, gid)).lastrowid
                s.put_record(m.name, 'notion', nr); s.put_record(m.name, 'google', gr)
            # Unknown common history remains a conflict until the explicit
            # deletion policy resolves it, preserving both snapshots in SQLite.
            engine._process_safe(m, link_id)
            conflict = s.db.execute("SELECT id FROM conflicts WHERE link_id=? AND status='open' ORDER BY id DESC LIMIT 1", (link_id,)).fetchone()
            if conflict:
                result = engine.resolve(conflict['id'], 'notion')
                if any(r.get('error') or r['action'] in ('retry', 'pending', 'replan', 'ambiguous') for r in result):
                    raise RuntimeError('Cancellation deferred; backup and journal retained')
            row = s.db.execute('SELECT status FROM links WHERE id=?', (link_id,)).fetchone()
            if row['status'] != 'deleted':
                raise RuntimeError('Expected a completed cancellation tombstone')
            append_private(args.directory / 'completed.jsonl', {'notion_id': nid, 'google_id': gid, 'link_id': link_id})
            counts['linked_and_cancelled'] += 1
            if counts['linked_and_cancelled'] % 10 == 0:
                print(json.dumps({'progress': dict(counts)}), flush=True)
        result = {'applied': args.apply, 'counts': dict(counts), 'remote_creates': 0,
                  'remaining_open': s.db.execute("SELECT COUNT(*) FROM conflicts WHERE status='open'").fetchone()[0],
                  'directory': str(args.directory)}
        (args.directory / 'summary.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
