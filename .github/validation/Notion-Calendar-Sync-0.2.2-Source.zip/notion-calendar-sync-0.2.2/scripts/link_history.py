#!/usr/bin/env python3
"""Apply an explicit historical-pair plan after fresh global uniqueness checks.

This tool never creates or deletes a remote item. All originals and a consistent
SQLite backup are retained. Address-only whitespace differences are resolved
using Calendar's formatting after linking; other changes fail closed.
"""
import argparse
from collections import Counter
from dataclasses import replace
import json
import os
from pathlib import Path

from notion_calendar_sync.config import load_config
from notion_calendar_sync.engine import Engine
from notion_calendar_sync.history import fingerprint, newer_notion_reschedule, plan_pairs, uuid_key
from notion_calendar_sync.providers import NotionProvider, GoogleProvider
from notion_calendar_sync.service import StateLock
from notion_calendar_sync.store import Store
from resolve_backed_up import append_private


class NoCreatesOrDeletes:
    def __init__(self, provider):
        self.provider = provider

    def __getattr__(self, name):
        return getattr(self.provider, name)

    def create(self, *args, **kwargs):
        raise RuntimeError('Historical linking cannot create remote items')

    def archive(self, *args, **kwargs):
        raise RuntimeError('Historical linking cannot delete remote items')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config', required=True)
    ap.add_argument('--plan', required=True, type=Path)
    ap.add_argument('--directory', required=True, type=Path)
    ap.add_argument('--apply', action='store_true')
    args = ap.parse_args()
    c = load_config(args.config)
    plan = json.loads(args.plan.read_text())
    m = next(m for m in c.mappings if m.name == plan['mapping'])
    n, g = NotionProvider(c), GoogleProvider(c)
    os.umask(0o077)
    directory = args.directory
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    counts = Counter()
    with StateLock(c.state_path), Store(c.state_path) as s:
        n.validate(m); g.validate(m)
        source = replace(m, notion_select_property='', notion_select_value='')
        full_n, full_g = n.scan(source, full=True), g.scan(m, full=True)
        ns = [n._record(m, r.raw) for r in full_n.records]
        other = [r for r in ns if r.raw.get('ncs_out_of_scope')]
        ns = [r for r in ns if not r.raw.get('ncs_out_of_scope')]
        existing = list(s.db.execute('SELECT * FROM links WHERE mapping=?', (m.name,)))
        proposed, rejected = plan_pairs(m, ns, full_g.records,
                                       [r['notion_id'] for r in existing],
                                       [r['google_id'] for r in existing], other)
        allowed = {(uuid_key(p['notion_id']), p['google_id']) for p in proposed}
        completed = {(uuid_key(r['notion_id']), r['google_id']) for r in existing}
        requested = [(uuid_key(p['notion_id']), p['google_id']) for p in plan['pairs']]
        if len(set(requested)) != len(requested):
            raise ValueError('Plan repeats an existing pair')
        if len({p[0] for p in requested}) != len(requested) or len({p[1] for p in requested}) != len(requested):
            raise ValueError('Plan must be one-to-one')
        if any(pair not in allowed and pair not in completed for pair in requested):
            raise ValueError('A proposed pair no longer passes current identity/uniqueness checks')
        if args.apply and not (directory / 'before.sqlite3').exists():
            s.backup(directory / 'before.sqlite3')
        append_private(directory / 'snapshots.jsonl', {
            'notion': [json.loads(r.to_json()) for r in full_n.records],
            'google': [json.loads(r.to_json()) for r in full_g.records]})
        engine = Engine(c, s, NoCreatesOrDeletes(n), NoCreatesOrDeletes(g))
        for p in plan['pairs']:
            key = (uuid_key(p['notion_id']), p['google_id'])
            if key in completed:
                counts['already_linked'] += 1
                continue
            nr, gr = n.get(m, p['notion_id']), g.get(m, p['google_id'])
            rescheduled = p['evidence'] == 'unique-content-near-creation-newer-notion-date' and newer_notion_reschedule(nr, gr)
            if not nr.eligible or not gr.eligible or nr.deleted or gr.deleted or (fingerprint(nr) != fingerprint(gr) and not rescheduled):
                raise ValueError('A pair changed or became ineligible after planning')
            append_private(directory / 'originals.jsonl', dict(p, notion=json.loads(nr.to_json()), google=json.loads(gr.to_json())))
            if not args.apply:
                counts['would_link'] += 1
                continue
            report = engine.link(m.name, nr.id, gr.id, dry_run=False)
            if any(x.get('error') for x in report):
                raise RuntimeError('Link operation deferred; originals and journal are retained')
            link = s.db.execute('SELECT * FROM links WHERE mapping=? AND notion_id=?', (m.name, nr.id)).fetchone()
            conflict = s.db.execute("SELECT id FROM conflicts WHERE link_id=? AND status='open' ORDER BY id DESC LIMIT 1", (link['id'],)).fetchone()
            if conflict:
                report = engine.resolve(conflict['id'], 'notion' if rescheduled else 'google')
                if any(x.get('error') or x['action'] in ('pending', 'replan', 'retry', 'ambiguous') for x in report):
                    raise RuntimeError('Whitespace normalization deferred; originals and journal are retained')
                counts['reschedule_preserved' if rescheduled else 'address_whitespace_normalized'] += 1
            nr2, gr2 = n.get(m, nr.id), g.get(m, gr.id)
            if nr2.values != gr2.values or nr2.deleted or gr2.deleted:
                raise RuntimeError('Post-link verification failed')
            append_private(directory / 'completed.jsonl', dict(p, link_id=link['id']))
            counts['linked_and_verified'] += 1
            if counts['linked_and_verified'] % 10 == 0:
                print(json.dumps({'progress': dict(counts)}), flush=True)
        result = {'applied': args.apply, 'counts': dict(counts), 'remote_creates': 0,
                  'remote_deletes': 0, 'directory': str(directory),
                  'remaining_open': s.db.execute("SELECT COUNT(*) FROM conflicts WHERE status='open'").fetchone()[0]}
        (directory / 'summary.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
