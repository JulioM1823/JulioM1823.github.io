#!/usr/bin/env python3
"""Import reviewed Calendar-only history without changing Calendar event fields.

Default: fresh full-database audit and private plan. --apply uses the durable
engine create journal, the required Google-ID marker, and source verification.
Calendar creates/deletes/field edits are forbidden; only link metadata may change.
The service must be stopped. Each series master is one row, without expansion.
"""
import argparse
from collections import Counter
from dataclasses import replace
import json
import os
from pathlib import Path
import time

from notion_calendar_sync.config import load_config
from notion_calendar_sync.engine import Engine
from notion_calendar_sync.history import importable_history
from notion_calendar_sync.model import Record
from notion_calendar_sync.providers import NotionProvider, GoogleProvider
from notion_calendar_sync.service import StateLock
from notion_calendar_sync.store import Store
from resolve_backed_up import append_private


class CalendarMetadataOnly:
    def __init__(self, provider):
        self.provider = provider

    def __getattr__(self, key):
        return getattr(self.provider, key)

    def create(self, *a, **kw):
        raise RuntimeError('Historical import cannot create Calendar events')

    def archive(self, *a, **kw):
        raise RuntimeError('Historical import cannot delete Calendar events')

    def update(self, *a, **kw):
        raise RuntimeError('Historical import cannot change Calendar mapped fields')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config', required=True)
    ap.add_argument('--directory', required=True, type=Path)
    ap.add_argument('--lookups', required=True, type=Path)
    ap.add_argument('--apply', action='store_true')
    args = ap.parse_args()
    c = load_config(args.config); m = c.mappings[0]
    n, g = NotionProvider(c), GoogleProvider(c)
    os.umask(0o077)
    args.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    counts = Counter(); started = time.monotonic()
    with StateLock(c.state_path), Store(c.state_path) as s:
        n.validate(m); g.validate(m)
        manifest = args.directory / 'plan.json'
        if manifest.exists() and args.apply:
            plan = json.loads(manifest.read_text())
        else:
            source = replace(m, notion_select_property='', notion_select_value='')
            ns, gs = n.scan(source, full=True), g.scan(m, full=True)
            trashed = [Record(**row['record']) for row in json.loads(args.lookups.read_text())['notion_lookups'] if 'record' in row]
            occupied = [r[0] for r in s.db.execute('SELECT google_id FROM links WHERE mapping=?', (m.name,))]
            pairs, held = importable_history(m, [*ns.records, *trashed], gs.records, occupied)
            # Masters first; explicit exceptions remain separate supported rows.
            source_records = {r.id: r for r in gs.records}
            pairs.sort(key=lambda row: (bool(source_records[row['google_id']].raw.get('recurringEventId')), row['google_id']))
            plan = {'mapping': m.name, 'proposals': pairs, 'held': held}
            manifest.write_text(json.dumps(plan, indent=2))
            append_private(args.directory / 'snapshots.jsonl', {'notion': [json.loads(r.to_json()) for r in ns.records],
                           'google': [json.loads(r.to_json()) for r in gs.records]})
        if not args.apply:
            print(json.dumps({'applied': False, 'proposed_notion_creates': len(plan['proposals']),
                              'held': plan['held'], 'directory': str(args.directory)}, indent=2))
            return
        if plan['mapping'] != m.name or len({p['google_id'] for p in plan['proposals']}) != len(plan['proposals']):
            raise ValueError('Invalid or repeated import identities')
        if not (args.directory / 'before.sqlite3').exists():
            s.backup(args.directory / 'before.sqlite3')
        engine = Engine(c, s, n, CalendarMetadataOnly(g))
        for p in plan['proposals']:
            gid = p['google_id']
            link = s.db.execute('SELECT * FROM links WHERE mapping=? AND google_id=?', (m.name, gid)).fetchone()
            if link and link['notion_id'] and link['status'] == 'active':
                counts['already_linked'] += 1
                continue
            current = g.get(m, gid)
            if current.deleted or not current.eligible:
                counts['preserved_changed_or_ineligible_source'] += 1
                continue
            append_private(args.directory / 'originals.jsonl', {'google_id': gid, 'google': json.loads(current.to_json())})
            if not link:
                with s.db:
                    lid = s.db.execute("INSERT INTO links(mapping,google_id,status,kind) VALUES(?,?,'linking',?)",
                                       (m.name, gid, engine._kind(current))).lastrowid
                    s.put_record(m.name, 'google', current)
                values = {k: current.values.get(k) for k in m.mapped_fields}
                # Save the Google URL at creation to avoid a needless later
                # Notion metadata PATCH. It is not part of the common base.
                create_values = dict(values)
                if m.properties.get('google_url'):
                    create_values['google_url'] = current.url
                op = engine._enqueue(m, lid, 'notion', 'create', {'values': create_values,
                    'source_side': 'google', 'source_id': gid, 'source_expected': values})
                engine._execute(m, op)
            else:
                lid = link['id']
                for op in list(s.db.execute("SELECT * FROM operations WHERE link_id=? AND status IN ('pending','inflight','retry','ambiguous') ORDER BY created", (lid,))):
                    engine._execute(m, op)
            engine._process_safe(m, lid)
            link = s.db.execute('SELECT * FROM links WHERE id=?', (lid,)).fetchone()
            if not link['notion_id'] or link['status'] != 'active':
                raise RuntimeError('Import deferred; its stable operation and original are retained for safe resumption')
            nr, gr = n.get(m, link['notion_id']), g.get(m, gid)
            if ({k: nr.values.get(k) for k in m.mapped_fields} != {k: gr.values.get(k) for k in m.mapped_fields} or
                nr.raw.get('ncs_peer_id') != gid or gr.raw.get('ncs_peer_id') != nr.id):
                raise RuntimeError('Import verification failed; originals and journal retained')
            append_private(args.directory / 'completed.jsonl', {'notion_id': nr.id, 'google_id': gid, 'link_id': lid})
            counts['created_and_verified'] += 1
            if counts['created_and_verified'] % 10 == 0:
                print(json.dumps({'progress': dict(counts), 'elapsed_seconds': round(time.monotonic() - started, 1)}), flush=True)
        result = {'applied': True, 'counts': dict(counts), 'held': plan['held'],
                  'remote_calendar_creates': 0, 'remote_calendar_deletes': 0,
                  'remaining_open': s.db.execute("SELECT COUNT(*) FROM conflicts WHERE status='open'").fetchone()[0],
                  'elapsed_seconds': round(time.monotonic() - started, 3), 'directory': str(args.directory)}
        (args.directory / 'summary.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
