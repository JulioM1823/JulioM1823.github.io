#!/usr/bin/env python3
"""Verify the running daemon using one disposable linked item; no worker is started.

Requires an already configured/running daemon and explicit --apply. The daemon
continues normal configured synchronization; only this script's new test pair
is edited and cleaned up by the driver. Run as the service user with its env.
"""
import argparse,os,json,time,uuid,sqlite3
from contextlib import closing
from pathlib import Path
from notion_calendar_sync.config import load_config
from notion_calendar_sync.providers import NotionProvider,GoogleProvider
from notion_calendar_sync.model import normalize_time
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--config',required=True);ap.add_argument('--apply',action='store_true',required=True)
args=ap.parse_args();c=load_config(args.config);m=c.mappings[0];n=NotionProvider(c);g=GoogleProvider(c)
prefix='NCS-DAEMON-'+uuid.uuid4().hex[:10];report={'prefix':prefix,'mode':'actual systemd daemon; real full-scope provider scans','poll_seconds':m.poll_seconds,'checks':[]};nid=gid=None
os.umask(0o077)
def wait_for(name,query):
 start=time.monotonic();deadline=start+240
 while time.monotonic()<deadline:
  with closing(sqlite3.connect('file:'+str(c.state_path)+'?mode=ro',uri=True)) as db:
   value=query(db)
  if value:
   report['checks'].append({'name':name,'acknowledged_source_write_to_local_completion_seconds':round(time.monotonic()-start,3)})
   return value
  time.sleep(.5)
 raise TimeoutError(name)
def observed(db,side,id,title=None,deleted=None):
 row=db.execute('select record from observations where mapping=? and side=? and item_id=?',(m.name,side,id)).fetchone()
 if not row:return False
 r=json.loads(row[0])
 return (title is None or r['values'].get('title')==title) and (deleted is None or r['deleted']==deleted)
try:
 props=n._properties(m,{'title':prefix,'time':normalize_time('2036-01-15T10:00:00-07:00','2036-01-15T11:00:00-07:00',m.timezone),'description':'Disposable daemon acceptance test','location':'','recurrence':[]})
 if m.notion_select_property:props[m.notion_select_property]={'select':{'name':m.notion_select_value}}
 nid=n._request('POST','/pages',body={'parent':{'type':'data_source_id','data_source_id':m.notion_data_source},'properties':props},safe=False)['id']
 gid=wait_for('notion-create-to-google',lambda db:(db.execute('select google_id from links where mapping=? and notion_id=? and google_id is not null',(m.name,nid)).fetchone() or [None])[0])
 assert g.get(m,gid).values['title']==prefix
 g.update(m,gid,{'title':prefix+' Google edit'})
 wait_for('google-edit-to-same-notion-page',lambda db:observed(db,'notion',nid,title=prefix+' Google edit'))
 assert n.get(m,nid).values['title']==prefix+' Google edit'
 n.archive(m,nid)
 wait_for('notion-trash-to-google-cancellation',lambda db:observed(db,'google',gid,deleted=True))
 assert g.get(m,gid).deleted
 report['logical_pair']={'notion':nid,'google':gid};report['passed']=True
finally:
 for provider,id in [(n,nid),(g,gid)]:
  if id:
   try:
    r=provider.get(m,id)
    if not r.deleted:provider.archive(m,id,r.version)
   except Exception:pass
 out=c.state_path.parent/'daemon-live-report.json';out.write_text(json.dumps(report,indent=2));out.chmod(0o600)
print(json.dumps(report,indent=2))
