#!/usr/bin/env python3
"""Native Windows acceptance probes; never reads existing app credentials/state.

Run using the extracted bundle's runtime/python.exe -I, passing --bundle to the
extracted 'Notion Calendar Sync' folder. Temporary installer destinations are
created beneath a disposable directory; no real startup preference is changed.
"""
import argparse
import ctypes
from contextlib import closing
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time
import uuid
from unittest.mock import patch


def run_checks(bundle=None):
    if sys.platform != 'win32':
        raise RuntimeError('This checker requires actual native Windows execution.')
    from notion_calendar_sync.desktop_platform import SecretStore, SecretJSONStore, _Credential
    from notion_calendar_sync.oauth import TokenManager
    from notion_calendar_sync.service import StateLock
    result = {'platform': platform.platform(), 'machine': platform.machine(),
              'python': sys.version.split()[0], 'native_windows': True, 'checks': [], 'passed': False}
    def check(name, condition):
        if not condition:
            raise AssertionError(name)
        result['checks'].append(name)
    expected = {'Flags':0,'Type':4,'TargetName':8,'Comment':16,'LastWritten':24,
                'CredentialBlobSize':32,'CredentialBlob':40,'Persist':48,'AttributeCount':52,
                'Attributes':56,'TargetAlias':64,'UserName':72}
    check('native CREDENTIALW x64 ABI', ctypes.sizeof(ctypes.c_void_p)==8 and ctypes.sizeof(_Credential)==80 and all(getattr(_Credential,k).offset==v for k,v in expected.items()))
    vault = SecretStore(service='org.notioncalendarsync.test.'+uuid.uuid4().hex)
    try:
        check('isolated credential missing',vault.get('probe') is None)
        vault.set('probe','disposable credential café 🌌')
        check('native credential roundtrip',vault.get('probe')=='disposable credential café 🌌')
        value='disposable-long-🔐'*1000
        vault.set('probe',value)
        check('native chunked credential roundtrip',vault.get('probe')==value)
        vault.set('probe','short replacement')
        check('native credential replacement',vault.get('probe')=='short replacement')
        vault.delete('probe');check('native credential deleted',vault.get('probe') is None)
        tokens=SecretJSONStore(vault,'oauth')
        tokens.save({'refresh_token':'disposable-refresh','expires_at':0})
        class Transport:
            def request(self,*a,**kw):return {'access_token':'disposable-access','expires_in':3600}
        with tempfile.TemporaryDirectory(prefix='ncs-win-native-') as td:
            root=Path(td)
            manager=TokenManager(root/'unused-client',root/'unused-token',Transport(),
                client_loader=lambda:{'client_id':'disposable-id'},token_loader=tokens.load,token_saver=tokens.save)
            check('native OAuth refresh hook',manager.access_token()=='disposable-access' and tokens.load()['refresh_token']=='disposable-refresh')
            check('no plaintext OAuth files',not list(root.iterdir()))
            state=root/'state.sqlite3'
            from notion_calendar_sync import service
            package_root=str(Path(service.__file__).resolve().parent.parent)
            code='import sys;sys.path.insert(0,sys.argv[1]);from notion_calendar_sync.service import StateLock\ntry:\n with StateLock(sys.argv[2]):print("acquired")\nexcept RuntimeError:print("blocked")'
            command=[sys.executable,'-I','-c',code,package_root,str(state)]
            with StateLock(state):
                child=subprocess.run(command,capture_output=True,text=True,timeout=30)
                check('native second writer rejected',child.returncode==0 and child.stdout.strip()=='blocked')
            child=subprocess.run(command,capture_output=True,text=True,timeout=30)
            check('native lock released',child.returncode==0 and child.stdout.strip()=='acquired')
        # Use the real Win32 registry APIs with only this process's imported
        # adapter routing the fixed Run path into a disposable unique key.
        # The user's actual startup preference is never read or changed.
        import winreg
        from types import SimpleNamespace
        from notion_calendar_sync.desktop_platform import set_startup, startup_enabled, APP_NAME
        temporary_key = r'Software\NCS-validation-' + uuid.uuid4().hex
        run_key = r'Software\Microsoft\Windows\CurrentVersion\Run'
        def routed_create(root,path):
            assert root == winreg.HKEY_CURRENT_USER and path == run_key
            return winreg.CreateKey(root,temporary_key)
        def routed_open(root,path):
            assert root == winreg.HKEY_CURRENT_USER and path == run_key
            return winreg.OpenKey(root,temporary_key)
        adapter=SimpleNamespace(HKEY_CURRENT_USER=winreg.HKEY_CURRENT_USER,REG_SZ=winreg.REG_SZ,
            CreateKey=routed_create,OpenKey=routed_open,SetValueEx=winreg.SetValueEx,
            QueryValueEx=winreg.QueryValueEx,DeleteValue=winreg.DeleteValue)
        try:
            with patch.dict(sys.modules,{'winreg':adapter}):
                startup=[r'C:\Program Files\NCS Test\pythonw.exe','-I','-m','notion_calendar_sync.desktop','--background']
                set_startup(True,startup,platform='Windows')
                check('native startup registration isolated key',startup_enabled(platform='Windows'))
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER,temporary_key) as key:
                    command,_=winreg.QueryValueEx(key,APP_NAME)
                    check('native startup quoted private runtime',command==subprocess.list2cmdline(startup))
                set_startup(False,startup,platform='Windows')
                check('native startup removal isolated key',not startup_enabled(platform='Windows'))
        finally:
            try:
                winreg.DeleteKey(winreg.HKEY_CURRENT_USER,temporary_key)
            except FileNotFoundError:
                pass
        if bundle:
            bundle=Path(bundle).resolve()
            runtime=bundle/'runtime/python.exe'
            check('bundle runtime exists',runtime.is_file())
            child=subprocess.run([str(runtime),'-I','-m','notion_calendar_sync.desktop','--smoke-test'],timeout=60)
            check('portable native Tk setup window',child.returncode==0)
            # Only an empty disposable program directory is touched. Shortcut
            # and startup registry writes are disabled by --test-root.
            with tempfile.TemporaryDirectory(prefix='ncs-installer-') as td:
                destination=Path(td)
                install=bundle/'Install.vbs'
                command=['cscript.exe','//nologo',str(install),'--test-root',str(destination)]
                child=subprocess.run(command,capture_output=True,text=True,timeout=120)
                check('installer fresh staging and promotion',child.returncode==0)
                installed=destination/'Notion Calendar Sync'
                check('installer retained full notices',(installed/'Licenses').is_dir() and (installed/'runtime/pythonw.exe').is_file())
                marker=installed/'preserved-test-marker.txt';marker.write_text('disposable old installation')
                child=subprocess.run(command+['--simulate-promotion-failure'],capture_output=True,text=True,timeout=120)
                check('installer failed promotion rollback',child.returncode!=0 and marker.read_text()=='disposable old installation')
                child=subprocess.run(command,capture_output=True,text=True,timeout=120)
                check('installer successful upgrade',child.returncode==0)
                backups=list(destination.glob('Notion Calendar Sync.previous-*'))
                check('installer recovery copy retained',any((p/'preserved-test-marker.txt').is_file() for p in backups))
                check('installer temporary staging cleaned',not list(destination.glob('Notion Calendar Sync.staging-*')))
        result['passed']=True
        return result
    finally:
        vault.delete('probe');vault.delete('oauth')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--bundle',type=Path)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    try:
        result=run_checks(args.bundle)
    except Exception as error:
        result={'passed':False,'native_windows':sys.platform=='win32','error':type(error).__name__}
        if isinstance(error,(AssertionError,RuntimeError)):
            result['message']=str(error)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
    if not result['passed']:
        raise SystemExit(1)


if __name__=='__main__':main()
