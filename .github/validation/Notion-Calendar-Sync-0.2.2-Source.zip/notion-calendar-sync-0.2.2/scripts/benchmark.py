#!/usr/bin/env python3
"""Reproduce local engine/service timings with synthetic provider latency.

No credentials or network calls. Runs from a source checkout (test fixtures are
intentional); it does NOT measure the actual provider APIs or Raspberry Pi.
"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
import json
from pathlib import Path
import platform
import resource
import statistics
import sys
import tempfile
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'tests')]
from test_engine import FakeProvider, values  # noqa: E402
from notion_calendar_sync.config import Config, Mapping  # noqa: E402
from notion_calendar_sync.engine import Engine  # noqa: E402
from notion_calendar_sync.service import SyncService  # noqa: E402
from notion_calendar_sync.store import Store  # noqa: E402


class InstrumentedProvider(FakeProvider):
    """Delay each external provider-method call, excluding nested fake helpers."""
    def __init__(self, side):
        super().__init__(side)
        self.delay = 0.0
        self.sleep_seconds = 0.0
        self.calls = Counter()
        self.depth = 0
        for name in ('validate', 'scan', 'get', 'create', 'update', 'archive', 'set_links'):
            original = getattr(self, name)
            setattr(self, name, self.wrap(name, original))

    def wrap(self, name, method):
        def instrumented(*args, **kwargs):
            outer = self.depth == 0
            if outer:
                self.calls[name] += 1
                if self.delay:
                    start = time.perf_counter()
                    time.sleep(self.delay)
                    self.sleep_seconds += time.perf_counter() - start
            self.depth += 1
            try:
                return method(*args, **kwargs)
            finally:
                self.depth -= 1
        return instrumented


def summary(numbers):
    ordered = sorted(numbers)
    return {
        'min': round(min(ordered), 6),
        'median': round(statistics.median(ordered), 6),
        'p95': round(ordered[max(0, (95 * len(ordered) + 99) // 100 - 1)], 6),
        'max': round(max(ordered), 6),
        'mean': round(statistics.mean(ordered), 6),
    }


def cpu_seconds():
    use = resource.getrusage(resource.RUSAGE_SELF)
    return use.ru_utime + use.ru_stime


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--items', type=int, default=100)
    parser.add_argument('--edits', type=int, default=20)
    parser.add_argument('--delay-ms', type=float, default=50)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.items < 1 or args.edits < 1 or args.delay_ms < 0:
        parser.error('items/edits must be positive; delay must be nonnegative')
    result = {
        'kind': 'local synthetic-provider benchmark; no live API calls',
        'host': {'system': platform.system(), 'release': platform.release(),
                 'machine': platform.machine(), 'python': platform.python_version()},
        'workload': {'mappings': 1, 'linked_items': args.items, 'note_bytes_each': 1024,
                     'sequential_single_item_edits': args.edits, 'directions': 'alternating notion/google',
                     'injected_delay_ms_per_external_provider_method': args.delay_ms,
                     'daemon_wake_interval_seconds': 0.25,
                     'provider_fakes_return_full_snapshots': True},
        'unmeasured': ['provider notification delivery delay', 'real API/network delay and throttling',
                       'provider UI end-to-end latency', 'Raspberry Pi CPU/RAM/OS performance'],
    }
    with tempfile.TemporaryDirectory(prefix='ncs-benchmark-') as directory:
        path = Path(directory) / 'sync.sqlite3'
        mapping = Mapping('benchmark', 'data-source', 'calendar', properties={
            'title': 'Task', 'date': 'Date', 'description': 'Note', 'location': 'Location',
            'google_event_id': 'ID', 'google_url': 'Link', 'recurrence': 'Recurrence'})
        config = Config(state_path=path, mappings=[mapping])
        notion, google = InstrumentedProvider('notion'), InstrumentedProvider('google')
        for index in range(args.items):
            notion.add('n' + str(index), values(title='Benchmark ' + str(index), description='x' * 1024))
        with Store(path) as store:
            engine = Engine(config, store, notion, google)
            start, cpu_start = time.perf_counter(), cpu_seconds()
            report = engine.sync(full=True)
            errors = [row for row in report if row['action'] in ('error', 'retry', 'ambiguous', 'conflict')]
            if errors:
                raise RuntimeError('Initial benchmark import failed: ' + json.dumps(errors))
            result['initial_import_zero_delay'] = {
                'wall_seconds': round(time.perf_counter() - start, 6),
                'cpu_seconds': round(cpu_seconds() - cpu_start, 6),
                'provider_method_calls': {'notion': dict(notion.calls), 'google': dict(google.calls)},
            }
            pairs = [dict(row) for row in store.db.execute('SELECT * FROM links ORDER BY id')]
            if len(pairs) != args.items:
                raise RuntimeError('Unexpected initial link count')
            # An unchanged pass establishes metadata and proves no feedback writes.
            before_writes = len(notion.writes) + len(google.writes)
            engine.sync(full=True)
            unchanged_writes = len(notion.writes) + len(google.writes) - before_writes
            if unchanged_writes:
                raise RuntimeError('Unchanged reconciliation wrote provider data')
            for provider in (notion, google):
                provider.delay = args.delay_ms / 1000
                provider.calls.clear()
                provider.sleep_seconds = 0
            service = SyncService(config, store, engine, google)
            # Initial import above is the full reconciliation. Every test edit is
            # a durable signal, with no other poll/reconcile due during the run.
            deadline = time.monotonic() + 3600
            service.next_poll[mapping.name] = deadline
            service.next_reconcile[mapping.name] = deadline
            processing, queue, completion, injected = [], [], [], []
            driver_errors = []

            def drive_changes():
                try:
                    with Store(path) as inbox:
                        for index in range(args.edits):
                            pair = pairs[index % len(pairs)]
                            side = 'notion' if index % 2 == 0 else 'google'
                            source = notion if side == 'notion' else google
                            peer = google if side == 'notion' else notion
                            source_id, target_id = pair[side + '_id'], pair[('google' if side == 'notion' else 'notion') + '_id']
                            title = 'Edited item ' + str(index)
                            source.edit(source_id, title=title)
                            before_sleep = notion.sleep_seconds + google.sleep_seconds
                            signal_id = 'benchmark-' + str(index)
                            inbox.signal(side, mapping.name, source_id if side == 'notion' else '', signal_id)
                            until = time.monotonic() + 60
                            while inbox.db.execute('SELECT 1 FROM signals WHERE id=?', (signal_id,)).fetchone():
                                if time.monotonic() > until:
                                    raise RuntimeError('Benchmark signal timed out')
                                time.sleep(0.01)
                            metrics = inbox.get_meta('last_service_metrics')
                            if not metrics or not metrics.get('success'):
                                raise RuntimeError('Service batch did not succeed')
                            if peer.items[target_id].values['title'] != title:
                                raise RuntimeError('Peer did not receive benchmark edit')
                            processing.append(metrics['duration_seconds'])
                            queue.append(metrics['signal_wait_seconds'])
                            completion.append(metrics['notification_to_batch_completion_seconds'])
                            injected.append(notion.sleep_seconds + google.sleep_seconds - before_sleep)
                except Exception as error:
                    driver_errors.append(str(error))
                finally:
                    service.stop.set()

            cpu_start, start = cpu_seconds(), time.perf_counter()
            driver = threading.Thread(target=drive_changes, name='benchmark-signal-driver')
            driver.start()
            service.run()
            driver.join(timeout=2)
            wall = time.perf_counter() - start
            cpu = cpu_seconds() - cpu_start
            if driver_errors:
                raise RuntimeError('; '.join(driver_errors))
            if len(processing) != args.edits:
                raise RuntimeError('Benchmark did not complete every edit')
            use = resource.getrusage(resource.RUSAGE_SELF)
            rss_bytes = use.ru_maxrss if sys.platform == 'darwin' else use.ru_maxrss * 1024
            store.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
            table_counts = {table: store.db.execute('SELECT COUNT(*) FROM ' + table).fetchone()[0]
                            for table in ('links', 'observations', 'operations', 'conflicts', 'signals')}
            result['single_item_edits'] = {
                'processing_seconds_including_injected_wait': summary(processing),
                'queue_wait_seconds_actual_daemon': summary(queue),
                'durable_signal_to_batch_completion_seconds': summary(completion),
                'injected_provider_wait_seconds': summary(injected),
                'processing_seconds_after_subtracting_injected_wait': summary([
                    max(0, p - wait) for p, wait in zip(processing, injected)]),
                'whole_workload_wall_seconds': round(wall, 6),
                'whole_process_cpu_seconds': round(cpu, 6),
                'average_one_core_cpu_percent_during_workload': round(100 * cpu / wall, 3),
                'provider_method_calls': {'notion': dict(notion.calls), 'google': dict(google.calls)},
                'unchanged_full_reconciliation_remote_writes': unchanged_writes,
            }
            result['resources'] = {
                'process_peak_rss_bytes': int(rss_bytes),
                'sqlite_database_bytes_after_checkpoint': path.stat().st_size,
                'sqlite_wal_bytes_after_checkpoint': Path(str(path) + '-wal').stat().st_size,
                'state_directory_total_bytes_after_checkpoint': sum(p.stat().st_size for p in path.parent.iterdir() if p.is_file()),
                'sqlite_table_rows': table_counts,
                'notes': 'RSS includes benchmark driver/test fixtures; CPU includes the signal-driving thread and SQLite polling. No idle Pi measurement. State/history grows with edits; rotated logs are separate.',
            }
    output = json.dumps(result, indent=2, sort_keys=True) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output)
    print(output, end='')


if __name__ == '__main__':
    main()
