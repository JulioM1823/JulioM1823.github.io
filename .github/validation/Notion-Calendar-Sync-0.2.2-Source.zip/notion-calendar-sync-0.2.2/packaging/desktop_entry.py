"""Frozen desktop entry point; deliberately separate from the headless CLI."""
from notion_calendar_sync.desktop import main

if __name__ == '__main__':
    main()
