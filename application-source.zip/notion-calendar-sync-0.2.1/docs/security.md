# Credentials, privacy, and webhook boundaries

The service uses an internal Notion token and a Google Desktop OAuth refresh token. Tokens never belong in source control or command-line arguments. The example TOML stores only paths/environment-variable names. Production secrets live in root-owned mode-0600 `/etc/ncs/secrets.env`; Google credentials/token and SQLite state have the documented restricted modes. Token refresh writes are atomic. State can contain event descriptions, pending values, and conflicting versions, so treat backups as sensitive.

Only the configured data sources/calendars are acted on. Notion integration access should be limited to the target database. Google scopes allow event management and calendar-list reads for the authorizing account; Google does not offer a scope bound to a single selected existing calendar. Configured calendar ids are the application boundary. Default attendee filtering avoids invitation/RSVP side effects. No meeting notifications or emails are intentionally sent.

The HTTPS receiver does not accept instructions from event content. Webhook payloads are hints and are never applied as authoritative item values. Notion uses HMAC-SHA256 over exact request bytes, subscription/workspace restrictions when configured, an age check, and durable event-id deduplication. Google requests must match a known active channel id, random token, resource id, and expiry. A notification cannot itself delete anything; the worker must fetch explicit provider deletion state.

Initial Notion verification is a separate, explicitly invoked short-lived CLI operation. Its received token remains untrusted until the operator successfully verifies it in Notion and installs it as the service's secret. The normal daemon rejects unsigned handshake requests. Do not log or proxy-log bearer tokens or channel-token headers.

The built-in HTTP server binds loopback by default and is intended to sit behind an existing HTTPS reverse proxy. It has a body limit and does not provide a general web UI. Deploy polling-only when no stable HTTPS endpoint exists. Do not expose the plain HTTP receiver directly to the internet.

The runtime has no third-party packages. Python's standard library is covered by the Python Software Foundation license. The build uses setuptools (MIT) and distribution packaging tools. This repository's source is [MIT](../LICENSE). TLS uses system CA roots; keeping Raspberry Pi OS/security packages and `tzdata` current remains part of normal system administration.
