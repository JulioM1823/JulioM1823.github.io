"""Native desktop setup and dashboard; all provider work stays off Tk's thread."""
from __future__ import annotations

import json
from pathlib import Path
import queue
import threading
import sys
from datetime import datetime
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
import webbrowser


FIELDS = [
    ('title', 'Event title *', 'title', 'The name displayed in Calendar.'),
    ('date', 'Start / end / all-day *', 'date', 'One Notion Date property supplies the full event range.'),
    ('description', 'Description / notes', 'rich_text', 'Literal text; existing unmapped page content stays intact.'),
    ('location', 'Location', 'rich_text', 'Address or meeting place.'),
    ('timezone', 'Event time zone', 'rich_text', 'Optional IANA zone per event, such as America/Denver.'),
    ('google_url', 'Google event link', 'url', 'A clickable link back to the Calendar event.'),
    ('google_event_id', 'Stable event identity *', 'rich_text', 'Required for reliable linking and recovery after interruption.'),
    ('recurrence', 'Recurring event rules', 'rich_text', 'Optional RFC5545 rules; unsupported cases pause safely.'),
    ('sync_enabled', 'Include this entry', 'checkbox', 'Optional checkbox limits which pages participate.'),
]


def display_name(row):
    return f"{row.get('name') or row.get('title') or 'Untitled'}  ·  {row.get('id', '')}"


def properties_from_schema(schema):
    return schema.get('properties', schema) if isinstance(schema, dict) else {}


class DesktopWindow:
    """Small native Tk shell over DesktopController's account/setup operations."""

    def __init__(self, controller, root=None):
        self.controller = controller
        self.root = root or tk.Tk()
        self.root.title('Notion Calendar Sync')
        self.root.geometry('1120x820')
        self.root.minsize(940, 700)
        self.root.configure(bg='#f2f5f9')
        self.tasks = queue.Queue()
        self.results = queue.Queue()
        self.alive = True
        self.state_pending = False
        self.active_jobs = 0
        self.current_state = {}
        self.preview_id = None
        self.schema_data = {}
        self.database_rows = []
        self.source_rows = []
        self.calendar_rows = []
        self.conflict_rows = []
        self.page = ''
        self.mapping_vars = {key: tk.StringVar() for key, *_ in FIELDS}
        self.source_id = tk.StringVar()
        self.calendar_id = tk.StringVar()
        self.zone = tk.StringVar(value='America/Denver')
        self.duration = tk.StringVar(value='60')
        self.poll = tk.StringVar(value='45')
        self.reconcile = tk.StringVar(value='900')
        self.category_property = tk.StringVar()
        self.category_value = tk.StringVar()
        self.startup = tk.BooleanVar(value=False)
        for variable in [*self.mapping_vars.values(), self.source_id, self.calendar_id,
                         self.zone, self.duration, self.poll, self.reconcile,
                         self.category_property, self.category_value]:
            variable.trace_add('write', lambda *_: self._invalidate_preview())
        self._style()
        self._build()
        self.root.protocol('WM_DELETE_WINDOW', self._minimize)
        if sys.platform == 'darwin':
            self.root.createcommand('tk::mac::ReopenApplication', self._show_window)
        threading.Thread(target=self._worker, name='desktop-ui-jobs', daemon=True).start()
        self.root.after(60, self._drain)
        self._run('Loading your workspace', self.controller.state, self._initial_state)
        self.root.after(3000, self._poll_state)

    def _style(self):
        style = ttk.Style(self.root)
        if 'clam' in style.theme_names():
            style.theme_use('clam')
        style.configure('.', font=('Helvetica', 11), background='#f2f5f9', foreground='#182d43')
        style.configure('TFrame', background='#f2f5f9')
        style.configure('Card.TFrame', background='#ffffff')
        style.configure('Card.TLabel', background='#ffffff')
        style.configure('Title.TLabel', font=('Helvetica', 25, 'bold'), foreground='#142b43')
        style.configure('Section.TLabel', font=('Helvetica', 14, 'bold'))
        style.configure('Muted.TLabel', foreground='#52677b')
        style.configure('Good.TLabel', foreground='#087f6c', font=('Helvetica', 12, 'bold'))
        style.configure('TButton', padding=(12, 9))
        style.configure('Accent.TButton', background='#166e76', foreground='white', padding=(15, 10))
        style.map('Accent.TButton', background=[('active', '#0b525b'), ('disabled', '#b6c8ca')])
        style.configure('Nav.TButton', anchor='w', padding=(12, 13))
        style.configure('Treeview', rowheight=29, fieldbackground='white', background='white')
        style.configure('Treeview.Heading', font=('Helvetica', 10, 'bold'))
        style.configure('TEntry', fieldbackground='white', padding=5)
        style.configure('TCombobox', fieldbackground='white', padding=5)

    def _build(self):
        menu = tk.Menu(self.root)
        app = tk.Menu(menu, tearoff=False)
        app.add_command(label='Show window', command=self._show_window)
        app.add_command(label='Minimize and keep syncing', command=self._minimize)
        app.add_separator()
        app.add_command(label='Quit Notion Calendar Sync', command=self._quit)
        menu.add_cascade(label='App', menu=app)
        help_menu = tk.Menu(menu, tearoff=False)
        help_menu.add_command(label='Notion connection setup', command=lambda: webbrowser.open('https://www.notion.so/profile/integrations'))
        help_menu.add_command(label='Google Cloud credentials', command=lambda: webbrowser.open('https://console.cloud.google.com/apis/credentials'))
        menu.add_cascade(label='Help', menu=help_menu)
        self.root.config(menu=menu)
        shell = ttk.Frame(self.root, padding=22)
        shell.pack(fill='both', expand=True)
        shell.columnconfigure(1, weight=1)
        shell.rowconfigure(0, weight=1)
        nav = ttk.Frame(shell, width=185)
        nav.grid(row=0, column=0, sticky='nsw', padx=(0, 24))
        ttk.Label(nav, text='NOTION\nCALENDAR SYNC', font=('Helvetica', 13, 'bold'), justify='left').pack(anchor='w', pady=(8, 26))
        for key, label in [('connect', '1  Connect accounts'), ('choose', '2  Choose calendars'),
                           ('mapping', '3  Map your fields'), ('preview', '4  Review & start'),
                           ('dashboard', '    Dashboard')]:
            ttk.Button(nav, text=label, style='Nav.TButton', command=lambda p=key: self.show(p)).pack(fill='x', pady=3)
        ttk.Label(nav, text='Your computer keeps\nyour calendars in sync.', style='Muted.TLabel', justify='left').pack(anchor='w', pady=(32, 8))
        ttk.Label(nav, text='Keep it powered on, online,\nand this app running.', style='Muted.TLabel', justify='left').pack(anchor='w')
        content = ttk.Frame(shell)
        content.grid(row=0, column=1, sticky='nsew')
        content.columnconfigure(0, weight=1)
        content.rowconfigure(0, weight=1)
        self.pages = {}
        for key in ('connect', 'choose', 'mapping', 'preview', 'dashboard'):
            frame = ttk.Frame(content)
            frame.grid(row=0, column=0, sticky='nsew')
            self.pages[key] = frame
        self._connect_page()
        self._choose_page()
        self._mapping_page()
        self._preview_page()
        self._dashboard_page()
        footer = ttk.Frame(shell)
        footer.grid(row=1, column=0, columnspan=2, sticky='ew', pady=(16, 0))
        self.activity = ttk.Label(footer, text='Ready', style='Muted.TLabel')
        self.activity.pack(side='left')
        ttk.Button(footer, text='Minimize · keep syncing', command=self._minimize).pack(side='right')
        self.show('connect')

    def _heading(self, parent, title, subtitle):
        ttk.Label(parent, text=title, style='Title.TLabel').pack(anchor='w', pady=(0, 8))
        ttk.Label(parent, text=subtitle, style='Muted.TLabel', wraplength=780, justify='left').pack(anchor='w', pady=(0, 18))

    def _card(self, parent):
        card = ttk.Frame(parent, style='Card.TFrame', padding=18)
        card.pack(fill='x', pady=(0, 14))
        return card

    def _connect_page(self):
        p = self.pages['connect']
        self._heading(p, 'Connect your accounts', 'Credentials are saved in your operating system’s secure credential storage. Your calendar data stays on this computer and the providers you connect.')
        card = self._card(p)
        ttk.Label(card, text='Notion', style='Section.TLabel').pack(anchor='w')
        ttk.Label(card, text='Create an internal Notion connection with Read, Insert and Update content.\nIn Notion, share your calendar database with that connection using Connections.', wraplength=740, justify='left', style='Card.TLabel').pack(anchor='w', pady=(8, 10))
        row = ttk.Frame(card, style='Card.TFrame'); row.pack(fill='x')
        self.notion_token = tk.StringVar()
        ttk.Entry(row, textvariable=self.notion_token, show='•').pack(side='left', fill='x', expand=True, padx=(0, 10))
        ttk.Button(row, text='Connect Notion', command=self._connect_notion).pack(side='right')
        self.notion_status = ttk.Label(card, text='Not connected', style='Card.TLabel')
        self.notion_status.pack(anchor='w', pady=(10, 0))
        card = self._card(p)
        ttk.Label(card, text='Google Calendar', style='Section.TLabel').pack(anchor='w')
        ttk.Label(card, text='Use a Google Cloud project with the Calendar API enabled and an OAuth client\nof type Desktop app. Download its client JSON, then authorize in your browser.\nExternal apps in Testing may lose offline access after seven days; for unattended\nuse, complete Google’s appropriate publishing or Workspace setup.', style='Card.TLabel', justify='left', wraplength=740).pack(anchor='w', pady=(8, 12))
        row = ttk.Frame(card, style='Card.TFrame'); row.pack(fill='x')
        ttk.Button(row, text='Choose OAuth client JSON…', command=self._choose_client).pack(side='left')
        ttk.Button(row, text='Authorize Google', style='Accent.TButton', command=lambda: self._run('Waiting for Google authorization in your browser', self.controller.authorize_google, lambda _: self._refresh())).pack(side='right')
        self.client_label = ttk.Label(card, text='No client selected', style='Card.TLabel')
        self.client_label.pack(anchor='w', pady=(10, 4))
        self.google_status = ttk.Label(card, text='Not connected', style='Card.TLabel')
        self.google_status.pack(anchor='w')
        ttk.Button(p, text='Continue to database selection →', style='Accent.TButton', command=lambda: self.show('choose')).pack(anchor='e', pady=8)

    def _choose_page(self):
        p = self.pages['choose']
        self._heading(p, 'Choose what to sync', 'Choose one Notion data source and one writable Google calendar. IDs are shown beside names so similarly named databases remain distinct.')
        card = self._card(p)
        ttk.Label(card, text='Notion database name, ID or URL', style='Card.TLabel').pack(anchor='w')
        row = ttk.Frame(card, style='Card.TFrame'); row.pack(fill='x', pady=(7, 10))
        self.database_query = tk.StringVar()
        query_entry = ttk.Entry(row, textvariable=self.database_query)
        query_entry.pack(side='left', fill='x', expand=True, padx=(0, 10))
        query_entry.bind('<Return>', lambda _: self._find_databases())
        ttk.Button(row, text='Find', command=self._find_databases).pack(side='right')
        self.database_choice = tk.StringVar()
        self.database_combo = ttk.Combobox(card, textvariable=self.database_choice, state='readonly')
        self.database_combo.pack(fill='x', pady=(0, 10))
        ttk.Button(card, text='Use selected database / entered ID', command=self._load_sources).pack(anchor='w')
        ttk.Label(card, text='Data source inside this database', style='Card.TLabel').pack(anchor='w', pady=(15, 6))
        self.source_choice = tk.StringVar()
        self.source_combo = ttk.Combobox(card, textvariable=self.source_choice, state='readonly')
        self.source_combo.pack(fill='x')
        self.source_combo.bind('<<ComboboxSelected>>', self._source_selected)
        self.source_label = ttk.Label(card, text='Databases can contain multiple data sources. Select the one with your events.', style='Card.TLabel', wraplength=730)
        self.source_label.pack(anchor='w', pady=(7, 0))
        card = self._card(p)
        ttk.Label(card, text='Google calendar', style='Card.TLabel').pack(anchor='w')
        row = ttk.Frame(card, style='Card.TFrame'); row.pack(fill='x', pady=(7, 0))
        self.calendar_choice = tk.StringVar()
        self.calendar_combo = ttk.Combobox(row, textvariable=self.calendar_choice, state='readonly')
        self.calendar_combo.pack(side='left', fill='x', expand=True, padx=(0, 10))
        self.calendar_combo.bind('<<ComboboxSelected>>', self._calendar_selected)
        ttk.Button(row, text='Refresh', command=self._load_calendars).pack(side='right')
        ttk.Button(p, text='Inspect fields & continue →', style='Accent.TButton', command=self._inspect_and_continue).pack(anchor='e', pady=8)

    def _mapping_page(self):
        p = self.pages['mapping']
        self._heading(p, 'Make the fields match', 'Suggestions are a starting point. Review each property; only mapped fields will be updated. Fields marked * are required.')
        canvas = tk.Canvas(p, bg='#f2f5f9', highlightthickness=0)
        scrollbar = ttk.Scrollbar(p, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right', fill='y')
        canvas.pack(fill='both', expand=True)
        body = ttk.Frame(canvas)
        item = canvas.create_window((0, 0), window=body, anchor='nw')
        body.bind('<Configure>', lambda _: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(item, width=e.width))
        grid = ttk.Frame(body)
        grid.pack(fill='x')
        grid.columnconfigure(1, weight=1)
        self.mapping_combos = {}
        for i, (key, label, _, description) in enumerate(FIELDS):
            ttk.Label(grid, text=label).grid(row=i*2, column=0, sticky='w', padx=(0, 14), pady=(5, 0))
            combo = ttk.Combobox(grid, textvariable=self.mapping_vars[key], state='readonly', width=30)
            combo.grid(row=i*2, column=1, sticky='ew', pady=(5, 0))
            self.mapping_combos[key] = combo
            ttk.Label(grid, text=description, style='Muted.TLabel', wraplength=740).grid(row=i*2+1, column=0, columnspan=2, sticky='w', pady=(2, 8))
        ttk.Button(body, text='Create missing integration properties…', command=self._create_properties).pack(anchor='w', pady=(4, 15))
        ttk.Separator(body).pack(fill='x', pady=(0, 12))
        settings = ttk.Frame(body); settings.pack(fill='x')
        for i, (label, variable, width) in enumerate([('Default IANA time zone', self.zone, 25), ('Missing end: duration in minutes', self.duration, 8), ('Poll interval (seconds)', self.poll, 8), ('Full check interval (seconds)', self.reconcile, 8)]):
            ttk.Label(settings, text=label).grid(row=i, column=0, sticky='w', pady=5, padx=(0, 14))
            ttk.Entry(settings, textvariable=variable, width=width).grid(row=i, column=1, sticky='w', pady=5)
        ttk.Label(body, text='Date-only entries become all-day events. Notion’s last date is inclusive; Calendar’s end is exclusive. Empty dates pause that entry without deleting its event. The date range supplies start and end; a missing end uses the duration above.', style='Muted.TLabel', wraplength=740, justify='left').pack(anchor='w', pady=(12, 16))
        ttk.Label(body, text='Optional category filter', style='Section.TLabel').pack(anchor='w')
        filter_row = ttk.Frame(body); filter_row.pack(fill='x', pady=(8, 8))
        self.category_combo = ttk.Combobox(filter_row, textvariable=self.category_property, state='readonly', width=28)
        self.category_combo.pack(side='left', padx=(0, 10))
        self.category_combo.bind('<<ComboboxSelected>>', lambda _: self._category_options())
        self.category_value_combo = ttk.Combobox(filter_row, textvariable=self.category_value, state='readonly', width=28)
        self.category_value_combo.pack(side='left')
        ttk.Label(body, text='Leave both empty to include the whole source. A mapped Include checkbox can narrow it further. Recurring series use one page plus explicit modified occurrences; regular future occurrences are not expanded.', style='Muted.TLabel', wraplength=740, justify='left').pack(anchor='w', pady=(0, 16))
        ttk.Button(body, text='Preview synchronization →', style='Accent.TButton', command=self._preview).pack(anchor='e', pady=(0, 16))

    def _preview_page(self):
        p = self.pages['preview']
        self._heading(p, 'Review before the first sync', 'A preview does not write to your providers. Review creates, updates, stable links, conflicts and unsupported entries before approving.')
        self.preview_summary = ttk.Label(p, text='Choose fields, then generate a preview.', style='Section.TLabel', wraplength=760)
        self.preview_summary.pack(anchor='w', pady=(0, 12))
        self.preview_text = scrolledtext.ScrolledText(p, height=20, wrap='word', font=('Menlo', 10), bg='white', fg='#182d43', relief='flat', padx=12, pady=12)
        self.preview_text.pack(fill='both', expand=True)
        self.preview_text.configure(state='disabled')
        ttk.Label(p, text='Existing items are linked only by verified stable identities. Matching titles or dates do not merge unrelated entries. Originals and SQLite state are backed up before the approved first sync.', style='Muted.TLabel', wraplength=760).pack(anchor='w', pady=12)
        row = ttk.Frame(p); row.pack(fill='x')
        ttk.Button(row, text='← Edit mapping', command=lambda: self.show('mapping')).pack(side='left')
        ttk.Button(row, text='Refresh preview', command=self._preview).pack(side='left', padx=10)
        self.approve_button = ttk.Button(row, text='Approve this preview & start', style='Accent.TButton', state='disabled', command=self._approve)
        self.approve_button.pack(side='right')

    def _dashboard_page(self):
        p = self.pages['dashboard']
        self._heading(p, 'Your sync, at a glance', 'Minimize this window to keep syncing. Quitting the app stops synchronization; your persistent state is retained for the next launch.')
        card = self._card(p)
        self.health_label = ttk.Label(card, text='Set up your accounts to begin', style='Section.TLabel')
        self.health_label.pack(anchor='w')
        self.detail_label = ttk.Label(card, text='', style='Card.TLabel', wraplength=740, justify='left')
        self.detail_label.pack(anchor='w', pady=(10, 0))
        row = ttk.Frame(card, style='Card.TFrame'); row.pack(fill='x', pady=(14, 0))
        ttk.Button(row, text='Pause', command=lambda: self._run('Pausing after current work', self.controller.pause, lambda _: self._refresh())).pack(side='left')
        ttk.Button(row, text='Resume', style='Accent.TButton', command=self._resume).pack(side='left', padx=10)
        ttk.Button(row, text='Reconnect accounts', command=lambda: self.show('connect')).pack(side='right')
        ttk.Button(row, text='Edit mapping', command=self._edit_mapping).pack(side='right', padx=10)
        ttk.Checkbutton(p, text='Start at login on this computer', variable=self.startup, command=self._autostart).pack(anchor='w', pady=(0, 14))
        conflict_head = ttk.Frame(p); conflict_head.pack(fill='x')
        ttk.Label(conflict_head, text='Conflicts needing a choice', style='Section.TLabel').pack(side='left')
        ttk.Button(conflict_head, text='Refresh conflicts', command=self._conflicts).pack(side='right')
        self.conflict_tree = ttk.Treeview(p, columns=('id', 'fields', 'item'), show='headings', height=5, selectmode='browse')
        for col, label, width in [('id', 'ID', 65), ('fields', 'Changed fields', 180), ('item', 'Item / relationship', 380)]:
            self.conflict_tree.heading(col, text=label)
            self.conflict_tree.column(col, width=width, stretch=col=='item')
        self.conflict_tree.pack(fill='x', pady=(8, 8))
        self.conflict_tree.bind('<<TreeviewSelect>>', self._show_conflict)
        self.conflict_text = scrolledtext.ScrolledText(p, height=8, wrap='word', font=('Menlo', 10), bg='white', relief='flat', padx=10, pady=10)
        self.conflict_text.pack(fill='both', expand=True)
        self.conflict_text.configure(state='disabled')
        row = ttk.Frame(p); row.pack(fill='x', pady=10)
        ttk.Button(row, text='Use Notion’s conflicting values…', command=lambda: self._resolve('notion')).pack(side='left')
        ttk.Button(row, text='Use Google’s conflicting values…', command=lambda: self._resolve('google')).pack(side='left', padx=10)
        ttk.Button(p, text='Export redacted diagnostics…', command=self._diagnostics).pack(anchor='e')

    def show(self, page):
        self.pages[page].tkraise()
        self.page = page
        if page == 'dashboard':
            self._refresh()
            self._conflicts()

    def _worker(self):
        while True:
            job = self.tasks.get()
            if job is None:
                return
            name, function, callback, quiet = job
            try:
                self.results.put((True, function(), callback, quiet, name))
            except Exception as exc:
                self.results.put((False, exc, callback, quiet, name))

    def _run(self, label, function, callback=None, quiet=False):
        if not self.alive:
            return
        if not quiet:
            self.active_jobs += 1
            self.activity.configure(text=label+'…')
        self.tasks.put((label, function, callback, quiet))

    def _drain(self):
        if not self.alive:
            return
        try:
            while True:
                ok, value, callback, quiet, name = self.results.get_nowait()
                if not quiet:
                    self.active_jobs = max(0, self.active_jobs-1)
                    self.activity.configure(text='Ready' if not self.active_jobs else 'Working…')
                if ok:
                    if callback:
                        try:
                            callback(value)
                        except Exception as exc:
                            messagebox.showerror('Could not update the window', str(exc), parent=self.root)
                elif quiet:
                    self.state_pending = False
                    self.health_label.configure(text='Connection needs attention')
                    self.detail_label.configure(text=str(value))
                else:
                    messagebox.showerror('Could not complete '+name.lower(), str(value), parent=self.root)
        except queue.Empty:
            pass
        self.root.after(80, self._drain)

    def _poll_state(self):
        if not self.alive:
            return
        if not self.state_pending and not self.active_jobs:
            self.state_pending = True
            self._run('Refreshing status', self.controller.state, self._render_state, quiet=True)
        self.root.after(3000, self._poll_state)

    def _refresh(self):
        if not self.state_pending:
            self.state_pending = True
            self._run('Refreshing status', self.controller.state, self._render_state, quiet=True)

    def _initial_state(self, value):
        self._render_state(value)
        settings = value.get('settings') or {}
        if settings:
            self._restore_settings(settings)
        if value.get('configured'):
            self.show('dashboard')

    def _render_state(self, value):
        self.state_pending = False
        self.current_state = value
        self.notion_status.configure(text='Connected securely' if value.get('connected_notion') else 'Not connected')
        self.google_status.configure(text='Authorized for offline access' if value.get('connected_google') else 'Authorization required')
        running = value.get('running', False)
        title = 'Synchronization is running' if running else ('Synchronization is paused' if value.get('configured') else 'Complete setup to begin')
        if value.get('error'):
            title = 'Connection or synchronization needs attention'
        self.health_label.configure(text=title)
        status = value.get('status') or {}
        parts = []
        if isinstance(status, dict):
            groups = {group: {row.get('status'): row.get('count', 0) for row in status.get(group, [])}
                      for group in ('links', 'operations', 'conflicts') if isinstance(status.get(group, []), list)}
            links = groups.get('links', {})
            pending = sum(count for key, count in groups.get('operations', {}).items() if key not in ('done', 'cancelled'))
            open_conflicts = groups.get('conflicts', {}).get('open', 0)
            if status:
                parts.append(f"{links.get('active', 0)} linked items  ·  {pending} pending operations  ·  {open_conflicts} conflicts")
            diagnostics = status.get('diagnostics', {})
            successes = [item for key, item in diagnostics.items() if key.startswith('last_success:') and isinstance(item, (int, float))]
            if successes:
                parts.append('Last successful sync: '+datetime.fromtimestamp(max(successes)).astimezone().strftime('%b %d, %Y at %H:%M:%S %Z'))
            failures = [item for key, item in diagnostics.items() if key.startswith('last_error:') and item]
            if failures:
                self.health_label.configure(text='Sync is retrying · connection needs attention')
                parts.append('A provider request needs attention. Check account access; temporary failures retry automatically.')
            if open_conflicts != getattr(self, '_last_conflict_count', 0):
                self._last_conflict_count = open_conflicts
                if self.page == 'dashboard':
                    self._conflicts()
        elif status:
            parts.append(str(status))
        if value.get('error'):
            parts.insert(0, str(value['error']))
        if value.get('configured'):
            settings = value.get('settings') or {}
            parts.append('Checks every '+str(settings.get('poll_seconds', 45))+' seconds; full reconciliation every '+str(settings.get('reconcile_seconds', 900))+' seconds.')
        self.detail_label.configure(text='\n'.join(parts)[:2400] or 'Choose your data source, calendar and mapping, then approve a preview.')
        if 'autostart' in value:
            self.startup.set(bool(value['autostart']))

    def _connect_notion(self):
        token = self.notion_token.get().strip()
        if not token:
            messagebox.showinfo('Notion token required', 'Paste the secret from your Notion internal connection.', parent=self.root)
            return
        self.notion_token.set('')
        self._run('Validating Notion access', lambda: self.controller.connect_notion(token), lambda _: self._refresh())

    def _choose_client(self):
        path = filedialog.askopenfilename(parent=self.root, title='Choose Google Desktop OAuth client JSON', filetypes=[('JSON files', '*.json'), ('All files', '*')])
        if not path:
            return
        try:
            file = Path(path)
            if file.stat().st_size > 1024*1024:
                raise ValueError('Choose the small JSON file downloaded for your Desktop OAuth client.')
            text = file.read_text(encoding='utf-8-sig')
        except (OSError, ValueError) as exc:
            messagebox.showerror('Could not read OAuth client', str(exc), parent=self.root)
            return
        self._run('Saving Google OAuth client securely', lambda: self.controller.connect_google(text), lambda _: self.client_label.configure(text='Client selected: '+Path(path).name))

    def _find_databases(self):
        query = self.database_query.get().strip()
        from .desktop_backend import notion_id
        try:
            notion_id(query)
        except ValueError:
            pass
        else:
            self.database_rows = []
            self.database_choice.set('')
            self._load_sources()
            return
        def found(rows):
            self.database_rows = rows
            self.database_combo.configure(values=[display_name(r) for r in rows])
            if rows:
                self.database_combo.current(0)
            else:
                self.database_choice.set('')
                messagebox.showinfo('No shared database found', 'Check that the database is shared with your Notion connection. You can also enter its full URL or ID and use that directly.', parent=self.root)
        self._run('Finding shared Notion databases', lambda: self.controller.databases(query), found)

    def _load_sources(self):
        index = self.database_combo.current()
        identifier = self.database_rows[index]['id'] if 0 <= index < len(self.database_rows) else self.database_query.get().strip()
        if not identifier:
            messagebox.showinfo('Choose a database', 'Search by name or enter a Notion database/data-source ID or URL.', parent=self.root)
            return
        def found(rows):
            self.source_rows = rows
            self.source_combo.configure(values=[display_name(r) for r in rows])
            if rows:
                self.source_combo.current(0)
                self._source_selected()
            else:
                self.source_choice.set('')
                self.source_id.set('')
                messagebox.showinfo('No accessible data sources', 'Share the database with your connection and try again.', parent=self.root)
        self._run('Reading database data sources', lambda: self.controller.data_sources(identifier), found)
        self._load_calendars()

    def _source_selected(self, _event=None):
        index = self.source_combo.current()
        if 0 <= index < len(self.source_rows):
            self.source_id.set(self.source_rows[index]['id'])
            self.source_label.configure(text='Selected source: '+self.source_id.get())

    def _load_calendars(self):
        def found(rows):
            self.calendar_rows = rows
            self.calendar_combo.configure(values=[display_name(r) for r in rows])
            if rows:
                index = next((i for i, row in enumerate(rows) if row['id'] == self.calendar_id.get()), 0)
                self.calendar_combo.current(index)
                self._calendar_selected()
        self._run('Finding writable Google calendars', self.controller.calendars, found)

    def _calendar_selected(self, _event=None):
        index = self.calendar_combo.current()
        if 0 <= index < len(self.calendar_rows):
            self.calendar_id.set(self.calendar_rows[index]['id'])

    def _inspect_and_continue(self):
        if not self.source_id.get() or not self.calendar_id.get():
            messagebox.showinfo('Choose both sides', 'Select an accessible Notion data source and a writable Google calendar first.', parent=self.root)
            return
        source = self.source_id.get()
        self._run('Inspecting Notion property types', lambda: self.controller.schema(source), lambda schema: (self._apply_schema(schema), self.show('mapping')))

    def _apply_schema(self, schema):
        self.schema_data = schema
        props = properties_from_schema(schema)
        suggestions = self.controller.suggest_mapping(schema)
        suggestions = suggestions.get('properties', suggestions)
        for key, _, kind, _ in FIELDS:
            names = [name for name, prop in props.items() if prop.get('type') == kind]
            self.mapping_combos[key].configure(values=['']+names)
            current = self.mapping_vars[key].get()
            current = next((name for name, prop in props.items() if prop.get('id') == current and name in names), current)
            chosen = current if current in names else suggestions.get(key, '')
            self.mapping_vars[key].set(chosen if chosen in names else '')
        names = [name for name, prop in props.items() if prop.get('type') == 'select']
        self.category_combo.configure(values=['']+names)
        category = self.category_property.get()
        category = next((name for name, prop in props.items() if prop.get('id') == category and name in names), category)
        self.category_property.set(category if category in names else '')
        self._category_options()

    def _category_options(self):
        prop = properties_from_schema(self.schema_data).get(self.category_property.get(), {})
        names = [item['name'] for item in prop.get('select', {}).get('options', [])]
        self.category_value_combo.configure(values=['']+names)
        if self.category_value.get() not in names:
            self.category_value.set('')

    def _create_properties(self):
        source = self.source_id.get()
        if not source:
            messagebox.showinfo('Choose a source first', 'Choose your Notion data source before creating properties.', parent=self.root)
            return
        if not messagebox.askyesno('Create integration properties?', 'Create missing NCS Event ID, NCS Time Zone, Recurrence and Calendar Link properties in this selected Notion data source?\n\nExisting properties will be kept. The new fields will be available for you to review in the mapping.', parent=self.root):
            return
        def refresh(_):
            self._run('Refreshing the schema', lambda: self.controller.schema(source), self._apply_schema)
        self._run('Creating confirmed integration properties', lambda: self.controller.create_properties(source, confirmed=True), refresh)

    def _settings(self):
        properties = {key: value.get().strip() for key, value in self.mapping_vars.items() if value.get().strip()}
        for key in ('title', 'date', 'google_event_id'):
            if not properties.get(key):
                raise ValueError('Select the required '+key.replace('_', ' ')+' property. Create missing integration properties if needed.')
        if len(properties.values()) != len(set(properties.values())):
            raise ValueError('Map each field to a different Notion property.')
        if not self.source_id.get() or not self.calendar_id.get():
            raise ValueError('Choose both the data source and Google calendar.')
        return {'notion_data_source': self.source_id.get(), 'google_calendar': self.calendar_id.get(),
                'timezone': self.zone.get().strip(), 'properties': properties,
                'default_duration_minutes': int(self.duration.get()),
                'poll_seconds': float(self.poll.get()), 'reconcile_seconds': float(self.reconcile.get()),
                'notion_select_property': self.category_property.get(), 'notion_select_value': self.category_value.get()}

    def _restore_settings(self, settings):
        self.source_id.set(settings.get('notion_data_source', ''))
        self.calendar_id.set(settings.get('google_calendar', ''))
        self.database_query.set(self.source_id.get())
        for key, value in settings.get('properties', {}).items():
            if key in self.mapping_vars:
                self.mapping_vars[key].set(value)
        for key, variable in [('timezone', self.zone), ('default_duration_minutes', self.duration),
                              ('poll_seconds', self.poll), ('reconcile_seconds', self.reconcile),
                              ('notion_select_property', self.category_property), ('notion_select_value', self.category_value)]:
            if key in settings:
                variable.set(str(settings[key]))

    def _edit_mapping(self):
        settings = self.current_state.get('settings') or {}
        if settings:
            self._restore_settings(settings)
        self.show('choose')
        if self.source_id.get():
            self._run('Reading current mapping schema', lambda: self.controller.schema(self.source_id.get()), self._apply_schema)
        self._load_calendars()

    def _invalidate_preview(self):
        if self.preview_id:
            self.preview_id = None
            self.preview_summary.configure(text='Settings changed. Generate a new preview before approval.')
            self.approve_button.configure(state='disabled')

    def _preview(self):
        try:
            settings = self._settings()
        except (ValueError, TypeError) as exc:
            messagebox.showerror('Review your mapping', str(exc), parent=self.root)
            return
        self.preview_id = None
        self.approve_button.configure(state='disabled')
        def rendered(value):
            try:
                unchanged = self._settings() == settings
            except (ValueError, TypeError):
                unchanged = False
            if not unchanged:
                self.preview_summary.configure(text='Settings changed while the preview was loading. Generate a fresh preview.')
                self.approve_button.configure(state='disabled')
                self.show('preview')
                return
            self.preview_id = None if value.get('blocked') else value.get('preview_id')
            summary = value.get('summary')
            if summary is not None:
                self.preview_summary.configure(text=json.dumps(summary, ensure_ascii=False) if not isinstance(summary, str) else summary)
            else:
                self.preview_summary.configure(text='Review all proposed changes below before approving.')
            self._text(self.preview_text, json.dumps(value.get('report', value), ensure_ascii=False, indent=2, default=str))
            self.approve_button.configure(state='normal' if self.preview_id else 'disabled')
            self.show('preview')
        self._run('Generating a read-only synchronization preview', lambda: self.controller.preview(settings), rendered)

    def _approve(self):
        preview_id = self.preview_id
        if not preview_id:
            return
        if not messagebox.askyesno('Start synchronization?', 'Apply this preview’s creates, updates and links, then keep synchronizing in both directions?\n\nSupported deletions will also synchronize. Conflicting edits are retained for review. A local backup will be created first.\n\nRun only one sync instance for this source/calendar pair. Stop an existing Pi or third-party sync for this pair before starting this desktop app.', parent=self.root):
            return
        self.approve_button.configure(state='disabled')
        def done(_):
            self.preview_id = None
            self.show('dashboard')
        self._run('Backing up and starting approved synchronization', lambda: self.controller.approve(preview_id), done)

    def _resume(self):
        if not self.current_state.get('approved'):
            self.show('mapping')
            messagebox.showinfo('Review first', 'Generate and approve a preview before starting synchronization.', parent=self.root)
            return
        self._run('Resuming synchronization', self.controller.resume, lambda _: self._refresh())

    def _conflicts(self):
        def rendered(rows):
            self.conflict_rows = rows
            self.conflict_tree.delete(*self.conflict_tree.get_children())
            for row in rows:
                fields = row.get('fields', [])
                if isinstance(fields, list):
                    fields = ', '.join(fields)
                self.conflict_tree.insert('', 'end', iid=str(row['id']), values=(row['id'], fields, row.get('title') or 'Relationship '+str(row.get('link_id', ''))))
        self._run('Reading retained conflicts', self.controller.conflicts, rendered, quiet=True)

    def _selected_conflict(self):
        selection = self.conflict_tree.selection()
        if not selection:
            return None
        return next((r for r in self.conflict_rows if str(r['id']) == selection[0]), None)

    @staticmethod
    def _decoded(value):
        if isinstance(value, str):
            try:
                return json.loads(value)
            except ValueError:
                return value
        return value

    def _show_conflict(self, _event=None):
        row = self._selected_conflict()
        if row:
            text = {side.capitalize(): self._decoded(row.get(side, row.get(side+'_values', {}))) for side in ('notion', 'google', 'base')}
            self._text(self.conflict_text, json.dumps(text, ensure_ascii=False, indent=2, default=str))

    def _resolve(self, side):
        row = self._selected_conflict()
        if not row:
            messagebox.showinfo('Choose a conflict', 'Select a conflict to compare both retained versions.', parent=self.root)
            return
        if not messagebox.askyesno('Resolve using '+side.capitalize()+'?', 'Use '+side.capitalize()+' for the conflicting fields in this selected pair?\n\nThe other conflicting values will be replaced. Independent changes stay merged; originals remain in the conflict history.', parent=self.root):
            return
        def resolved(value):
            self._conflicts()
            self._refresh()
            if isinstance(value, dict) and value.get('resolved') is False:
                messagebox.showinfo('Resolution is pending', 'The provider operation has not completed. Your conflict and both versions are retained. Review the status before retrying or resuming.', parent=self.root)
            else:
                messagebox.showinfo('Conflict resolved', 'The selected values were applied and originals retained. Synchronization is paused; choose Resume when you are ready.', parent=self.root)
        self._run('Resolving the selected conflict', lambda: self.controller.resolve(row['id'], side), resolved)

    def _diagnostics(self):
        path = filedialog.asksaveasfilename(parent=self.root, title='Save redacted diagnostics', defaultextension='.json', initialfile='notion-calendar-sync-diagnostics.json', filetypes=[('JSON', '*.json')])
        if path:
            self._run('Exporting redacted diagnostics', lambda: self.controller.diagnostics(path), lambda _: messagebox.showinfo('Diagnostics saved', 'Redacted diagnostics were saved. Your credentials and event contents are excluded.', parent=self.root))

    def _autostart(self):
        enabled = self.startup.get()
        self._run('Updating startup at login', lambda: self.controller.set_autostart(enabled), lambda _: self._refresh())

    def _text(self, widget, text):
        widget.configure(state='normal')
        widget.delete('1.0', 'end')
        widget.insert('1.0', text)
        widget.configure(state='disabled')

    def _minimize(self):
        self.root.iconify()

    def _show_window(self):
        self.root.deiconify()
        self.root.lift()
        return ''

    def _quit(self):
        if self.current_state.get('running') and not messagebox.askyesno('Quit synchronization?', 'Quitting stops synchronization on this computer. Pending work is retained and resumes next time you start the app.\n\nQuit now?', parent=self.root):
            return
        self.activity.configure(text='Finishing current work and closing…')
        def close():
            try:
                self.controller.close()
            finally:
                self.results.put((True, None, lambda _: self._destroy(), True, 'Closing'))
        threading.Thread(target=close, name='desktop-close', daemon=True).start()

    def _destroy(self):
        self.alive = False
        self.tasks.put(None)
        self.root.destroy()

    def run(self):
        self.root.mainloop()


def run(controller):
    DesktopWindow(controller).run()
