"""Self-hosted Notion ↔ Google Calendar synchronization."""
__version__ = "0.2.1"
