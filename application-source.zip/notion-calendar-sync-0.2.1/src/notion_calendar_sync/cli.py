"""Administrative commands for the self-hosted synchronizer."""
from __future__ import annotations

import argparse
import dataclasses
import json
import os
from pathlib import Path
import signal
import sqlite3
import sys
import threading


def _json(value):
    def default(item):
        if dataclasses.is_dataclass(item):
            return dataclasses.asdict(item)
        if isinstance(item, Path):
            return str(item)
        if isinstance(item, sqlite3.Row):
            return dict(item)
        return str(item)
    print(json.dumps(value, default=default, indent=2, ensure_ascii=False))


def parser():
    result = argparse.ArgumentParser(prog="ncs", description="Self-hosted Notion ↔ Google Calendar synchronization")
    result.add_argument("--config", default="config.toml", type=Path, help="TOML configuration (default: config.toml)")
    commands = result.add_subparsers(dest="command", required=True)
    auth = commands.add_parser("authorize", help="Authorize a Google desktop OAuth client on this computer")
    auth.add_argument("--no-browser", action="store_true", help="Print authorization URL without launching a browser")
    auth.add_argument("--port", type=int, default=0, help="Loopback callback port (0 chooses an unused port)")
    inspect = commands.add_parser("inspect", help="Read and validate configured provider schemas/permissions")
    inspect.add_argument("--mapping", action="append", help="Restrict to a mapping (repeatable)")
    for name in ["dry-run", "sync"]:
        sub = commands.add_parser(name, help="Preview changes without remote writes" if name == "dry-run" else "Synchronize once")
        sub.add_argument("--full", action="store_true", help="Perform a full reconciliation")
        sub.add_argument("--mapping", action="append", help="Restrict to a mapping (repeatable)")
    commands.add_parser("run", help="Run continuously with polling and optional webhooks")
    commands.add_parser("status", help="Show local state and operational diagnostics")
    conflicts = commands.add_parser("conflicts", help="List unresolved conflicts (contains event values)")
    conflicts.add_argument("id", type=int, nargs="?", help="Show a particular conflict, including all versions")
    operations = commands.add_parser("operations", help="List incomplete journal operations and recovery IDs")
    operations.add_argument("id", nargs="?", help="Show one operation including its payload (contains event values)")
    resolve = commands.add_parser("resolve", help="Resolve a conflict using one side's conflicting fields")
    resolve.add_argument("id", type=int)
    resolve.add_argument("--prefer", choices=["notion", "google"], required=True)
    link = commands.add_parser("link", help="Explicitly link stable IDs; preview unless --apply is supplied")
    link.add_argument("--mapping", required=True)
    link.add_argument("--notion", required=True)
    link.add_argument("--google", required=True)
    link.add_argument("--apply", action="store_true")
    retry = commands.add_parser("retry-operation", help="Explicitly retry a blocked Notion creation after checking active pages and Trash")
    retry.add_argument("id", help="Persistent operation ID")
    retry.add_argument("--acknowledge-no-remote-create", action="store_true", required=True,
                       help="Confirm you checked the required event identity marker in active pages and Trash and found no remote creation")
    backup = commands.add_parser("backup", help="Create a consistent online SQLite backup (event data, no OAuth token)")
    backup.add_argument("output", type=Path)
    verify = commands.add_parser("webhook-verify", help="Temporarily capture Notion's initial untrusted verification candidate")
    verify.add_argument("--output", required=True, type=Path, help="New mode-600 candidate token file; never automatically trusted")
    verify.add_argument("--timeout", type=int, default=300, help="Seconds to wait for one candidate (default: 300)")
    return result


def _selected(config, names):
    wanted = set(names or [mapping.name for mapping in config.mappings])
    available = {mapping.name for mapping in config.mappings}
    unknown = wanted - available
    if unknown:
        raise ValueError("Unknown mapping: " + ", ".join(sorted(unknown)))
    return [mapping for mapping in config.mappings if mapping.name in wanted]


def status(store):
    data = {}
    for table in ["links", "operations", "conflicts", "channels"]:
        data[table] = [dict(row) for row in store.db.execute(f"SELECT status,COUNT(*) AS count FROM {table} GROUP BY status")]
    data["queued_notifications"] = store.db.execute("SELECT COUNT(*) FROM signals").fetchone()[0]
    data["database_bytes"] = store.db.execute("PRAGMA page_count").fetchone()[0] * store.db.execute("PRAGMA page_size").fetchone()[0]
    diagnostics = {}
    for row in store.db.execute("SELECT key,value FROM meta"):
        key = row["key"]
        # Cursor/identity metadata can contain private data and is intentionally
        # not displayed in the operational status command.
        if key.startswith(("last_", "channel_error:", "error:")):
            try:
                diagnostics[key] = json.loads(row["value"])
            except (ValueError, TypeError):
                diagnostics[key] = row["value"]
    data["diagnostics"] = diagnostics
    return data


def backup_database(store, output):
    output = output.expanduser().resolve()
    state = Path(store.path if hasattr(store, "path") else store.db.execute("PRAGMA database_list").fetchone()[2]).resolve()
    if output == state:
        raise ValueError("Backup output must differ from the live database")
    output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    os.close(fd)
    try:
        destination = sqlite3.connect(output)
        try:
            store.db.backup(destination)
            destination.commit()
        finally:
            destination.close()
        os.chmod(output, 0o600)
    except Exception:
        output.unlink(missing_ok=True)
        raise
    return {"backup": str(output), "bytes": output.stat().st_size}


def retry_operation(store, operation_id):
    row = store.db.execute("SELECT * FROM operations WHERE id=?", (operation_id,)).fetchone()
    if row is None:
        raise ValueError("Operation not found")
    if row["side"] != "notion" or row["action"] != "create" or row["status"] not in {"ambiguous", "retry"}:
        raise ValueError("Only an ambiguous or retrying Notion creation can be acknowledged for replay")
    link = store.db.execute("SELECT notion_id FROM links WHERE id=?", (row["link_id"],)).fetchone()
    if link is None or link["notion_id"]:
        raise ValueError("Operation has no incomplete Notion target to create")
    payload = json.loads(row["payload"])
    payload["recovery_only"] = False
    with store.db:
        store.db.execute("UPDATE operations SET status='pending',payload=?,error=NULL,next_attempt=0 WHERE id=?", (json.dumps(payload, sort_keys=True), operation_id))
    return {"operation_id": operation_id, "status": "pending", "acknowledged_no_remote_create": True}


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        return execute(args)
    except KeyboardInterrupt:
        return 130
    except Exception as error:
        # Provider exception messages are sanitized at their boundary. Other
        # failures deliberately expose only type, not arbitrary object contents.
        from .http import ProviderError
        message = str(error) if isinstance(error, (ValueError, RuntimeError, ProviderError, FileNotFoundError, FileExistsError, PermissionError)) else "Operation failed; inspect state and configuration"
        print(json.dumps({"error": type(error).__name__, "message": message}), file=sys.stderr)
        return 1


def execute(args):
    from .config import load_config
    from .store import Store
    from .service import StateLock, SyncService, configure_logging, report_has_errors
    config = load_config(args.config)
    if args.command == "authorize":
        from .oauth import authorize
        with StateLock(config.state_path):
            authorize(config.google_client_path, config.google_token_path, open_browser=not args.no_browser, port=args.port)
        _json({"authorized": True, "token_file": str(config.google_token_path)})
        return 0
    if args.command == "webhook-verify":
        from .webhooks import start_server
        if args.output.exists():
            raise FileExistsError("Candidate output already exists; choose a new file")
        if not 1 <= args.timeout <= 3600:
            raise ValueError("Verification timeout must be between 1 and 3600 seconds")
        with StateLock(config.state_path):
            args.output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            server, receiver = start_server(config, bootstrap_output=args.output)
            try:
                print("Waiting for Notion verification candidate on /webhooks/notion. This candidate remains untrusted until verified in Notion.", file=sys.stderr)
                arrived = receiver.verified.wait(args.timeout)
            finally:
                server.shutdown()
                server.server_close()
        if not arrived:
            raise RuntimeError("No verification candidate received before timeout")
        _json({"candidate_file": str(args.output.resolve()), "trusted": False, "instruction": "Read the candidate privately, paste into Notion's Verify form, and only after successful verification set NOTION_WEBHOOK_SECRET to the same value."})
        return 0
    with Store(config.state_path) as store:
        if args.command == "status":
            _json(status(store))
            return 0
        if args.command == "backup":
            _json(backup_database(store, args.output))
            return 0
        if args.command == "operations":
            if args.id is None:
                rows = store.db.execute("SELECT * FROM operations WHERE status NOT IN ('done','cancelled') ORDER BY created,id").fetchall()
            else:
                rows = store.db.execute("SELECT * FROM operations WHERE id=?", (args.id,)).fetchall()
            result = []
            for row in rows:
                item = dict(row)
                payload = json.loads(item.pop("payload"))
                item["source_id"] = payload.get("source_id")
                item["recovery_only"] = bool(payload.get("recovery_only"))
                if args.id is not None:
                    item["payload"] = payload
                result.append(item)
            _json(result)
            return 0
        if args.command == "conflicts":
            if args.id is None:
                rows = store.db.execute("SELECT id,mapping,link_id,fields,created FROM conflicts WHERE status='open' ORDER BY id").fetchall()
            else:
                rows = store.db.execute("SELECT * FROM conflicts WHERE id=?", (args.id,)).fetchall()
            data = []
            for row in rows:
                item = dict(row)
                for key in ["fields", "base", "notion", "google"]:
                    if key in item:
                        try:
                            item[key] = json.loads(item[key])
                        except (ValueError, TypeError):
                            pass
                data.append(item)
            _json(data)
            return 0
        if args.command == "retry-operation":
            with StateLock(config.state_path):
                _json(retry_operation(store, args.id))
            return 0
        from .providers import NotionProvider, GoogleProvider
        from .engine import Engine
        notion, google = NotionProvider(config), GoogleProvider(config)
        engine = Engine(config, store, notion, google)
        if args.command == "inspect":
            result = []
            for mapping in _selected(config, args.mapping):
                result.append({"mapping": mapping.name, "notion": notion.validate(mapping), "google": google.validate(mapping)})
            _json(result)
            return 0
        # Even dry runs share observations with the daemon's live state. Acquire
        # the writer lock so the preview is coherent and never interleaves an
        # administrative apply command with an ongoing daemon operation.
        with StateLock(config.state_path):
            if args.command in {"dry-run", "sync"}:
                _selected(config, args.mapping)
                report = engine.sync(dry_run=args.command == "dry-run", full=args.full, mapping_names=args.mapping)
                _json(report)
                return 2 if report_has_errors(report) else 0
            if args.command == "resolve":
                report = engine.resolve(args.id, args.prefer)
                _json(report)
                return 2 if report_has_errors(report) else 0
            if args.command == "link":
                _selected(config, [args.mapping])
                report = engine.link(args.mapping, args.notion, args.google, dry_run=not args.apply)
                _json(report)
                return 2 if report_has_errors(report) else 0
            if args.command == "run":
                configure_logging(config)
                stop = threading.Event()
                previous = {}
                for signum in [signal.SIGINT, signal.SIGTERM]:
                    previous[signum] = signal.signal(signum, lambda *_: stop.set())
                try:
                    SyncService(config, store, engine, google, stop=stop).run()
                finally:
                    for signum, handler in previous.items():
                        signal.signal(signum, handler)
                return 0
    raise ValueError("Unknown command")
