import os
from pathlib import Path
import sqlite3
import tempfile
import unittest

from notion_calendar_sync.cli import backup_database, parser, status, retry_operation, execute
from notion_calendar_sync.store import Store


class CLITests(unittest.TestCase):
    def test_parse_commands(self):
        self.assertEqual("dry-run", parser().parse_args(["dry-run", "--full"]).command)
        self.assertEqual("notion", parser().parse_args(["resolve", "2", "--prefer", "notion"]).prefer)
        args = parser().parse_args(["link", "--mapping", "work", "--notion", "page-id", "--google", "event-id"])
        self.assertFalse(args.apply)
        args = parser().parse_args(["authorize", "--no-browser", "--port", "8766"])
        self.assertTrue(args.no_browser)
        self.assertIsNone(parser().parse_args(["operations"]).id)
        self.assertEqual("op", parser().parse_args(["operations", "op"]).id)

    def test_online_backup_preserves_wal_state_and_private_permissions(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state.sqlite3"
            with Store(path) as store:
                store.db.execute("INSERT INTO meta VALUES ('test','123')")
                store.db.commit()
                destination = Path(directory) / "backup.sqlite3"
                backup_database(store, destination)
                copied = sqlite3.connect(destination)
                try:
                    self.assertEqual("123", copied.execute("SELECT value FROM meta WHERE key='test'").fetchone()[0])
                finally:
                    copied.close()
                if os.name != 'nt':  # POSIX modes are not Windows ACLs; native vault is tested separately.
                    self.assertEqual(0o600, destination.stat().st_mode & 0o777)
                with self.assertRaises(FileExistsError):
                    backup_database(store, destination)
                with self.assertRaises(ValueError):
                    backup_database(store, path)

    def test_explicit_ambiguous_notion_creation_retry_requires_acknowledgement(self):
        import contextlib
        import io
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                parser().parse_args(["retry-operation", "operation-id"])
        args = parser().parse_args(["retry-operation", "operation-id", "--acknowledge-no-remote-create"])
        self.assertTrue(args.acknowledge_no_remote_create)
        with tempfile.TemporaryDirectory() as directory:
            with Store(Path(directory) / "state.sqlite3") as store:
                link_id = store.db.execute("INSERT INTO links(mapping,google_id) VALUES ('work','google-id')").lastrowid
                store.db.execute("INSERT INTO operations(id,mapping,link_id,side,action,payload,status,error,next_attempt) VALUES ('operation-id','work',?,'notion','create','{}','ambiguous','AmbiguousWrite',9999999999)", (link_id,))
                store.db.commit()
                store.db.execute('UPDATE operations SET payload=\'{"recovery_only":true,"source_id":"google-id"}\'')
                store.db.commit()
                retry_operation(store, "operation-id")
                row = store.db.execute("SELECT * FROM operations").fetchone()
                self.assertEqual("pending", row["status"])
                import json
                self.assertFalse(json.loads(row["payload"])["recovery_only"])
                self.assertEqual("google-id", json.loads(row["payload"])["source_id"])
                self.assertEqual(0, row["next_attempt"])
                self.assertIsNone(row["error"])
                with self.assertRaises(ValueError):
                    retry_operation(store, "operation-id")
                store.db.execute("UPDATE operations SET status='retry',side='google'")
                store.db.commit()
                with self.assertRaises(ValueError):
                    retry_operation(store, "operation-id")
                with self.assertRaises(ValueError):
                    retry_operation(store, "missing")

    def test_operations_lists_recovery_ids_without_event_values_by_default(self):
        import contextlib
        import io
        import json
        from unittest.mock import patch
        from notion_calendar_sync.config import Config
        with tempfile.TemporaryDirectory() as directory:
            config = Config(state_path=Path(directory) / "state.sqlite3")
            with Store(config.state_path) as store:
                store.db.execute("INSERT INTO operations(id,mapping,link_id,side,action,payload,status) VALUES ('op-id','work',1,'notion','create',?,'ambiguous')", (json.dumps({"source_id": "event-id", "values": {"title": "private event title"}, "recovery_only": True}),))
                store.db.commit()
            for operation_id in (None, "op-id"):
                output = io.StringIO()
                args = ["operations"] + ([operation_id] if operation_id else [])
                with patch("notion_calendar_sync.config.load_config", return_value=config), contextlib.redirect_stdout(output):
                    self.assertEqual(0, execute(parser().parse_args(args)))
                data = json.loads(output.getvalue())
                self.assertEqual("op-id", data[0]["id"])
                self.assertEqual("event-id", data[0]["source_id"])
                self.assertTrue(data[0]["recovery_only"])
                if operation_id:
                    self.assertEqual("private event title", data[0]["payload"]["values"]["title"])
                else:
                    self.assertNotIn("private event title", output.getvalue())

    def test_status_hides_channel_tokens_and_sync_cursors(self):
        with tempfile.TemporaryDirectory() as directory:
            with Store(Path(directory) / "state.sqlite3") as store:
                store.db.execute("INSERT INTO meta VALUES ('cursor:work','\"private-cursor\"')")
                store.db.execute("INSERT INTO meta VALUES ('last_service_metrics','{\"duration_seconds\":1}')")
                store.db.execute("INSERT INTO channels VALUES ('channel','work','resource','private-token',123,'active')")
                store.db.commit()
                result = status(store)
                self.assertNotIn("private-token", str(result))
                self.assertNotIn("private-cursor", str(result))
                self.assertIn("last_service_metrics", result["diagnostics"])


if __name__ == "__main__":
    unittest.main()
