# Notion Calendar Sync

A free, MIT-licensed desktop application for reliable two-way synchronization between Notion and Google Calendar on macOS and Windows. It includes guided account connection, schema-based field mapping, read-only previews, persistent conflicts, explicit two-way deletion, SQLite recovery and compressed API responses.

Start with [the desktop user and build guide](docs/desktop.md). The headless CLI and Raspberry Pi systemd deployment files remain available for self-hosted installations; the desktop wrapper reuses the same sync engine.

```sh
python3 -m venv .venv
# Activate the environment for your operating system.
python -m pip install -r packaging/requirements-build.txt
# Set PYTHONPATH=src in your shell, then:
python -m notion_calendar_sync.desktop
python -m unittest discover -s tests -v
python scripts/build-desktop.py native
```

The source archive intentionally excludes account-specific deployment reports, screenshots, observed configurations, private backups, credentials and synchronization state. The application cannot synchronize while its host is asleep, offline or not running. Never run independent synchronizers against the same provider scope without transferring/reviewing their stable identity mappings.

Application source is [MIT](LICENSE). Bundled runtime notices are in [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
